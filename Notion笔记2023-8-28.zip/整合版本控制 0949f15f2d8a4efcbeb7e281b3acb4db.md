# 整合版本控制

参考链接：

[【idea必知必会】git使用_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1Pc411G7UL/?buvid=XY9DA259897DDB94CD03E89AB86A72A21C07B&is_story_h5=false&mid=boT4H8ZIZ3cHGGR7OCDwLQ==&p=1&plat_id=114&share_from=ugc&share_medium=android&share_plat=android&share_session_id=4ddff11c-3eac-4957-b393-fae4b1583a68&share_source=WEIXIN&share_tag=s_i&timestamp=1687084021&unique_k=VffhhX8&up_id=351569518&vd_source=1ff3d91e5fc304c43204d473b2b897df)

[Git在IDEA中的使用（详细图文全解）_git idea_拧螺丝专业户的博客-CSDN博客](https://blog.csdn.net/mucaoyx/article/details/98476174)

## 一、Git的安装与配置

[Git安装教程](https://www.cnblogs.com/wj-1314/p/7993819.html)

进入[Git官网](https://git-scm.com/downloads)，选择合适的系统进行下载。然后点开idea，打开设置，进入版本控制页面：

![Untitled](Untitled%2078.png)

进入Git配置页面点击测试可以看到它的版本，则代表安装成功，否则安装失败。

IDEA中对于github的操作有两种，一种是将项目拷到本地，一种是将项目上传到GitHub中去。

## 二、GitHub与配置

[GitHub教程](https://zhuanlan.zhihu.com/p/369486197)

我们知道Git是版本控制工具，它可以记录项目开发过程中的各个历史版本，允许开发者进行项目的回退与编辑，这使得团队开发变得轻松。Git不仅支持本地仓库也支持远程仓库，GitHub便是开源的远程仓库，适合开发者对项目进行上传、开发、维护和开源。GitHub因为只支持git版本库格式的托管，因此叫做GitHub。

### 1.GitHub个人主页

![Untitled](Untitled%2079.png)

标注 1：View profile and more，更多选项视图；

标注 2：Your profile，个人简介。

如上图所在，我们依次点击 标注 1 所示的View profile and more和 标注 2 所示的Your profile，进入「个人简介」界面：

![Untitled](Untitled%2080.png)

标注 1：Edit profile，修改个人简介；

标注 2：Overview，个人主页概览；

标注 3：Repositories，仓库；

标注 4：Star，点星记录；

标注 5：Followers，粉丝；

标注 6：Following，关注的 GitHub 账号；

标注 7：个人贡献历史记录。

### 2.配置GitHub

![Untitled](Untitled%2081.png)

我们知道GitHub是代码托管平台，可以认为就是一个远程服务器，有自己的空间和存储。因此为了实现本地仓库与远程仓库的互连，首先要做的就是两个主机之间互联。GitHub提供了类似于云服务器连接一样的方式——SSH密钥和账号密码登录。IDEA提供了两种方式登录，这里我们推荐直接使用GitHub账号密码，避免在GitHub生成密钥的麻烦。

## 三、拉取项目

在前面学习Git时我们了解了Git的使用规范，我们开发一个项目并上传到远程仓库时，创建远程仓库必须是空文件。而我们对一个项目进行在开发时，必须先拉取再开发。下面我们重点介绍一下文件拉取：

参考文档：

[【IDEA】利用git从GitHub上clone项目_LeeeeeMOON的博客-CSDN博客](https://blog.csdn.net/leonia1996/article/details/107200640)

由此我们知道，在idea中类似于创建一个新项目，我们点击新建项目的地方，选择git，克隆即可。具体如下：

![Untitled](Untitled%2082.png)

![Untitled](Untitled%2083.png)

找到指定的远程仓库项目，选择复制HTTPS url进行粘贴

![Untitled](Untitled%2084.png)

## 四、上传到远程仓库

### 1.分支的创建与管理

首先是创建和选择分支，对于不同分支下的项目进行管理，这里idea默认选择的是master分支进行管理，我们也可以在该处进行分支，并对每一个分支的远程仓库进行设置。

![Untitled](Untitled%2085.png)

![Untitled](Untitled%2086.png)

在左侧“提交”中也可以进行便捷管理，两者等价。

![Untitled](Untitled%2087.png)

### 2.提交与推送

IDEA支持git add自动添加操作：当我们初始化仓库之后，每一次更改操作自动git add，无须手动。

在IDEA中我们不需要每次更改之后都使用git add添加到工作区，只需要关注版本级的提交和推送就可以了。

![Untitled](Untitled%2088.png)

点击origin可以定义远程仓库并进行推送(push)：

![Untitled](Untitled%2089.png)

![Untitled](Untitled%2090.png)

这里的URL是GitHub对应仓库的HTTPS，不是SSH

![Untitled](Untitled%2091.png)

点击推送按钮后弹出以下弹窗

![Untitled](Untitled%2092.png)

远程链接时由于事先在IDEA中已经配置了账号，因此这里弹出框不要选择`使用令牌`链接GitHub，而是`通过GitHub登录`（会弹出网页点击验证按钮）即可。

![Untitled](Untitled%2093.png)

关于推送原则：远程仓库中只少不多，即不能有推送仓库所不包含的文件。推送到远程仓库的项目必须是在远程仓库原有项目基础上的增加和修改，而不能是删除。

### 3.远程仓库的创建和删除

IDEA无法管理远程仓库的创建和删除，因此要手动去创建才可以远程链接。

### (1)仓库创建

![Untitled](Untitled%2094.png)

项目名称可以与本地项目名称不一致，只要远程连接时指定好url即可。

![Untitled](Untitled%2095.png)

### (2)仓库删除

本节主要对远程仓库进行删除操作

![Untitled](Untitled%2096.png)

点击`setting`进入设置页面，下滑至最低处

![Untitled](Untitled%2097.png)

点击`Delete this repository`

![Untitled](Untitled%2098.png)

## 五、仓库的管理

IDEA中提供了Git的实际操作面板，允许对仓库进行快捷的管理。

![Untitled](Untitled%2099.png)

点击左下角Git图标，进入Git具体操作页面。在这个页面我们可以看到每次提交的版本记录以及本地仓库、远程仓库链接等。

### 1.版本回滚

首先是选择我们需要回退的版本，点击`Reset Current Branch to Here`

![Untitled](Untitled%20100.png)

我们看到回退选择有如下几种：

![Untitled](Untitled%20101.png)

![Untitled](Untitled%20102.png)

如果我们直接回退到原先项目代码，可以选择Hard，之后要稍等片刻，项目结构会自动刷新。如果没反应可能回滚较慢。在等待期间不要进行其它操作。

### 2.远程仓库链接的删除与重建

本地仓库允许链接多个远程仓库进行管理

原先远程仓库链接建立与删除是使用指令。进入当项目当前目录中使用如下命令即可及案例和删除

```powershell
# 推送到远程仓库
git push <remote_repo> <branch_name>
# 删除远程
git remote rm origin
```

除了打开命令行到项目目录执行上述命令外，IDEA还提供了终端按钮直接到达该项目所在目录，执行终端命令

![Untitled](Untitled%20103.png)

![Untitled](Untitled%20104.png)

在IDEA中的操作如下：

![Untitled](Untitled%20105.png)

打开面板直接操作：

![Untitled](Untitled%20106.png)