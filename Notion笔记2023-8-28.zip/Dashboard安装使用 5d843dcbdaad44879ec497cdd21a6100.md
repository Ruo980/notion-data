# Dashboard安装使用

[官方参考文档](https://kubernetes.io/zh-cn/docs/tasks/access-application-cluster/web-ui-dashboard/)

在之前学习K8s时，我们经常借助kubectl输入命令来操作管理集群。和git Bash类似，K8s也提供了Dashboard可视化管理工具来替换kubectl去管理kubernetes集群及资源。掌握Dashboard能显著提高我们的开放管理效率。

## 基本概念

---

Dashboard 是基于网页的 Kubernetes 用户界面。 你可以使用 Dashboard 将容器应用部署到 Kubernetes 集群中，也可以对容器应用排错，还能管理集群资源。 你可以使用 Dashboard 获取运行在集群中的应用的概览信息，也可以创建或者修改 Kubernetes 资源 （如 Deployment，Job，DaemonSet 等等）。 例如，你可以对 Deployment 实现弹性伸缩、发起滚动升级、重启 Pod 或者使用向导创建新的应用。

Dashboard 同时展示了 Kubernetes 集群中的资源状态信息和所有报错信息：

![Untitled](Untitled%2066.png)

## 安装部署

---

Dashboard的安装部署主要分为两个步骤：下载和启动，以及开放访问。在前者中，我们使用类似于创建Pod资源的方式进行安装；而在后者中，我们通过设置代理来实现访问。

### 下载安装

K8s集群默认情况下不会部署 Dashboard。和其它资源一样，可以通过`kubectl apply yaml`命令部署：

```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml
```

此时dashboard已经安装运行启动了。

### 设置代理

为了保护集群数据，K8s一般不允许外部访问集群资源，因此我们需要使用代理服务器指定端口。外部主机借助浏览器请求指定IP:端口访问该集群。这样内部的资源也会响应的开放。这类似于给Web应用指定服务端口。

```bash
kubectl proxy
```

执行上述命令默认集群对外服务端口为8001。在集群本地使用[http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/](http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/)可以直接访问到集群应用。

我们可以使用如下命令来允许外部主机访问

```bash
kubectl proxy --port=8100 --address=192.168.192.142 --accept-hosts='^.*' &
```

修改访问路径中的IP(该IP是集群主机的IP，也即远程连接需要输入的IP)及端口后访问。这样我们便可以使用任意主机的浏览器请求192.168.192.142:8100，进而访问到该虚拟机中的集群。然后/api/vi/namespace访问指定的资源。现在我们访问Dashboard，在浏览器输入如下：

```bash
http://192.168.192.142:8100/api/v1/namespaces/kubernetes-dashboard/services/http:kubernetes-dashboard:/proxy/
```

### 开放端口

如果我们按照上面的方式设置好代理服务器之后，访问上述网址不行，可能是防火墙屏蔽的原因。执行下面命令查看8100端口占用情况：

```bash
sudo firewall-cmd --zone=public --query-port=8100/tcp
```

这将查询公共区域（public zone）中TCP端口8100的状态。如果该端口已开放，命令将返回yes；如果该端口未开放，命令将返回no。

如果返回no，表示端口8100未被防火墙开放。你可以使用以下命令来添加防火墙规则以允许端口8100的访问：

```
sudo firewall-cmd --zone=public --add-port=8100/tcp --permanent
sudo firewall-cmd --reload
```

第一条命令将添加一个允许TCP端口8100的规则，并将其永久保存。第二条命令将重新加载防火墙配置，使规则生效。

重新加载防火墙配置后，你可以再次运行上述查询命令来确认端口8100是否已成功开放。

<aside>
💡 注意，每一次重启虚拟机，我们都需要使用minikube start重启K8s集群，然后使用kubectl proxy重新设置代理服务器。

</aside>

## 欢迎页面

---

![Untitled](Untitled%2067.png)

## 部署容器化应用

---

传统的K8s应用部署主要是创建yaml文件并手动编写设置，然后借助kubectl命令实现指定应用的生成。这种过程虽然简单但在终端中编写配置相当繁杂，Dashboard则提高了可视化操作页面来简化这一过程。

![Untitled](Untitled%2068.png)

点击任何页面右上角的 **CREATE** 按钮以开始。我们可以看到三种创建方式：我们可以手工指定应用的详细配置，或者上传一个包含应用配置的 YAML 或 JSON _清单_文件或者在线编写一个YAML文件。

![Untitled](Untitled%2069.png)

通过一个简单的部署向导，可以使用 Dashboard 将容器化应用作为一个 Deployment 和可选的 Service 进行创建和部署。

部署向导需要提供以下信息：

- **应用名称**（必填）：应用的名称。内容为 `应用名称` 的 标签 会被添加到任何将被部署的 Deployment 和 Service。注意它是pod中label标签下的key-value值而不是name属性值。
    
    在选定的 Kubernetes 名字空间 中， 应用名称必须唯一。必须由小写字母开头，以数字或者小写字母结尾， 并且只含有小写字母、数字和中划线（-）。小于等于24个字符。开头和结尾的空格会被忽略。
    
- **容器镜像**（必填）：公共镜像仓库上的 Docker 容器镜像 或者私有镜像仓库 （通常是 Google Container Registry 或者 Docker Hub）的 URL。容器镜像参数说明必须以冒号结尾。
- **Pod 的数量**（必填）：希望应用程序部署的 Pod 的数量。值必须为正整数。
    
    系统会创建一个 Deployment 以保证集群中运行期望的 Pod 数量。
    
- **服务**（可选）：对于部分应用（比如前端），你可能想对外暴露一个 Service，这个 Service 可能用的是集群之外的公网 IP 地址（外部 Service）。其它只能对集群内部可见的 Service 称为内部 Service。不管哪种 Service 类型，如果你选择创建一个 Service，而且容器在一个端口上开启了监听（入向的）， 那么你需要定义两个端口。创建的 Service 会把（入向的）端口映射到容器可见的目标端口。 该 Service 会把流量路由到你部署的 Pod。支持 TCP 协议和 UDP 协议。 这个 Service 的内部 DNS 解析名就是之前你定义的应用名称的值。

如果我们有更多的配置要求，可以打开 **Advanced Options** 部分，这里可以定义更多详情设置。不过我们更推荐直接编写yaml文件并上传的做法，这方便我们更快的迁移和部署项目。