# Minikube学习

### 安装Minikube

Minikube是一个工具，允许本地计算机上运行单节点的Kubernetes集群。它旨在使我们能够在部署到生产Kubernetes集群之前，在本地开发和测试应用程序变得更加容易。它还提供了一个命令行界面（CLI），用于与集群进行交互，允许您部署应用程序、管理资源和监视集群的状态。使用Minikube，可以轻松设置用于开发、测试和学习目的的本地Kubernetes环境。它特别适用于希望在不需要完整规模生产集群的情况下使用Kubernetes的开发人员。

首先，选择合适的虚拟化技术（如VirtualBox、VMware或KVM），并按照Minikube的安装指南进行操作，在VM上安装和配置Minikube。

使用curl下载Minikube二进制可执行安装包:

```bash
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64

sudo install minikube-linux-amd64 /usr/local/bin/minikube
```

`install`命令用于将一个文件复制到指定位置，并在必要时设置访问权限。这个命令将拷贝Minikube可执行文件到`/usr/local/bin`目录，并设置它可以作为名称为`minikube`的命令在终端中运行。

### 搭建K8s集群

我们前面已经使用install命令将Minikube的程序添加到环境变量中。现在我们使用minikube命令来启动Minikube工具并生成K8s集群。

1.**启动Minikube**

输入minikube start启动：

```bash
[root@administrator program]# minikube start
* minikube v1.25.2 on Centos 7.9.2009 (amd64)
* Automatically selected the docker driver. Other choices: ssh, none
* The "docker" driver should not be used with root privileges.
* If you are running minikube within a VM, consider using --driver=none:
*   https://minikube.sigs.k8s.io/docs/reference/drivers/none/

X Exiting due to DRV_AS_ROOT: The "docker" driver should not be used with root privileges.
```

我们看到启动异常：这是因为需要创建了一个属于docker用户组的k8s用户，并切换到该用户，才能启动minikube并运行docker。

```bash
# 创建用户
useradd  -g docker k8s
# 设置用户密码
passwd k8s
# 切换用户
su k8s
```

2**.再次启动Minikube**

再次使用minikube start命令启动会正常运行，但考虑到国内网速问题我们往往在启动minikube创建集群时指定一些参数来启动：

```bash
minikube start --vm-driver=docker --image-mirror-country='cn'
```

- `-vm-driver=docker` 指定使用 docker作为虚拟化驱动
- `-image-mirror-country='cn'` 配置使用中文dockcer镜像仓库，加速镜像下载

3**.安装结果**

![Untitled](Untitled%2072.png)

我们看到minikube启动过程会启动docker作为运行时，同时会创建K8s集群。

尽管minikube默认携带了kubectl来操作集群，但是它是以: `minikube kubectl cluster-info`语法形式操作； 如果想直接使用`kubectl`命令，需要将其复制到/bin目录下

```bash
# 查找kubectl命令的位置:切换到正常用户
[root@administrator program]# find / -name kubectl
/home/k8s/.minikube/cache/linux/amd64/v1.23.3/kubectl
/www/server/docker/volumes/minikube/_data/lib/minikube/binaries/v1.23.3/kubectl

# 复制到/bin目录下
[root@administrator program]# cp /www/server/docker/volumes/minikube/_data/lib/minikube/binaries/v1.23.3/kubectl /bin/

#切换为k8s用户
[root@administrator program]# su k8s
[k8s@administrator program]$ kubectl version
Client Version: version.Info{Major:"1", Minor:"23", GitVersion:"v1.23.3", GitCommit:"816c97ab8cff8a1c72eccca1026f7820e93e0d25", GitTreeState:"clean", BuildDate:"2022-01-25T21:25:17Z", GoVersion:"go1.17.6", Compiler:"gc", Platform:"linux/amd64"}
Server Version: version.Info{Major:"1", Minor:"23", GitVersion:"v1.23.3", GitCommit:"816c97ab8cff8a1c72eccca1026f7820e93e0d25", GitTreeState:"clean", BuildDate:"2022-01-25T21:19:12Z", GoVersion:"go1.17.6", Compiler:"gc", Platform:"linux/amd64"}
```

此时我们可以直接使用`kubectl`来操作minikube创建的集群了。

![Untitled](Untitled%2073.png)

### 插件安装

在这里我们将学习在集群中搭建基本的插件来提高开发速度。

**1.Dashboard**

> Dashboard是基于网页的K8S用户界面。可以使用Dashboard将容器应用部署到K8S集群中，也可以对容器应用排错，还能管理集群资源。
> 

```bash
minikube addons list # minikube自带插件列表

minikube addons enable ADDON_NAME # ADDON_NAME插件启用

minikube addons disable ADDON_NAME #  ADDON_NAME插件禁用
```

### 代理服务器设置

经过上面的操作，Minikube搭建好集群并添加了各种所需插件。现在我们需要给集群创建代理服务器使得外部主机能够访问该集群。

使用kubectl设置代理，--address设置为服务器地址(内外IP，外网IP不行)，然后才能从外部访问Dashboard

```bash
kubectl proxy  --port=[需要暴露的端口号] --address='[服务器IP]' --accept-hosts='^[外部访问服务器的IP]$'  >/dev/null 2>&1&
```

- kubectl proxy：启动Kubernetes代理服务器。
- --port=[需要暴露的端口号]：指定代理服务器监听的端口号。将[需要暴露的端口号]替换为所需的端口号。
- --address='[服务器IP]'：指定代理服务器绑定的IP地址。将[服务器IP]替换为服务器的IP地址。这里填写虚拟机的内网IP
- --accept-hosts='^[外部访问服务器的IP]$'：指定一个正则表达式模式，用于匹配可以访问代理服务器的允许主机。将[外部访问服务器的IP]替换为需要访问服务器的外部机器的IP地址或主机名。
- >/dev/null 2>&1&：将标准输出和错误流重定向到/dev/null，丢弃任何输出。末尾的&将命令在后台运行。

```bash

kubectl proxy --port=8100 --address=192.168.192.142 --accept-hosts='^.*' &
```

修改访问路径中的IP及端口后访问。这样我们便可以使用任意主机的浏览器请求192.168.192.142:8100，进而访问到该虚拟机中的集群。然后/api/vi/namespace访问指定的资源。现在我们访问Dashboard，在浏览器输入如下：

```bash
http://192.168.192.142:8100/api/v1/namespaces/kubernetes-dashboard/services/http:kubernetes-dashboard:/proxy/
```

### 开放端口

如果我们按照上面的方式设置好代理服务器之后，访问上述网址不行，可能是防火墙屏蔽的原因。执行下面命令查看8100端口占用情况：

```bash
sudo firewall-cmd --zone=public --query-port=8100/tcp
```

这将查询公共区域（public zone）中TCP端口8100的状态。如果该端口已开放，命令将返回yes；如果该端口未开放，命令将返回no。

如果返回no，表示端口8100未被防火墙开放。你可以使用以下命令来添加防火墙规则以允许端口8100的访问：

```
sudo firewall-cmd --zone=public --add-port=8100/tcp --permanent
sudo firewall-cmd --reload
```

第一条命令将添加一个允许TCP端口8100的规则，并将其永久保存。第二条命令将重新加载防火墙配置，使规则生效。

重新加载防火墙配置后，你可以再次运行上述查询命令来确认端口8100是否已成功开放。

<aside>
💡 注意，每一次重启虚拟机，我们都需要使用minikube start重启K8s集群，然后使用kubectl proxy重新设置代理服务器。

</aside>