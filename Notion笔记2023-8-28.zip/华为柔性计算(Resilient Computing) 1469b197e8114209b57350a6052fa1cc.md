# 华为柔性计算(Resilient Computing)

[柔性计算(Resilient Computing)](\l)

[一、概念 · Concept](about:blank#%E4%B8%80%E6%A6%82%E5%BF%B5-concept)

[二、原理 · Principle](about:blank#%E4%BA%8C%E5%8E%9F%E7%90%86-principle)

[(1) cpu.shares](about:blank#cpu.shares)

[(2) schedule](about:blank#schedule)

[(3) OutOfcpu](about:blank#outofcpu)

[三、实现 · Implementation](about:blank#%E4%B8%89%E5%AE%9E%E7%8E%B0-implementation)

[(1) ReController: ReUpdater](about:blank#recontroller-reupdater)

[(2) ReController: ReEvictor](about:blank#recontroller-reevictor)

[(3) ReScheduler](about:blank#rescheduler)

[(4) RePod](about:blank#repod)

## 一、概念 · Concept

现流行的弹性计算(Elastic Computing)通过虚拟化技术将物理资源进行抽象，为用户提供任意规格的计算资源；然而这些规格往往是预设的，经常与用户实际的资源需求不匹配，导致资源的分配率较高（>90%）但实际使用率却较低（<40%）

为了缓解这个问题，提出了柔性计算(Resilient Computing)的概念，柔性计算旨在将**已分配给用户但实际并未使用到的**那部分资源利用上，提高整体资源利用率

尝试将柔性计算逻辑应用在容器编排工具Kubernetes上

## 二、原理 · Principle

### (1) cpu.shares

在Kubernetes集群中，用户需要创建Pod时可以设置一个 `request` 字段，它表示该Pod至少需要这么多资源，随后Kubernetes在调度的过程中会基于 `request` 比较各个Node上的剩余资源是否满足，只会将Pod调度到满足该Pod `request` 的Node上；例如：

```
spec:
  containers:
  - name: containername
    resources:
      requests:
        memory: "500Mi"
        cpu: "700m"
```

对于上面的Pod，CPU资源少于 700毫核（1 核CPU = 1000 毫核CPU）、内存资源少于 500Mi 的Node，将不符合Pod的需求

此外，与 `request` 同级的还有一个 `limit` 字段，`request` 表示的是资源的最小值，而 `limit` 则表示资源的最大值；Pod实际运行时消耗的资源可以超过 `request`，但不能超过 `limit`，否则会被终止

`request` 表示Pod所需资源的最小值，然而 `request` 是用户自行设置的，可能Pod实际运行的时候并没有消耗这么多资源，导致资源的浪费；同时，用户为了确保自己的Pod有足够的资源稳定运行，在设置 `request` 时可能会偏大；总之，用户认为Pod需要的资源（`request`）和Pod实际消耗的资源之间的不匹配，使得这里可以通过柔性计算逻辑提高资源的使用率

早先认为，Kubernetes存在一套机制，可以确保Pod `request` 索要的那部分资源会被该Pod牢牢占有，哪怕Pod实际并未使用到这么多资源，其它Pod也不能对这部分资源进行使用；这一点体现在实验上：

- 实验以CPU资源为例
- 测试Node拥有64核CPU资源
- 测试Pod实际消耗2核CPU，但 `request` 被设置为较大的5核
- 实验表明：只能将 64 / 5 = 12 个这样的Pod调度到Node上运行，更多的Pod会处于资源不足而挂起的Pending状态

在这个实验中，可以认为每个Pod都独占其 `request` 索要的5核CPU资源，使得即使Pod实际只消耗2核CPU，但剩余的3核无法被进一步使用，Node上无法再运行更多的这样的Pod

但是在进一步调研中发现，以CPU资源为例，`request` 字段设置的值在底层是传递到了Cgroup的 `cpu.shares` 字段中，参考 [https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/kubelet/cm/helpers_linux.go#L115](https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/kubelet/cm/helpers_linux.go#L115)：

![image1.png](image1.png)

![image2.png](image2.png)

`cpu.shares` 本身不存在资源独占的机制，所以哪怕Pod设置的 `request` 较大而实际并未使用到这么多资源，其它的Pod也可以利用这部分资源

### (2) schedule

随后发现，造成前面无法将更多的Pod运行到Node上的原因是调度，参考 [https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257](https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257)，对Node资源的检查实现在 `fitsRequest()` 中；以CPU资源为例，其检查逻辑为：

```
if podRequest.MilliCPU > (nodeInfo.Allocatable.MilliCPU - nodeInfo.Requested.MilliCPU) {
    // Failed
}
```

其中：

- `podRequest.MilliCPU` 就是该Pod为CPU资源设置的 `request` 值
- `nodeInfo.Allocatable.MilliCPU` 表示Node可分配的CPU资源数，也就是Node上CPU资源的总量
- `nodeInfo.Requested.MilliCPU` 表示Node已分配的CPU资源数

通过将Node上CPU资源的总量( `Allocatable` )减去已使用量( `Requested` )，得到资源剩余量；如果Pod索要的资源 `request` 超过资源剩余量，那么该Node将不满足条件，Kubernetes不会将该Pod调度到该Node上

问题是Node资源已使用量 `nodeInfo.Requested.MilliCPU` 的计算方式不太合理，在Kubernetes默认调度器中，它只是简单地通过累加已经运行在Node上的Pod的 `request` 来计算Node已使用的资源，而由于 `request` 可能与Pod实际消耗的资源有较大偏差，所以Node资源已使用量的计算也会过早地接近饱和，使得尽管Node上剩余资源较多，也无法将更多的Pod调度到该Node上运行 —— 这与柔性计算的内涵一致，对资源的分配额度与实际使用不匹配，导致资源的浪费；在这里，用户通过 `request` 为Pod分配资源，但 `request` 的设置通常依据不足，与实际消耗的资源量有一定的偏差

为此在Kubernetes上的实现柔性计算的解决思路是，修改Kubernetes默认调度器的调度逻辑，使得其在计算Node资源已使用量时不是简单地通过累加 `request` 得到，而是更逼近已经运行在Node上Pod的真实资源使用情况，这样可以令Node资源的已使用量更接近实际情况，能将更多的Pod调度到Node上运行

> 为此编写ReScheduler组件来替换Kubernetes的默认调度器，同时辅以ReController组件，具体实现见后面内容
> 

通过ReScheduler能将更多的Pod调度到Node上运行，以前面的实验为参考：

- 实验以CPU资源为例
- 测试Node拥有64核CPU资源
- 测试Pod实际消耗2核CPU，但 `request` 被设置为较大的5核；借助ReController可以获取到Pod的实际资源消耗情况为2核CPU
- 实验表明：ReScheduler可以将 (64 - 5) / 2 + 1 = 30 个Pod调度到Node上运行

然而实验发现，虽然ReScheduler可以将更多的Pod调度到Node上，但是额外数量的Pod却会以 **OutOfcpu** 的理由被kubelet终止运行

### (3) OutOfcpu

通过对 OutOfcpu 异常在源码中的定位，发现其抛出于 [https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/kubelet/lifecycle/predicate.go#L143](https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/kubelet/lifecycle/predicate.go#L143)：

![image3.png](image3.png)

往调用链上追溯发现是 kubelet 的生命周期检查问题

前面通过ReScheduler修改了调度逻辑（主要是修改了对Node已使用量的计算方式），但调研发现，kubelet 会定期对Node进行检查，其中在对资源的检查中直接复用了调度部分的代码，也就是 [https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257](https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257)，使得其在计算Node已使用资源时仍然是按 `request` 累加的方式

测试的Pod实际消耗2核CPU，但 `request` 却是5核，对于拥有64核资源的Node来说，ReScheduler能够将30个这样的Pod调度上去，这时对 kubelet 而言，Node已使用的CPU资源是 `request` × 30 = 150 核，远超过Node拥有的64核，为此 kubelet 就会以 OutOfcpu 的理由终止部分Pod的运行，使得Node的 `request` 总量不超过 100%

为此在后续的方案改进中，需要放弃对 `request` 的使用，强制让CPU资源的 `request` 为最小的 1m，然后用户原本设置在 `request` 的值改为设置到 `limit` 中，并且修改ReScheduler，其原本只是修改Node资源已使用量的计算方式，这次更新后，对于待调度的Pod，不再视 `request` 为其索要的资源量，而是用 `limit` 代替

这样做的好处有两点：①对用户而言只是将原本的设置从 `request` 转移到了 `limit`；②调度逻辑保持不变，只是将从 `request` 获取Pod索要的资源量改成了从 `limit`；

> 后续华为这边也反映，用户只会设置一个 limit，request 不会被设置
> 

由于 `request` 被设置为 1m，所以可以绕过 kubelet 的生命周期检查，ReScheduler在将更多的Pod调度到Node上的同时，能确保这些Pod稳定运行在Node上

## 三、实现 · Implementation

### (1) ReController: ReUpdater

新增一个组件 **ReController**，负责辅助柔性计算的实现

由于柔性计算需要时刻关注Pod的实际资源消耗情况，为此ReController的其中一个组件 **ReUpdater** 负责从 `/metrics` API读取Pod的实际消耗情况，并写入到Pod的Annotation `resilient-computing/averageMilliCpu` 字段中

ReUpdater 会以一定的频率去读取Pod的实际消耗并更新字段，由于目前无法存储历史数据，所以采用的记录方式是：

- `resilient-computing/averageMilliCpu`：记录多次数据采集后Pod平均消耗的CPU资源
- `resilient-computing/recoreTime`：ReUpdater 采集数据的次数

每次这两个字段通过下面的方式进行更新：

$$\mathrm{\text{usageMilliCpu}} = \frac{\mathrm{\text{usageMilliCpu}} \times \mathrm{\text{recordTime}} + \mathrm{\text{nowMilliCpu}}}{\mathrm{\text{recordTime}} + 1}$$

recordTime = recordTime + 1

这样可以在不记录历史数据的情况下，得到 ReUpdater 运行至今Pod平均消耗的CPU资源

单纯以平均值去衡量Pod的实际资源使用情况并不足够，于是引入方差，可以通过下面的公式计算得到：

*D*(*X*) = *E*((*X*−*E*(*X*)2)) = *E*(*X*2) − *E*2(*X*)

而新增 `resilient-computing/squareCpuValue` 字段表示公式中的 *E*(*X*2)，用于辅助进行方差的计算；实际测试发现，可以在 ReUpdater 的任意一次读取后计算得到平均值和方差，进而更好地反映Pod的真实资源使用情况

### (2) ReController: ReEvictor

由于柔性计算利用的是已分配但暂时未使用上的那部分资源，而Pod的资源可能处于不断变化中，一旦Pod消耗的CPU资源增大，那么会挤压到柔性计算这部分资源的利用，进而使得整个Node的CPU资源紧张

如果Node资源紧张，kubelet 存在压力驱逐机制，会根据一定的策略将Pod驱逐，使得资源使用率维持在一个合理的范畴，但 kubelet 的驱逐机制只针对内存、磁盘等资源，CPU并不支持；同时考虑到驱逐顺序的问题，为了更好地自定义优先驱逐哪个Pod，在ReController中添加多一个组件 **ReEvictor**，该组件与ReUpdater一起构成整个ReController

ReEvictor 的作用有两点：

1. 定期监测Node的CPU资源使用率，当超过预先设置的阈值时，触发驱逐
- 
    
    ![image4.png](image4.png)
    
    在具体实现中，通过 `/metrics` API获取Node的实际CPU使用量以及容量，计算出此刻的CPU实际使用率
    
1. 根据我们手动为Pod设置的柔性优先级 `resilient-computing/RePriority` 进行驱逐，优先级低的会被优先驱逐，而相同优先级则优先驱逐实际资源使用量更多的Pod
- 
    
    ![image5.png](image5.png)
    
    在具体实现中，实际是对Node上所有的Pod进行排序，排在前面的Pod会被优先驱逐；排序的依据定义在 `Less()` 函数中，优先按照 `resilient-computing/RePriority` 进行排序，然后按照CPU实际使用量进行排序
    

确定了驱逐顺序后，开始驱逐，由于单独驱逐优先级最低的Pod可能无法将CPU使用率降至阈值以下，所以会进行多个Pod的驱逐，直到Node CPU使用率降下来；此外，由于相同优先级时驱逐顺序取决于CPU实际使用量，但刚运行在Node上的Pod无法从 `/metrics` 中获取到CPU指标，为此设置一个驱逐保护期，当ReController监测的次数少于 3 （表示刚运行上去），则暂时跳过驱逐：

![image6.png](image6.png)

### (3) ReScheduler

对Kubernetes默认调度逻辑的修改集中在其检查资源的插件 NodeResourcesFit 上：[https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257](https://github.com/kubernetes/kubernetes/blob/release-1.23/pkg/scheduler/framework/plugins/noderesources/fit.go#L257)，特别是对CPU资源的检查上，原有的逻辑为：

```
if podRequest.MilliCPU > (nodeInfo.Allocatable.MilliCPU - nodeInfo.Requested.MilliCPU) {
    // Failed
}
```

ReScheduler 通过Kubernetes提供的调度框架(Scheduler Framework)实现，该官方提供的扩展接口可以修改调度过程中的某处逻辑，实现自定义调度器；由于资源检查需要靠上面提到的 NodeResourcesFit 扩展实现，为此ReScheduler的思想逻辑是：先禁用原生的NodeResourcesFit，再启用ReScheduler进行替代

NodeResourcesFit 扩展在三个扩展点上都进行了注册：

- preFilter 扩展点：在该扩展点，NodeResourcesFit 负责获取Pod的所需的资源，本质是获取待调度Pod的 `request`
- filter 扩展点：在该扩展点，NodeResourcesFit 会对所有Node进行遍历，并计算出Node的剩余资源是否符合Pod需求
- score 扩展点：filter 扩展点对Node的筛选后，可能有多个Node满足Pod的资源需求，NodeResourcesFit 在该扩展点负责传递所有满足要求的Node，由Kubernetes对它们进行打分，分数最高的Node将会是Pod最终被调度的地方

为此ReScheduler需要修改的是 NodeResourcesFit 在 filter 扩展点处的逻辑，修改部分为：

- 原本Pod索要的资源读取自 `request`，ReScheduler则修改为读取自 `limit`
- 
    
    ![image7.png](image7.png)
    
    因为为了绕过 kubelet 的生命周期检查，这时的 `request` 已经被强制设置为 1m，用户认为该Pod需要的资源已经从 `request` 转移到 `limit`
    
- 修改Node资源已使用量的计算方式

![image8.png](image8.png)

- Kubernetes默认情况下是直接通过累加 `request` 的方式来计算Node的资源已使用量，ReScheduler则是通过读取运行在Node上各个Pod的 `resilient-computing/averageMilliCpu` 和 `resilient-computing/squareCpuValue` 来计算Node资源的已使用量，使得可以将更多的Pod调度到Node上
    
    但目前并未决定如何基于 `resilient-computing/averageMilliCpu` 和 `resilient-computing/squareCpuValue` 来表示Pod当前CPU的实际使用量，只是单纯用平均值 `resilient-computing/averageMilliCpu` 来表示，这对于CPU资源波动较大的Pod可能不准确，后续再考虑如何将方差纳入到计算中
    

> 在具体代码实现上，不仅实现了ReScheduler在 filter 扩展点的代码，还实现了在 preFilter 扩展点的代码，这是因为 filter 扩展点存在对 preFilter 处定义的数据结构的类型断言(Type Assertion)，必须同时实现
> 

### (4) RePod

举例从用户的角度出发，在原生框架和柔性框架下，部署Pod时在YAML配置文件上的差别：

![image9.png](image9.png)

左边为原生框架下的YAML，右边是对应的柔性框架

对比可见，相比于原生框架，用户想通过柔性框架部署应用，只需进行三处操作（上图红框）：

1. 指定调度器(Scheduler)为 `rescheduler`，使得基于实际资源使用情况可以将更多的Pod调度到Node上
2. 设置 `requests.cpu` 为 `1m`，使得绕过 kubelet 的生命周期检查，避免抛出 OutOfCpu 异常
3. 在Annotation中设置柔性优先级 `resilient-computing/RePriority`，作为资源紧张时，ReEvictor的驱逐依据

Pod成功运行在Node上后，ReController会定期更新Pod的 Annotation（上图蓝框），更新的字段包括 `resilient-computing/recordTime`、`resilient-computing/averageMilliCpu` 和 `resilient-computing/squareCpuValue`，这些字段都无需用户设置

完整的柔性框架实现为：

![image10.png](image10.png)