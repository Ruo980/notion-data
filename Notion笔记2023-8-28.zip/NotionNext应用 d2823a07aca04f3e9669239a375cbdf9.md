# NotionNext应用

[NotionNext 操作手册 | Tangly Blog](https://www.tangly1024.com/article/notion-next-guide#0b3ca7a7e9c84b43b03683aa419f38f7)

[Dashboard – Vercel](https://vercel.com/ruo980/notion-next-75wo)

[](https://github.com/Ruo980/NotionNext/blob/main/blog.config.js)