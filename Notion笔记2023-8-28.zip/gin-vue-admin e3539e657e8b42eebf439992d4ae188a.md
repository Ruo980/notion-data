# gin-vue-admin

**目录：**

**参考文档：**

[实战模板项目官网](https://www.gin-vue-admin.com/)

[模板项目代码Github](https://github.com/flipped-aurora/gin-vue-admin)

[模板项目教学视频](https://www.bilibili.com/video/BV1Rg411u7xH/?vd_source=1ff3d91e5fc304c43204d473b2b897df)

## 项目概览

---

### 基本介绍

gin-vue-admin 是一个使用 gin + vue 进行极速开发的全栈后台管理系统，后台使用 gin 框架，gin 是目前很流行的 Go 语言 web 框架，前端主要使用 vue。

这个项目还使用到了一些流行的 Go 开源库及中间件，例如：

gin：最流行的 Go 语言 web 框架
gorm：数据库操作中间件
zap：uber 开源的 Go 语言日志库
redis：k-v 缓存

### 技术选型

GIN-VUE-ADMIN 是一款基于 GIN+VUE+ElementPlus 开发的全栈基础开发平台。

- 前端：用基于 `vue3` 的 `Element-Plus` 构建基础页面。
- 后端：用 `Gin` 快速搭建基础 restful 风格 API，`Gin` 是一个 go 语言编写的 Web 框架。
- 数据库：采用 `MySql`>5.7 版本，数据库引擎 innoDB，使用 `gorm` 实现对数据库的基本操作，已添加对 sqlite 数据库的支持。
- 缓存：使用 `Redis` 实现记录当前活跃用户的 `jwt` 令牌并实现多点登录限制。
- API 文档：使用 `Swagger` 构建自动化文档。
- 配置文件：使用 `fsnotify` 和 `viper` 实现 `yaml` 格式的配置文件。
- 日志：使用 `zap` 实现日志记录。

## 项目部署

---

### 代码下载

找到模板项目网址：[https://github.com/flipped-aurora/gin-vue-admin](https://github.com/flipped-aurora/gin-vue-admin)。然后打开GoLand以版本控制的方式将项目克隆到本地。

**1.打开克隆页面**

在JetBrains中并不需要使用git clone命令来克隆项目到本地，它支持可视化快速克隆并进行版本控制。按照下面步骤打开克隆页面：

![Untitled](Untitled%20139.png)

选择Git→克隆，进入克隆页面。

**2.克隆项目到本地**

输入刚刚项目GitHub网址，点击“克隆”，将项目从指定GitHub远程仓库拉取到本地：

![Untitled](Untitled%20140.png)

此时我们看到项目已经下载到本地，并在GoLand打开了：

![Untitled](Untitled%20141.png)

### 环境配置

参考上面的目录：

deploy用于项目的发布和运维，因此暂时不用学习；

docs主要是存放说明文档资源，一般存放的是Markdown所需要使用的图片；

server后端项目，也是我们重点关注的Gin框架构建

web前端项目，采用的是Vue3+Element+Vite来进行的开发

因此现阶段，我们只需要分别编辑web和server即可。我们首先使用GoLand打开server项目，使用其它前端工具(如WebStorm、VsCode)打开Web项目。然后对各自项目分别引入各种依赖。

**1.GoLand配置后端项目**

使用GoLand打开server文件夹，点击设置，配置GOROOT与GoModule的代理。点击并打开go.mod文件，右键”`go mod tidy`”导入指定的所有依赖。

依赖导入完成之后，选择项目入口文件main.go并debug该文件，运行后端项目。

**2.WebStorm配置前端项目**

和后端项目一样，先下载相关依赖，然后运行项目即可。

![Untitled](Untitled%20142.png)

点击“`npm install`”下载相关依赖，然后找到package.json提供的脚本：

```json
"scripts": {
        "serve": "node openDocument.js && vite --host --mode development",
        "build": "vite build --mode production",
        "limit-build": "npm install increase-memory-limit-fixbug cross-env -g && npm run fix-memory-limit && node ./limit && npm run build",
        "preview": "vite preview",
        "fix-memory-limit": "cross-env LIMIT=4096 increase-memory-limit"
    },
```

使用`npm run serve`即可运行出项目。

## 后端项目

---

本章主要介绍后端项目的大致设计功能，帮助我们了解项目，能在项目基础上进行后续的开发。

### 创建路由

**1.编写路由文件**

在Gin框架末尾“项目结构”中我们知道，如何从main.go中将路由及其处理函数分离出来成为单独的包router\controller。

首先定义一个router对象：路由名称主要是Init+数据体名称+Router

```go
package system

import (
	v1 "github.com/flipped-aurora/gin-vue-admin/server/api/v1"
	"github.com/flipped-aurora/gin-vue-admin/server/middleware"
	"github.com/gin-gonic/gin"
)

type UserRouter struct{}

func (s *UserRouter) InitUserRouter(Router *gin.RouterGroup) {
	userRouter := Router.Group("user").Use(middleware.OperationRecord())
	userRouterWithoutRecord := Router.Group("user")
	baseApi := v1.ApiGroupApp.SystemApiGroup.BaseApi
	{
		userRouter.POST("admin_register", baseApi.Register)               // 管理员注册账号
		userRouter.POST("changePassword", baseApi.ChangePassword)         // 用户修改密码
		userRouter.POST("setUserAuthority", baseApi.SetUserAuthority)     // 设置用户权限
		userRouter.DELETE("deleteUser", baseApi.DeleteUser)               // 删除用户
		userRouter.PUT("setUserInfo", baseApi.SetUserInfo)                // 设置用户信息
		userRouter.PUT("setSelfInfo", baseApi.SetSelfInfo)                // 设置自身信息
		userRouter.POST("setUserAuthorities", baseApi.SetUserAuthorities) // 设置用户权限组
		userRouter.POST("resetPassword", baseApi.ResetPassword)           // 设置用户权限组
	}
	{
		userRouterWithoutRecord.POST("getUserList", baseApi.GetUserList) // 分页获取用户列表
		userRouterWithoutRecord.GET("getUserInfo", baseApi.GetUserInfo)  // 获取自身信息
	}
}
```

这段代码是一个定义在 system 包中的 UserRouter 结构体，包含了一个 InitUserRouter 方法。代码的作用是初始化用户相关的路由。

1. InitUserRouter 方法接收一个指向 gin.RouterGroup 的指针参数 Router。
2. 第 12 行代码创建了名为 userRouter 的 RouterGroup，并使用了一个名为 middleware.OperationRecord 的中间件。

**2.按模块封装**

将这些路由文件按照模块划分，放置在一个包中做进一步封装：

![Untitled](Untitled%20143.png)

如上图所示，实际上是划分为system、example两个模块，前者是系统配置接口组，后者是一个用户案例功能接口组。我们把系统必须带有的路由全部放置于这个system包中(system/enter.go)。

**3.统一管理**

把模块全部放置于router包中统一对外接口，统一管理。

在router内创建enter.go文件夹，导入各模块包，然后重新放置在一个路由组合中：

```go
package router

import (
	"github.com/flipped-aurora/gin-vue-admin/server/router/example"
	"github.com/flipped-aurora/gin-vue-admin/server/router/system"
)

type RouterGroup struct {
	System  system.RouterGroup
	Example example.RouterGroup
}

var RouterGroupApp = new(RouterGroup)
```

4.注册到Gin中

经过上面的步骤，我们创建和定义了路由及其分组。但是我们还需要把router注册到Gin中。也就是说我们需要在main.go中导入包.方法()并传入main.go中定义的引擎来进行初始化。例如：

```go
package main

import (
	"ginDemo2/routers"

	"github.com/gin-gonic/gin"
)

func main() {

	// 创建一个默认的路由引擎
	r := gin.Default()

	// 路由抽离并分组
	routers.SetupProductRouterInit(r)

	// 启动 HTTP 服务，默认在 0.0.0.0:8080 启动服务
	r.Run(":8080")

}
```

但实际上该项目对此进行了进一步的封装：

在项目/server/initialize/router.go中完成路由的注册：

```go
package initialize

// 初始化总路由

func Routers() *gin.Engine {
	Router := gin.Default() //生成Gin引擎
	InstallPlugin(Router) // 安装插件
	systemRouter := router.RouterGroupApp.System //导入自定义路由模块
	exampleRouter := router.RouterGroupApp.Example //导入自定义路由模块
	//把引擎注册为全局变量
	Router.StaticFS(global.GVA_CONFIG.Local.StorePath, http.Dir(global.GVA_CONFIG.Local.StorePath)) // 为用户头像和文件提供静态地址
	docs.SwaggerInfo.BasePath = global.GVA_CONFIG.System.RouterPrefix
	Router.GET(global.GVA_CONFIG.System.RouterPrefix+"/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	global.GVA_LOG.Info("register swagger handler")
	// 方便统一添加路由组前缀 多服务器上线使用

	PublicGroup := Router.Group(global.GVA_CONFIG.System.RouterPrefix)
	{
		// 健康监测
		PublicGroup.GET("/health", func(c *gin.Context) {
			c.JSON(http.StatusOK, "ok")
		})
	}
	{
		systemRouter.InitBaseRouter(PublicGroup) // 注册基础功能路由 不做鉴权
		systemRouter.InitInitRouter(PublicGroup) // 自动初始化相关
	}
	//从全局变量中引入引擎
	PrivateGroup := Router.Group(global.GVA_CONFIG.System.RouterPrefix)
	PrivateGroup.Use(middleware.JWTAuth()).Use(middleware.CasbinHandler())// 设定中间件
	{ // 将各路由全部注册初始化：包.初始化方法(引擎)
		systemRouter.InitApiRouter(PrivateGroup, PublicGroup)    // 注册功能api路由
		systemRouter.InitJwtRouter(PrivateGroup)                 // jwt相关路由
		systemRouter.InitUserRouter(PrivateGroup)                // 注册用户路由
		systemRouter.InitMenuRouter(PrivateGroup)                // 注册menu路由
		systemRouter.InitSystemRouter(PrivateGroup)              // system相关路由
		systemRouter.InitCasbinRouter(PrivateGroup)              // 权限相关路由
		systemRouter.InitAutoCodeRouter(PrivateGroup)            // 创建自动化代码
		systemRouter.InitAuthorityRouter(PrivateGroup)           // 注册角色路由
		systemRouter.InitSysDictionaryRouter(PrivateGroup)       // 字典管理
		systemRouter.InitAutoCodeHistoryRouter(PrivateGroup)     // 自动化代码历史
		systemRouter.InitSysOperationRecordRouter(PrivateGroup)  // 操作记录
		systemRouter.InitSysDictionaryDetailRouter(PrivateGroup) // 字典详情管理
		systemRouter.InitAuthorityBtnRouterRouter(PrivateGroup)  // 字典详情管理
		systemRouter.InitChatGptRouter(PrivateGroup)             // chatGpt接口

		exampleRouter.InitCustomerRouter(PrivateGroup)              // 客户路由
		exampleRouter.InitFileUploadAndDownloadRouter(PrivateGroup) // 文件上传下载功能路由

	}

	global.GVA_LOG.Info("router register success")
	return Router
}
```

### 创建api

在该项目中使用了api包来替代controller存放处理函数。然后我们在