# Go语法基础

**目录：**

**参考文档：**

[韩茹视频教学](https://www.bilibili.com/video/BV1k4411G7yy/?vd_source=1ff3d91e5fc304c43204d473b2b897df)

[Go语言中文官网](https://go.p2hp.com/doc/)

[Go 零基础编程入门教程 · Golang学习笔记](https://www.k8stech.net/go-book/)

[码神之路知识体系](https://www.mszlu.com/go/base/01/01.html#_1-go%E5%8E%86%E5%8F%B2)

[阿秀的学习笔记](https://interviewguide.cn/notes/02-learning_route/02-language/02-golang.html)

## Go的核心特性

在最近的十年里，C/C++在计算领域没有很好得到发展，并没有新的系统编程语言出现。对于开发程度和系统效率在很多情况下不能兼得。要么执行效率高但低效的开发和编译，如C++；要么执行低效，但拥有有效的编译，如.NET、Java；所以需要一种拥有较高的执行速度、编译速度和开发速度的编程语言，Go就横空出世了。

- **以斐波拉契数列进行性能比较**
    
    编译速度排名：Golang →C→JavaScript+NodeJs→PHP→C++→Java→Python
    
    运行速度排名：C++→C→Golang→Java→JavaScript+NodeJs→PHP→Python
    

Golang既有C语言一样的编译运行效率，同时又能像Python一样进行快速开发。它的高级特性如下：

- 从C语言中继承了很多理念，表达式语法控制结构等等，但它比绝大多数语言要简洁不少，这一点是其最大的亮点之一，也是其在未来进入高并发高性能场景的重要筹码。
- 引入了包的概念，一个文件必须属于一个包。
- 提供垃圾回收机制，内存自动回收，不需要管理人员去管理内存。
- go的并发执行单元是一种称为goroutine的协程。

## 环境配置

和C/C++一样，在使用Go之前，我们需要搭建Go语言运行环境。环境的配置主要包括下载go编译器并配置到环境变量中。本节还主要讲述GOROOT与GOPATH，明白Go语言运行机制。

### 安装下载

[快速下载](https://go.p2hp.com/doc/install)

- 下载完成后,直接双击 msi 文件进行安装,一路点击`Next`即可
- 打开wind+R 输入cmd,打开命令行工具，输入 go version 查询安装的go版本。

```go
$ go version
go version go1.14.2 windows/amd64
```

### GOROOT与GOPATH

Go编译器下载完成后需要将GOROOT与GOPATH添加到环境变量中：

- GOROOT：GOROOT是指Go语言的安装根目录。当我们安装Go语言时，会选择一个目录作为Go的安装路径，这个目录就是GOROOT。GOROOT中包含了Go语言的标准库、编译器、工具链等。在使用Go语言开发时，系统会根据GOROOT来查找和加载相关的库和工具。它的作用类似于JDK路径，提供javac等编译工具及Java标准库。
- GOPATH：GOPATH是指Go语言的工作目录。它是一个环境变量，用于指定你的Go项目的根目录。只有在GOPATH下，才可以创建和组织Go项目，并且在这个目录下安装和管理第三方库。GOPATH下的结构一般包括三个子目录：src、pkg和bin。src目录用于存放源代码，pkg目录用于存放编译后的包对象文件，bin目录用于存放可执行文件。

<aside>
💡 GOROOT是指Go语言的安装根目录，而GOPATH是指Go语言的工作目录，用于存放你的Go项目和第三方库。

</aside>

在使用Go语言开发时，项目文件应该位于GOPATH的src目录下的相应包路径中。当使用import语句导入其他包时，Go编译器会在GOPATH下的src目录中查找相应的包。也就是说，我们不能像Java语言一样在任意目录创建我们的项目并交由GOROOT编译，只能在GOPATH内创建项目。显然，这种做法是不合适的。从Go 1.11版本开始，Go模块化（Go Modules）的引入使得GOPATH不再是必需的。不过，在使用Go模块化时，GOROOT仍然是必需的，因为它包含了Go语言的标准库和工具链。

### Go Modules

Go Modules是Go语言自从1.11版本引入的一种模块化管理工具。它的目的是解决Go语言包管理的一些问题，并提供更灵活、可靠的依赖管理机制。

在传统的GOPATH方式下，所有的Go项目都需要放在同一个GOPATH目录下，这导致了项目之间的依赖管理困难，无法同时使用不同版本的依赖包。Go模块化允许我们在任意目录下开发和管理Go项目，不再依赖于GOPATH。通过使用go mod命令来初始化和管理模块。

Go Modules的具体用法如下：

在项目的根目录下使用`go mod init`命令来初始化一个新的模块。这将会创建一个`go.mod`文件，其中包含了模块的名称和版本信息。然后，使用`go get`命令来获取依赖包，并将其添加到`go.mod`文件中。Go Modules会自动解析和管理依赖关系，并确保使用正确的版本。

<aside>
💡 从上述过程我们看到，它类似于git的使用过程。借助于go mod可以将任意目录下的项目放置于GOROOT管理。而go.mod文件更新maven中的pom文件用来管理依赖。

</aside>

使用`go mod init`命令生成go.mod来管理项目依赖的过程也叫做启用依赖项跟踪。

另外，Go Modules还支持语义化版本控制。在`go.mod`文件中指定依赖包的版本范围，例如`v1.2.3`、`^1.2.0`、`>=1.0.0`等。这样可以确保项目在更新依赖包时不会引入不兼容的变化。

使用Go Modules的好处包括：

- 简化依赖管理：不再需要将所有项目放在同一个GOPATH下，可以在任意目录下开发和管理项目。
- 版本控制：可以使用语义化版本控制来管理依赖包的版本，确保项目的稳定性和兼容性。
- 离线支持：Go Modules可以缓存依赖包，使得在没有网络连接的情况下仍然可以构建项目。

总的来说，Go Modules提供了更灵活、可靠的依赖管理机制，使得Go语言开发更加方便和可靠。它已经成为Go语言包管理的推荐方式，并且在未来的版本中将成为默认的包管理方式。

### 代理配置

在使用Go Modules时，当执行`go get`或`go build`等命令时，Go会从远程仓库下载依赖包。然而，直接从远程仓库下载可能会受到网络延迟或不稳定的影响，导致构建过程变慢或失败。为了解决这个问题，可以使用Go代理来缓存依赖包，以便在需要时快速获取。

当执行`go get`或`go build`等命令时，Go会首先检查本地代理是否有所需的依赖包，如果有则直接从代理获取，否则才会从远程仓库下载。

GoProxy（https://goproxy.io）：GoProxy是一个公共的Go代理服务，它提供了全球多个节点，可以加速依赖包的下载。

使用Go代理的好处包括：

- 加速依赖包下载：代理可以缓存依赖包，减少从远程仓库下载的时间。
- 离线支持：代理可以在没有网络连接的情况下提供依赖包，使得在离线环境下仍然可以构建项目。
- 减轻远程仓库的负载：代理可以减少对远程仓库的请求，降低远程仓库的负载压力。

使用命令go env可以查看Go配置信息：

![Untitled](Untitled%20191.png)

在上图中我们可以查看GOROOT、GOPATH与GOPROXY的配置信息。`go env -w 配置变量 = 值`可以修改Go的配置。

```powershell
go env -w GOPROXY=https://goproxy.cn,direct #设置代理

go env -w GO111MODULE=on #开启go modules

go env -w GO111MODULE=auto #根据go.mod的有无来自开启
```

## Hello World

本节主要以一个简单的hello world对go语言编程有一个基本的认识。

### 创建项目

这里我们推荐的IDE是GoLand。下面是GoLand创建Go项目的过程。

作为Go的工作目录，GOPATH实际上是可以指定多个的，我们把添加到本地环境变量的GOPATH目录认为是全局GOPATH。尽管GoLand支持便捷设置多个GOPATH，这里包括全局、项目级、模块级别。但考虑到Go Modules的发行，我们在后续的开发中将抛弃GOPATH，而采用依赖项跟踪(go mod)。

创建项目过程：

1. 打开GoLand：启动GoLand集成开发环境。
2. 创建新项目：点击菜单栏中的 "File"（文件）选项，然后选择 "New Project"（新建项目）。
3. 选择项目类型：在弹出的对话框中，选择 "Go" 作为项目类型。
4. 配置项目：在下一个对话框中，输入项目的名称和选择项目的位置。你可以选择一个现有的目录作为项目的根目录，或者创建一个新的目录。
5. 配置Go SDK：在下一个对话框中，选择你要使用的Go SDK。如果你还没有安装Go SDK，可以点击 "Download"（下载）按钮来下载并安装Go SDK。
6. 配置项目模板：在下一个对话框中，选择你要使用的项目模板。GoLand提供了一些常用的项目模板，例如 "Empty Project"（空项目）、"Web Application"（Web应用程序）等。选择适合你的项目类型的模板。
7. 完成创建：点击 "Create"（创建）按钮，GoLand将会根据你的选择创建一个新的Go项目。

Go语言项目（工作空间的大致结构如下）：

```
- workspace
    - bin
    - pkg
    - src
        - github.com
            - user_name
                - project1
                - project2
```

如果当前项目不在GOPATH内，我们需要启动依赖跟踪项才可以正常运行项目，具体操作：在当前目录中使用go mod init命令生成go.mod文件即可。

不过如果我们创建GoLand项目时在第3步选择Go Modules作为项目类型，生成的项目会直接包含go.mod文件，省去了模块化启动的步骤。

### 基础入门

在上面创建的项目中创建hello.go文件，代码如下：

```go
package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}
```

在此代码中:

- 声明一个`main`包（包是对函数进行分组的一种方式，它由同一目录中的所有文件组成)。
- 导入流行的 `fmt` 包, 其中包含格式化文本的功能，包括打印到控制台. 这个包是你安装 Go 时得到的标准库包之一。
- 实现 `main` 函数以将消息打印到控制台。当你运行`main`包时`main` 函数会默认执行。

****[Init函数和main函数说明](https://www.topgoer.com/go%E5%9F%BA%E7%A1%80/Init%E5%87%BD%E6%95%B0%E5%92%8Cmain%E5%87%BD%E6%95%B0.html)****

**1.package(包)**

在Go语言中，package（包）是一种组织和管理代码的方式。每个Go源代码文件都属于一个包，而包可以包含多个相关的源代码文件。在一个Go程序中，通常会有一个特殊的包名为`main`的包，它包含了程序的入口点（`main`函数）。当程序运行时，会首先执行`main`包中的`main`函数。程序必须从 `main`包开始运行，如果源代码文件是程序的入口文件，必须将其声明为`main`包，而其它仅被调用的源代码文件则可以自定义所属的包，一般其父文件夹就是package。

**2.外部包引入**

和其它语言一样，Go的包包可以被其他包导入并使用其中的代码。通过导入其他包，可以重用已经实现的功能，避免重复编写代码。导入包的语法是使用`import`关键字，后跟包的路径。

当我们使用import关键字进入第三方外部包时，需要刷新go.mod：在当前目录输入`go mod tidy`进行刷新。

**3.包与模块区别**

包（package）是用于组织和管理代码的基本单元。每个Go源代码文件都属于一个包，而包可以包含多个相关的源代码文件。包提供了代码的可见性控制和代码复用的机制。通过导入其他包，可以重用已经实现的功能，避免重复编写代码。包在编译和构建过程中起到了重要的作用。
模块（module）是用于管理代码依赖关系的单元。一个模块是一个包的集合，它定义了一组相关的包，并且指定了这些包的版本。模块使用Go语言的模块管理工具（如go mod）进行管理。模块提供了一种机制来管理和解决代码的依赖关系，确保项目的构建和运行所需的包的版本一致性。

<aside>
💡 也就是可以说，模块相当于子项目，而包只是项目的一个组成。不同的模块可以导入不同的依赖，而包则共享自己所属模块的依赖。

</aside>

**4.包访问权限**

不同于Java采用关键字来设置访问权限，在Go语言中，访问权限是通过标识符的大小写来确定的。Go语言中的标识符（变量、函数、结构体等）以大写字母开头的被认为是公开的，可以在包外部访问。而以小写字母开头的标识符则被认为是私有的，只能在包内部访问。

例如，如果有一个包含一个公开函数和一个私有函数的包，那么只有公开函数可以在包外部被访问，而私有函数只能在包内部被访问。下面是一个示例：

```go
package mypackage

import "fmt"

func PublicFunction() {
fmt.Println("This is a public function")
}

func privateFunction() {
fmt.Println("This is a private function")
}
```

```go
package main

import (
"fmt"
"mypackage"
)

func main() {
mypackage.PublicFunction() // 可以访问公开函数
// mypackage.privateFunction() // 无法访问私有函数，会导致编译错误
}
```

在上面的示例中，PublicFunction是一个公开函数，可以在包外部被访问。而privateFunction是一个私有函数，只能在mypackage包内部被访问。如果在main函数中尝试调用privateFunction，会导致编译错误。

## Golang变量

变量是用于存储和操作数据的基本单元。在使用变量之前，需要先声明变量并指定其类型。Go语言是静态类型语言，变量的类型在编译时就确定了，并且变量一旦声明后，其类型就不能再改变。

### 变量定义

**1.变量声明**

Go语言采用关键字`var`进行变量声明，另外变量类型被置于变量名之后。Go变量声明格式如下：

```go
var variableName dataType //Go的变量类型被置于变量名之后
var variableName dataType = value //Go支持声明时直接赋值初始化
//eg:
var age int
var name string
var isStudent bool

//eg:
var age int = 25
var name string = "John"
var isStudent bool = true
```

**2.多变量声明**

当同时定义多个变量的时候，可以使用括号批量声明：

```go
var (
    variable1 dataType1 = value1
    variable2 dataType2 = value2
    // ...
)

//eg:
var (
    a, b int  // 同时声明 a, b 的整数
    c float64
)
```

var关键字是括号成立的必要条件。

**3.简短声明（仅在函数内部可用）**

除了上述常规声明之外，Golang对初始化时的声明进行了改进，提高了简短声明机制。如果变量定义时就进行初始化赋值，可以考虑使用`:=`，Golang会自动根据值来判断该变量的类型。

```go
a := 1
```

简短声明重点就是减去了var和类型声明。

注意：

- var关键字是括号批量声明的必要条件，因此，不使用简短声明。
- 全局变量不允许使用简短声明，它必须使用var关键字开头，且首字母必须大写。

**4.简短声明应用**

Golang使用简短声明快速实现两个变量值的交换

```go
package main

import "fmt"

func main() {
	a := 100
	b := 200
	b,a = a,b
	fmt.Printf("a=%d,b=%d",a,b)
}
```

<aside>
💡 在实际开发中，只有在需要显式指定类型或在函数外部声明变量时，才需要使用var声明。其它时候一般推荐使用简短声明。

</aside>

### 匿名变量

使用`多重赋值`时，如果`不需要在左值中接受变量`，可以使用匿名变量：

```go
package main

import (
	"fmt"
	"net"
)
func main() {

    //conn, err := net.Dial("tcp", "127.0.0.1:8080")
    //如果不想接收err的值，那么可以使用_表示，这就是匿名变量
    conn, _ := net.Dial("tcp", "127.0.0.1:8080")
	fmt.Println(conn)
}
```

也就是说，当函数多个返回值时，只需要使用_就可以替代省略掉。

<aside>
💡 下划线“_”是特殊标识符，用来忽略结果。

</aside>

当它在程序代码中时，意思是忽略这个变量。可以用来当作匿名变量。当它用于import中表示不导入包而只执行包的init()函数。

例如：

```go
    import "database/sql"
    import _ "github.com/go-sql-driver/mysql"
```

第二个import就是不直接使用mysql包，只是执行一下这个包的init函数，把mysql的驱动注册到sql包里，然后程序里就可以使用sql包来访问mysql数据库了。

<aside>
💡 当import中使用下划线"_"时，仅执行该包下的文件里所有init()函数都会被执行，而不是引入该包。

</aside>

### 变量的作用域

Go语言中的变量作用域可以分为以下几种情况：

- 全局作用域：在函数体外声明的变量具有全局作用域，可以在整个程序中的任何地方访问。全局变量在声明时没有被初始化的话，会被默认初始化为其类型的零值。
- 函数作用域：在函数体内声明的变量具有函数作用域，只能在函数内部访问。函数作用域的变量在函数执行结束后会被销毁。
- 块作用域：在if语句、for循环等代码块内部声明的变量具有块作用域，只能在该代码块内部访问。块作用域的变量在代码块执行结束后会被销毁。
- 包作用域：在包级别声明的变量具有包作用域，可以在整个包内的任何地方访问。包作用域的变量在程序执行期间一直存在。

全局变量声明`必须以 var 关键字开头`，如果想要在外部包中使用全局变量的`首字母必须大写`。也就是不支持简短声明。

需要注意的是，Go语言中的变量遵循就近原则，即在嵌套作用域中，内层作用域的变量会覆盖外层作用域的同名变量。如果需要在内层作用域中访问外层作用域的同名变量，可以使用限定符来指定变量的作用域。以下是一个示例代码，展示了不同作用域的变量使用方式：

```go
package main

import "fmt"

var globalVariable = 10 // 全局作用域

func main() {
    var functionVariable = 20 // 函数作用域
    fmt.Println(globalVariable) // 可以访问全局变量
    fmt.Println(functionVariable) // 可以访问函数内的变量

    if true {
        var blockVariable = 30 // 块作用域
        fmt.Println(blockVariable) // 可以访问块内的变量
        fmt.Println(functionVariable) // 可以访问外层作用域的变量
    }

    // fmt.Println(blockVariable) // 无法访问块外的变量

    anotherFunction()
}

func anotherFunction() {
    fmt.Println(globalVariable) // 可以访问全局变量
    // fmt.Println(functionVariable) // 无法访问其他函数内的变量
}
```

## Golang常量

### 常量的定义

常量的定义，使用关键词为const。不能使用:=，因此这是变量专用。使用:=省略了var关键字，即:=作为简短声明只用于变量声明而不应用于常量。

```go
const a = 64 // 定义常量值为 64 的值

const (
  b = 4
  c = 0.1
)
```

### iota常量生成器

> 常量声明可以使用 iota 常量生成器初始化，它用于生成一组以相似规则初始化的常量，但是不用每行都写一遍初始化表达式。
> 

**在一个 const 声明语句中，在第一个声明的常量所在的行，iota 将会被置为 0，然后在每一个有常量声明的行加1**

比如，定义星期日到星期六，从0-6

```go
const (
    Sunday  = iota //0
    Monday
    Tuesday
    Wednesday
    Thursday
    Friday
    Saturday  //6
)
```

## 基本数据类型

Go语言和其它语言一样，提供了基本的数据类型和复杂数据类型。本节主要介绍Go语言的基本数据类型。

![Go基本数据类型.png](Go%25E5%259F%25BA%25E6%259C%25AC%25E6%2595%25B0%25E6%258D%25AE%25E7%25B1%25BB%25E5%259E%258B.png)

如上图所示，Go语言基本数据类型主要分为布尔类型、数字类型、字符串、特殊类型四种。其中特殊类型是Go提供的不同于其它语言的类型，字符类型为rune，错误类型为error。

### 基本介绍

**1.布尔类型**

Go语言中以`bool`类型进行声明布尔型数据，布尔型数据只有`true（真）`和`false（假）`两个值。

<aside>
💡 **注意：**
    布尔类型变量的默认值为false。
    Go 语言中不允许将整型强制转换为布尔型.
    布尔型无法参与数值运算，也无法与其他类型进行转换。

</aside>

**2.数字类型**

数字类型表示整数值，根据平台的不同，可以是32位或64位。数字类型分为整型和浮点型两种。

整型分为以下两个大类： 按长度分为：`int8`、`int16`、`int32`、`int64`对应的无符号整型：`uint8`、`uint16`、`uint32`、`uint64`

其中，`uint8`就是我们熟知的`byte`型，`int16`对应C语言中的`short`型，`int64`对应C语言中的`long`型。

Go语言支持两种浮点型数：`float32`和`float64`。这两种浮点型数据格式遵循`IEEE 754`标准： `float32` 的浮点数的最大范围约为`3.4e38`，可以使用常量定义：`math.MaxFloat32`。 `float64` 的浮点数的最大范围约为 `1.8e308`，可以使用一个常量定义：`math.MaxFloat64`。

**3.字符串类型**

Go语言中的字符串以原生数据类型出现，而不是像Java一样只是一个对象，因此它使用的关键字`string`首字母为小写。 Go 语言里的字符串的内部实现使用UTF-8编码。 字符串的值为双引号(")中的内容，可以在Go语言的源码中直接添加非`ASCII`码字符，例如：

```go
string s1 = "hello"
s2 := "你好"
```

字符串常用操作如下：

| 方法 | 介绍 |
| --- | --- |
| len(str) | 求长度 |
| +或fmt.Sprintf | 拼接字符串 |
| strings.Split | 分割 |
| strings.Contains | 判断是否包含 |
| strings.HasPrefix,strings.HasSuffix | 前缀/后缀判断 |
| strings.Index(),strings.LastIndex() | 子串出现的位置 |
| strings.Join(a[]string, sep string) | join操作 |

在Go语言中，**strings**是一个标准库包，用于处理字符串相关的操作。它提供了许多函数来操作和处理字符串，包括字符串的拼接、分割、替换、查找、大小写转换等。

<aside>
💡 注意：字符串是不能修改的！因此需要借助于byte和rune类型。

</aside>

**4.byte和rune类型**

组成每个字符串的元素叫做“字符”，可以通过遍历或者单个获取字符串元素获得字符。 字符用单引号（’）包裹起来，如：

```go
    var a := '中'
    var b := 'x'
```

Go 语言的字符有以下两种：

```go
    uint8类型，或者叫 byte 型，代表了ASCII码的一个字符。
    rune类型，代表一个 UTF-8字符。
```

8位的byte只能用于英文。而中文等其它语言都是超过8字节的。因此，当需要处理中文、日文或者其他复合字符时，则需要用到`rune`类型。`rune`类型实际是一个`int32`。 Go 使用了特殊的 `rune` 类型来处理 `Unicode`，让基于 `Unicode`的文本处理更为方便，也可以使用 `byte` 型进行默认字符串处理，性能和扩展性都有照顾

<aside>
💡 byte仅适用于8位二进制的ASCII，而rune则适用于16位二进制Unicode。

</aside>

字符串底层是一个byte数组，所以可以和[]byte类型相互转换。字符串是不能修改的！字符串是由byte字节组成，所以字符串的长度是byte字节的长度。 rune类型用来表示utf8字符，一个rune字符由一个或多个byte组成。

要修改字符串，需要先将其转换成`[]rune或[]byte`，完成后再转换为`string`。无论哪种转换，都会重新分配内存，并复制字节数组。

```go
    func changeString() {
        s1 := "hello"
        // 强制类型转换
        byteS1 := []byte(s1)
        byteS1[0] = 'H'
        fmt.Println(string(byteS1))

        s2 := "博客"
        runeS2 := []rune(s2)
        runeS2[0] = '狗'
        fmt.Println(string(runeS2))
    }
```

这里初步使用了数据类型的转换。接下来我们详细介绍数据类型转换。

### 数据类型转换

Go语言中只有强制类型转换，没有隐式类型转换。该语法只能在两个类型之间支持相互转换的时候使用。

强制类型转换的基本语法如下：

```go
    T(表达式)
```

其中，T表示要转换的类型，是Go的基本数据类型。表达式包括变量、复杂算子和函数返回值等.

比如计算直角三角形的斜边长时使用math包的Sqrt()函数，该函数接收的是float64类型的参数，而变量a和b都是int类型的，这个时候就需要将a和b强制类型转换为float64类型。

```
    func sqrtDemo() {
        var a, b = 3, 4
        var c int
        // math.Sqrt()接收的参数是float64类型，需要强制转换
        c = int(math.Sqrt(float64(a*a + b*b)))
        fmt.Println(c)
    }
```

## 流程控制

在学习基本数据类型之后、学习复杂数据类型之前我们需要先学习Go的流程控制，方便我们对后续复杂数据类型的遍历问题进行探讨。

### 条件语句

条件语句需要开发者通过指定一个或多个条件，并通过测试条件是否为 true 来决定是否执行指定语句，并在条件为 false 的情况在执行另外的语句。

**1.if语句**

Go 编程语言中 if 语句的语法如下：

```
    • 可省略条件表达式括号。
    • 持初始化语句(即在if上定义变量)，可定义代码块局部变量。
    • 代码块左 括号必须在条件表达式尾部。

    if 布尔表达式 {
    /* 在布尔表达式为 true 时执行 */
    }

```

if 在布尔表达式为 true 时，其后紧跟的语句块执行，如果为 false 则不执行。

```go
x := 0

// if x > 10        // Error: missing condition in if statement
// {
// }

if n := "abc"; x > 0 {     // 初始化语句未必就是定义变量， 如 println("init") 也是可以的。
    println(n[2])
} else if x < 0 {    // 可以在 if 或 else if 语句中嵌入一个或多个 if 或 else if 语句。
	println(n[1])									 
} else {             // 注意 else if 和 else 左大括号位置。
    println(n[0])
}
```

**2.switch语句**

switch 语句用于基于不同条件执行不同动作，每一个 case 分支都是唯一的，从上直下逐一测试，直到匹配为止。 Golang switch 分支表达式可以是任意类型，不限于常量。可省略 break，默认自动终止。

Go 编程语言中 switch 语句的语法如下：

```go
switch var1 {
    case val1:
        ...
    case val2:
        ...
    default:
        ...
}

```

变量 var1 可以是任何类型，而 val1 和 val2 则可以是同类型的任意值。类型不被局限于常量或整数，但必须是相同的类型；或者最终结果为相同类型的表达式。 您可以同时测试多个可能符合条件的值，使用逗号分割它们，例如：case val1, val2, val3。

**3.select语句**

select 语句类似于 switch 语句，但是select会随机执行一个可运行的case。如果没有case可运行，它将阻塞，直到有case可运行。

select 是Go中的一个控制结构，类似于用于通信的switch语句。每个case必须是一个通信操作，要么是发送要么是接收。 select 随机执行一个可运行的case。如果没有case可运行，它将阻塞，直到有case可运行。一个默认的子句应该总是可运行的。

Go 编程语言中 select 语句的语法如下：

```go
select {
    case communication clause  :
       statement(s);
    case communication clause  :
       statement(s);
    /* 你可以定义任意数量的 case */
    default : /* 可选 */
       statement(s);
}
```

以下描述了 select 语句的语法：

```
    每个case都必须是一个通信
    所有channel表达式都会被求值
    所有被发送的表达式都会被求值
    如果任意某个通信可以进行，它就执行；其他被忽略。
    如果有多个case都可以运行，Select会随机公平地选出一个执行。其他不会执行。
    否则：
    如果有default子句，则执行该语句。
    如果没有default字句，select将阻塞，直到某个通信可以运行；Go不会重新对channel或值进行求值。
```

select是Go中的一个控制结构，类似于switch语句，用于处理异步IO操作。select会监听case语句中channel的读写操作，当case中channel读写操作为非阻塞状态（即能读写）时，将会触发相应的动作。 select中的case语句必须是一个channel操作

### 循环语句

不同于其它语言，Go语言不提供while循环那样的关键字，仅提供for关键字来进行循环。要想实现while效果必须使用for替换。

**1.for语句**

Go语言的For循环有3中形式，只有其中的一种使用分号。

```go
    for init; condition; post { }
    for condition { }
    for { }
    init： 一般为赋值表达式，给控制变量赋初值；
    condition： 关系表达式或逻辑表达式，循环控制条件；
    post： 一般为赋值表达式，给控制变量增量或减量。
    for语句执行过程如下：
    ①先对表达式 init 赋初值；
    ②判别赋值表达式 init 是否满足给定 condition 条件，若其值为真，满足循环条件，则执行循环体内语句，然后执行
```

例如：

```go
s := "abc"

for i, n := 0, len(s); i < n; i++ { // 常见的 for 循环，支持初始化语句。
    println(s[i])
}

n := len(s)
for n > 0 {                // 替代 while (n > 0) {}
    println(s[n])        // 替代 for (; n > 0;) {}
    n--
}

for {                    // 替代 while (true) {}
    println(s)            // 替代 for (;;) {}
```

Go语言使用for关键字来实现和while相同的效果，具体操作如下：

```go
package main

import "fmt"

func main() {
    i := 0
    for i < 5 {
        fmt.Println(i)
        i++
    }
}
```

**2.range语句**

和Python提供range函数类似，Go提供range关键字来快速返回索引及其值。这个语句一般用于复杂数据类型如数组等上，方便快速提取索引及其对应的值。

for 循环的 range 格式可以对 slice、map、数组、字符串等进行迭代循环。格式如下：

```go
for key, value := range oldMap {
    newMap[key] = value
}

eg:
		s := "abc"
    // 忽略 2nd value，支持 string/array/slice/map。
    for i := range s {
        println(s[i])
    }
    a := [5,6,2,4,1]
		for key, value := range a {
        println(key,value)
    }
		// 可忽略不想要的返回值，或 "_" 这个特殊变量。
		// 忽略 index。
    for _, c := range a {
        println(c)
    }
```

**3.循环控制**

在Go语言中，有三种循环控制语句：`goto`、`break`和`continue`。

- `goto`语句用于无条件地跳转到程序中的某个标签。它的使用被广泛认为是一种不良的编程实践，因为它会导致代码变得难以理解和维护。因此，在大多数情况下，应该避免使用`goto`语句。
    
    下面是一个使用`goto`语句的示例：
    
    ```go
    func main() {
        i := 0
    LOOP:
        fmt.Println(i)
        i++
        if i < 10 {
            goto LOOP
        }
    }
    
    ```
    
    在上面的示例中，`goto`语句被用来跳转到标签`LOOP`，从而实现了循环输出数字0到9。
    
- `break`语句用于立即终止当前循环，并跳出循环体。它通常与条件语句结合使用，用于提前结束循环。
    
    下面是一个使用`break`语句的示例：
    
    ```go
    func main() {
        for i := 0; i < 10; i++ {
            if i == 5 {
                break
            }
            fmt.Println(i)
        }
    }
    
    ```
    
    在上面的示例中，当`i`的值等于5时，`break`语句被执行，循环被终止。
    
- `continue`语句用于立即跳过当前循环的剩余代码，并开始下一次循环迭代。它通常与条件语句结合使用，用于跳过某些特定的迭代。
    
    下面是一个使用`continue`语句的示例：
    
    ```go
    func main() {
        for i := 0; i < 10; i++ {
            if i%2 == 0 {
                continue
            }
            fmt.Println(i)
        }
    }
    
    ```
    
    在上面的示例中，当`i`的值为偶数时，`continue`语句被执行，当前迭代的剩余代码被跳过，开始下一次迭代。
    

需要注意的是，尽管`goto`、`break`和`continue`语句在某些情况下可能会有用，但过度使用它们可能会导致代码变得难以理解和维护。因此，在编写代码时，应该谨慎使用这些循环控制语句，并尽量使用更清晰和结构化的代码逻辑来实现相同的功能。

## 复杂数据类型

![Go复杂基本数据类型.png](Go%25E5%25A4%258D%25E6%259D%2582%25E5%259F%25BA%25E6%259C%25AC%25E6%2595%25B0%25E6%258D%25AE%25E7%25B1%25BB%25E5%259E%258B.png)

主要有数组、切片(slice)、映射(map)、自定义类型(type)、结构体(struct)、函数(func)、方法、接口8个类型。另外还有一个并发操作类型——通道(channel)

### 数组

**1.基本定义**

数组是固定长度，其使用与C语言基本一致。另外类型后置的意思就是类型放在最后面

```go
//数组定义：var a [len]int len是常量，一旦定义完成，长度将保持不变
var a [20]int;
var b = [20]int{1,2,3,4,5,6}
//如果不写数据数量，而使用...，表示数组的长度是根据初始化值的个数来计算
arr := [...]int{1,2,3}
```

**2.数组遍历**

在Go语言中，可以使用`for`循环来遍历数组。以下是一个示例：

```go
package main

import "fmt"

func main() {
    // 定义一个整数数组
    numbers := [5]int{1, 2, 3, 4, 5}

    // 使用for循环遍历数组
    for i := 0; i < len(numbers); i++ {
        fmt.Println(numbers[i])
    }
}

```

在上面的示例中，我们定义了一个包含5个整数的数组`numbers`。然后，使用`for`循环遍历数组，并使用`fmt.Println`函数打印每个数组元素的值。

另外，Go语言还提供了一种更简洁的方式来遍历数组，使用`range`关键字。以下是使用`range`关键字遍历数组的示例：

```go
package main

import "fmt"

func main() {
    // 定义一个整数数组
    numbers := [5]int{1, 2, 3, 4, 5}

    // 使用range关键字遍历数组
    for index, value := range numbers {
        fmt.Println(index, value)
    }
}

```

在上面的示例中，`range`关键字返回数组的索引和对应的值，然后我们可以在循环体中使用这些值。

**3.多维数组**

```go
全局
    var arr0 [5][3]int
    var arr1 [2][3]int = [...][3]int{{1, 2, 3}, {7, 8, 9}}
 局部：
    a := [2][3]int{{1, 2, 3}, {4, 5, 6}}
    b := [...][2]int{{1, 1}, {2, 2}, {3, 3}} // 第 2 纬度不能用 "..."。
```

**4.数组做参**

数组作为参数进行值传递，例如：

```go
package main

import "fmt"

// 函数接受一个整数数组作为参数，并打印数组中的元素
func printArray(arr []int) {
    for _, num := range arr {
        fmt.Println(num)
    }
}

func main() {
    // 创建一个整数数组
    arr := []int{1, 2, 3, 4, 5}

    // 调用函数并传递数组作为参数
    printArray(arr)
}
```

将arr数组作为参数传给函数printArray，实际是将值传给形参，这样形参的值改变并不影响实参arr。和C语言一样，Go数组支持指针传参，同时Go还提供了切片的概念，借助引用传参。

下面我们暂时只介绍指针传参：(关于实参、形参以及引用传递的具体做法在函数节还会详细说明)

```go
package main

import "fmt"

func printArr(arr *[5]int) {
    arr[0] = 10
    for i, v := range arr {
        fmt.Println(i, v)
    }
}

func main() {
    var arr1 [5]int
    printArr(&arr1)//把arr1的地址作为实参数传给形参
}
```

形参作为指针，将地址传送并复制给该指针，指针能够很轻松的遍历和使用。这里注意*号位置，和C++类似，*号位于类型上，则指针取值时不用再加*号。

### 切片

**1.基本定义**

需要说明，slice 并不是数组或数组指针。它通过内部指针和相关属性引用数组片段，以实现动态长度方案。切片的本质就是对数组进行切割，它是一个指针指向一个底层的数组。因此它必须依赖数组才能建立，此时我们可以使用简短声明的方式来指定

```go
a := [20]int{1,2,3,4,5,6}
b := a[2:5] //这里我们要知道切片采用左闭右开原则。如果想包含端部元素，则使用[2:]类似操作即可
```

关于切片规则大致参考Python，它大致如下：

![Untitled](Untitled%20192.png)

**2.通过make来创建切片**

make()函数可以用于创建切片和map，它通过基于某些符合条件的值生成，可以使用简短声明进行使用。我们后面介绍Map时也可以注意make()函数的使用。

```go
		var slice []type = make([]type, len)
    slice  := make([]type, len)
    slice  := make([]type, len, cap)
```

使用 make 动态创建slice，避免了数组必须用常量做长度的麻烦。还可用指针直接访问底层数组，退化成普通数组操作。

**3.切片追加**

Go语言使用append实现切片的拼接与追加。

```go
package main

import (
    "fmt"
)

func main() {

    var a = []int{1, 2, 3}
    fmt.Printf("slice a : %v\n", a)
    var b = []int{4, 5, 6}
    fmt.Printf("slice b : %v\n", b)
    c := append(a, b...)
    fmt.Printf("slice c : %v\n", c)
    d := append(c, 7)
    fmt.Printf("slice d : %v\n", d)
    e := append(d, 8, 9, 10)
    fmt.Printf("slice e : %v\n", e)

}
```

输出结果为：

```go
		slice a : [1 2 3]
    slice b : [4 5 6]
    slice c : [1 2 3 4 5 6]
    slice d : [1 2 3 4 5 6 7]
    slice e : [1 2 3 4 5 6 7 8 9 10]
```

在Go语言中，**%v**是一个格式化占位符，用于打印变量的默认格式。它可以用于各种数据类型，包括基本数据类型、结构体、切片、映射等。

append ：向 slice 尾部添加数据，返回新的 slice 对象。

****4.slice中cap重新分配规律****

在Go语言中，切片（slice）是对数组的一个引用，它包含了指向数组的指针、切片的长度和切片的容量。切片的容量（capacity）表示切片底层数组的长度，即切片可以扩展的最大长度。

当切片的长度超过了其容量时，Go语言会自动为切片分配一个新的底层数组，并将原有的元素复制到新的数组中。这个过程称为切片的重新分配（re-slicing）。

切片的重新分配规律如下：

- 当切片的长度小于等于其容量时，对切片进行追加操作，不会触发重新分配。切片的长度会增加，但容量保持不变。
- 当切片的长度超过其容量时，对切片进行追加操作，会触发重新分配。Go语言会创建一个新的底层数组，并将原有的元素复制到新的数组中。新切片的长度会增加，容量会根据策略进行调整。
    - 如果原切片的容量小于1024，则新切片的容量会扩大为原容量的2倍。
    - 如果原切片的容量大于等于1024，则新切片的容量会扩大为原容量的1.25倍。

这种重新分配的策略可以有效地减少内存的浪费，并提高切片的性能。但需要注意的是，切片的重新分配会导致原有的切片和底层数组的引用失效，因此在重新分配后，原切片和新切片将引用不同的底层数组。

### 映射

map的定义、map的初始化、常见操作、make和delete函数。

map是一种无序的基于key-value的Hash数据结构，Go语言中的map是引用类型，必须初始化才能使用。类似于python的字典。所谓无序就是实际排序和插入顺序是不同的。

**初始化问题**

```go
//后置类型声明
var cMap map[string]int
cMap["test"] = 12
//结果报错
```

我们要注意go语言中的空对象nil。在上述声明中实际上生成的就是nil，不能直接创建键值。正确写法如下：

```go
//使用make进行初始化,make可以使用简短声明进行搭配
cMap := make(map[string]int)
cMap["test"] = 1
//正常运行，添加键值对<test,1>
```

对于map最好指定容器长度，可以有效增加容器map的性能。

```go
// 指定初始容量
cMap = make(map[string]int, 100)
cMap["北京"] = 1
```

**map的基本操作**

```go
cMap := map[string]int{}

cMap["北京"] = 1 //写

code := cMap["北京"] // 读
fmt.Println(code)

code = cMap["广州"]  // 读不存在 key
fmt.Println(code)

code, ok = cMap["广州"]  // 检查 key 是否存在
if ok {
  fmt.Println(code)  
} else {
  fmt.Println("key not exist")  
}

delete(cMap, "北京") // 删除 key
fmt.Println("北京")
```

**map的嵌套**

var cMap map[string]map[string,int]。我们也可以看出来map的键只支持基本数据类型，复杂数据类型不支持。

### 结构体

Go语言中没有“类”的概念，也不支持“类”的继承等面向对象的概念。Go语言中通过结构体的内嵌再配合接口比面向对象具有更高的扩展性和灵活性。和其它语言一样，结构体的定义用到了核心关键字`type`。

**1.类型别名与自定义类型**

- 自定义类型

在Go语言中有一些基本的数据类型，如string、整型、浮点型、布尔等数据类型，Go语言中可以使用type关键字来定义自定义类型。

自定义类型是定义了一个全新的类型。我们可以基于内置的基本类型定义，也可以通过struct定义。例如：

```
    //将MyInt定义为int类型
    type MyInt int
```

通过Type关键字的定义，MyInt就是一种新的类型，它具有int的特性。

- 类型别名

类型别名是Go1.9版本添加的新功能。

类型别名规定：TypeAlias只是Type的别名，本质上TypeAlias与Type是同一个类型。就像一个孩子小时候有小名、乳名，上学后用学名，英语老师又会给他起英文名，但这些名字都指的是他本人。

```go
    type TypeAlias = Type
```

我们之前见过的rune和byte就是类型别名，他们的定义如下：

```go
    type byte = uint8
    type rune = int32
```

- 两者区别

类型别名与类型定义表面上看只有一个等号的差异，我们通过下面的这段代码来理解它们之间的区别。

```go
//类型定义
type NewInt int

//类型别名
type MyInt = int

func main() {
    var a NewInt
    var b MyInt

    fmt.Printf("type of a:%T\n", a) //type of a:main.NewInt
    fmt.Printf("type of b:%T\n", b) //type of b:int
}

```

结果显示a的类型是main.NewInt，表示main包下定义的NewInt类型。b的类型是int。MyInt类型只会在代码中存在，编译完成时并不会有MyInt类型。

**2.结构体定义**

Go语言提供了一种自定义数据类型，可以封装多个基本数据类型，这种数据类型叫结构体，英文名称struct。 也就是我们可以通过struct来定义自己的类型了。Go语言中通过struct来实现面向对象。

<aside>
💡 结构体实际上就是一种自定义类型，但是它增加了新的关键字struct。

</aside>

具体声明格式如下：

```go
type 类型名 struct {
        字段名 字段类型
        字段名 字段类型
        …
    }

//eg:

type student struct {
	Age int
  Name string
  City,Car string
}
```

就像语句没有使用分号隔开一样，对象内部也不使用逗号隔开。

**3.结构体实例化**

只有当结构体实例化时，才会真正地分配内存。也就是必须实例化后才能使用结构体的字段。

结构体本身也是一种类型，我们可以像声明内置类型一样使用var关键字声明结构体类型。

```go
 定义：var 结构体实例 结构体类型

eg:

type person struct {
    name string
    city string
    age  int8
}

func main() {

		//属性法实现实例化
    var p1 person
    p1.name = "pprof.cn"
    p1.city = "北京"
    p1.age = 18
		//构造法实现实例化
		p2 := person("pprof.cn","北京",18)
    fmt.Printf("p1=%v\n", p1)  //p1={pprof.cn 北京 18}
    fmt.Printf("p1=%#v\n", p1) //p1=main.person{name:"pprof.cn", city:"北京", age:18}
		fmt.Printf("p1=%v\n", p2)  //p1={pprof.cn 北京 18}
    fmt.Printf("p1=%#v\n", p2) //p1=main.person{name:"pprof.cn", city:"北京", age:18}
}

除了上述方式外，结构体可以像基本数据类型一样，定义时完成初始化，只不过是直接生成对象，而结构体不能再赋值

p5 := person{
    name: "pprof.cn",
    city: "北京",
    age:  18,
}
fmt.Printf("p5=%#v\n", p5) //p5=main.person{name:"pprof.cn", city:"北京", age:18}
```

**4.结构体标签（Tag）**

Tag是结构体的元信息，可以在运行的时候通过反射的机制读取出来。

Tag在结构体字段的后方定义，由一对反引号包裹起来，具体的格式如下：

```go
    `key1:"value1" key2:"value2"`
```

结构体标签由一个或多个键值对组成。键与值使用冒号分隔，值用双引号括起来。键值对之间使用一个空格分隔。 注意事项： 为结构体编写Tag时，必须严格遵守键值对的规则。结构体标签的解析代码的容错能力很差，一旦格式写错，编译和运行时都不会提示任何错误，通过反射也无法正确取值。例如不要在key和value之间添加空格。

结构体标签的常见用途包括：

- 序列化和反序列化：结构体标签可以用于指定字段在进行序列化和反序列化时的名称、格式或其他规则。例如，可以使用标签指定字段在 JSON 或 XML 中的名称，或者指定字段的数据类型。
- 数据验证：结构体标签可以用于验证字段的值是否符合特定的规则或约束。例如，可以使用标签指定字段的最小值、最大值或正则表达式等。
- ORM（对象关系映射）：结构体标签可以用于将结构体字段映射到数据库表的列。ORM 框架可以使用这些标签来自动执行数据库操作。

在Go语言中，结构体的字段可以使用json标签来指定在JSON序列化和反序列化过程中的字段名称和行为。json标签是一个结构体字段的元数据，用于定义与JSON相关的属性。也就是说，当我们进行序列化和反序列化时，相关操作会读取tag元数据，判断每个字段的json标签并按照要求进行序列化和反序列化。

json标签的基本语法是json:"tag"，其中tag是一个字符串，可以包含多个逗号分隔的选项。以下是一些常用的选项：

- omitempty：如果字段的值为空值（零值或空切片/映射/指针等），则在序列化时忽略该字段。
- string：将字段的值序列化为JSON字符串。
- "-"：忽略该字段，不进行序列化和反序列化。
- omitempty,string：如果字段的值为空值，则在序列化时忽略该字段；将非空值序列化为JSON字符串。

```go
type Person struct {
Name   string `json:"name"`
Age    int    `json:"age,omitempty"`
Email  string `json:"email,omitempty"`
Active bool   `json:"-"`
}
```

json标签主要用于序列化，下面我们开始介绍结构体序列化过程。

**5.结构体序列化**

结构体的序列化是指将结构体对象转换为可以存储或传输的格式，如JSON、XML、Protobuf等。这样可以方便地将结构体数据进行持久化存储、网络传输或与其他系统进行交互。我们在前后端进行数据交互时必须借助于json字符串来进行传输。一个结构体序列化的全过程：

```go
package main

import (
"encoding/json"
)

//1.定义结构体
type IndexData struct{
  Title string 'json:"Title"' //借助json标签对序列化过程中键进行说明
  Desc string 'json:"Desc"'
}

var indexData IndexData
indexData.Title="index"
indexData.Desc="首页"

// 调用方法json.Marshal()，序列化为JSON字符串
jsonData , error = json.Marshal(indexData)

// 调用方法json.UnMarshal()，反序列化为JSON字符串
var newPerson IndexData
err = json.Unmarshal(jsonData, &newPerson)
```

在Go中最常用的序列化方法是引入标准库中的`encoding/json`包，在上述示例中，我们定义了一个IndexData 结构体，并使用`json`标签指定了JSON字段的名称。通过调用`json.Marshal`函数可以将Person结构体对象序列化为JSON字符串，而`json.Unmarshal`函数可以将JSON字符串反序列化为Person结构体对象。

**6.结构体方法**

Golang实际上不是严格意义的面向对象语言，因此它使用struct来实现Object这一类型。我们知道类的内部可以定义方法，而结构体内部只能定义属性。因此，go在设计上采用的就是函数定义时绑定对应的结构体的方式来实现方法。在学完Go基础知识之后，我们将对Golang面向对象编程进行专门的扩展与讲解。

## Go函数

### 函数声明

函数声明包含一个函数名，参数列表， 返回值列表和函数体。如果函数没有返回值，则返回列表可以省略。函数从第一条语句开始执行，直到执行return语句或者执行函数的最后一条语句。

函数可以没有参数或接受多个参数。

注意类型在变量名之后 。

当两个或多个连续的函数命名参数是同一类型，则除了最后一个类型之外，其他都可以省略。

函数可以返回任意数量的返回值。

使用关键字 `func` 定义函数，左大括号依旧不能另起一行。

```go
func multi(a,b int)(string,int,int,bool){
				// 类型相同的相邻参数，参数类型可合并。 多返回值必须用括号。
        return a+b,a-b,a*b,a/b //这里不使用分号

}

Go函数特点：
		• 无需声明原型。
    • 支持不定 变参。
    • 支持多返回值。
    • 支持命名返回参数。 
    • 支持匿名函数和闭包。
    • 函数也是一种类型，一个函数可以赋值给变量。

    • 不支持 嵌套 (nested) 一个包不能有两个名字一样的函数。
    • 不支持 重载 (overload) 
    • 不支持 默认参数 (default parameter)。
```

函数的参数也是可以写的，都是类型后置就可以了，上面就是(name string,age int,size int,isMan bool)

### 函数参数

**1.形参与实参**

函数定义时指出，函数定义时有参数，该变量可称为函数的形参。形参就像定义在函数体内的局部变量。但当调用函数，传递过来的变量就是函数的实参，函数可以通过两种方式来传递参数：值传递和引用传递。

值传递：指在调用函数时将实际参数复制一份传递到函数中，这样在函数中如果对参数进行修改，将不会影响到实际参数。也就是形参只是拷贝了实参的值，在函数体中改变形参的值不会影响的形参。

引用传递：是指在调用函数时将实际参数的地址传递到函数中，那么在函数中对参数所进行的修改，将影响到实际参数。也就是说形参拷贝的是实参的地址，在函数体中借助地址找到实参所存储的值进行更改。

> 在数组章节中就简单介绍了数组做参数时是值传递，我们可以使用指针直接实现地址的传输，不过，一般推荐使用slice引用的方式进行引用传参。
> 

引用传参如下：

```go
package main

import (
    "fmt"
)

/* 定义相互交换值的函数 */
func swap(x, y *int) {
    var temp int

    temp = *x /* 保存 x 的值 */
    *x = *y   /* 将 y 值赋给 x */
    *y = temp /* 将 temp 值赋给 y*/

}

func main() {
    var a, b int = 1, 2
    /*
        调用 swap() 函数
        &a 指向 a 指针，a 变量的地址
        &b 指向 b 指针，b 变量的地址
    */
    swap(&a, &b)

    fmt.Println(a, b)
}
```

<aside>
💡 无论是值传递，还是引用传递，传递给函数的都是变量的副本，不过，值传递是值的拷贝。引用传递是地址的拷贝，一般来说，地址拷贝更为高效。而值拷贝取决于拷贝的对象大小，对象越大，则性能越低。

</aside>

**2.可变参数**

Golang的参数可以不用规定个数。可变参数本质上就是 slice。只能有一个，且必须是最后一个。因此参数类型必须一致，且数量动态时，可以使用动态参数函数的。具体用法如下：

```go
	func myfunc(args ...int) {    //0个或多个参数
  }

  func add(a int, args…int) int {    //1个或多个参数
  }

  func add(a int, b int, args…int) int {    //2个或多个参数
  }
```

这里args就是slice变量。可以通过arg[index]依次访问所有参数,通过len(arg)来判断传递参数的个数。

### 返回值

这里主要说明，可以使用`"_"`标识符，用来忽略函数的某个返回值：

```go
package main

func test() (int, int) {
    return 1, 2
}

func main() {
    // s := make([]int, 2)
    // s = test()   // Error: multiple-value test() in single-value context

    x, _ := test()
    println(x)
}
```

### **匿名函数**

和JavaScript类似，Go语言也提供匿名函数。匿名函数是指不需要定义函数名的一种函数实现方式。匿名函数由一个不带函数名的函数声明和函数体组成。匿名函数的优越性在于可以直接使用函数内的变量，不必申明。不过，它往往只用一次的简单测试。

```go
package main

import (
    "fmt"
    "math"
)

func main() {
    getSqrt := func(a float64) float64 {
        return math.Sqrt(a)
    }
    fmt.Println(getSqrt(4))
}
```

我们具体参考文档如下：

[函数 · Golang学习笔记](https://www.k8stech.net/go-book/ch5/function.html)

### 访问权限

和Java采用关键字来规定访问权限不同，Go语言对名字进行了规范来设定访问权限。Go语言变量、结构体属性、函数、结构体方法命名首字母规定了访问权限。当首字母为大写时则为公开public；当首字母为小写时，则为私有private。

例如：

```go
package mypackage

func PublicFunction() {
    // 可以在包外部访问
}

func privateFunction() {
    // 只能在包内部访问
}
```

在其他包中，可以通过包名和标识符来访问公开的函数：

```go
package main

import "mypackage"

func main() {
    mypackage.PublicFunction() // 可以访问
    mypackage.privateFunction() // 无法访问，会报错
}
```

需要注意的是，即使在同一个包内部，私有函数也只能在定义它们的文件中访问，而不能在其他文件中访问。这是为了保持代码的清晰性和封装性。

## Go异常处理

在Go语言中，异常处理采用了一种不同于传统的异常处理机制，它主要包括defer、recover、panic三个关键字。Golang 没有结构化异常，使用 panic 抛出错误，recover 捕获错误。

异常的使用场景简单描述：Go中可以抛出一个panic的异常，然后在defer中通过recover捕获这个异常，然后正常处理。

### 延迟调用(defer)

defer"延迟"，用来声明一个延迟调用函数，该函数可以是匿名函数也可以是具名函数。defer将延迟调用函数延迟到主函数的return执行之后。在下面的说明中，我们将函数体中包含defer的函数暂时称为方法，与延迟调用函数相区分，在该方法内部使用defer延迟调用函数。

```go
func someFunction() {
    defer cleanup() // 延迟执行cleanup函数
    // 函数的其他代码
}
```

在上述代码中someFunction函数现在被称为方法以和cleanup函数进行区分。

![Untitled](Untitled%20193.png)

我们可以看到：1.defer只要在方法中被使用，无论方法如何结束都会执行。但如果异常发生在defer之前导致defer没有被使用，则不会执行。因此处理异常中defer往往在方法顶部使用。2.defer执行顺序类似于栈结构，先延迟的后执行。3.延迟调用函数参数会进行预计算。4.延迟调用函数的执行时间，方法return之后，但是在返回参数到调用方法之前。

正是因为defer作为在return之后必然会执行的函数，因此用它来处理方法存在的异常。（它相当于在尾部使用recover进行接收panic，然后执行相关的处理）

### 抛出异常(panic)

**1.错误及其处理**

在Go中，函数可以返回一个额外的错误值，用于表示函数执行过程中是否发生了异常情况。通常，函数的最后一个返回值是一个`error`类型，用于表示错误。如果函数执行成功，错误值为**nil**；如果函数执行失败，错误值为一个非`nil`的错误对象。

```go
//定义函数
func divide(a, b int) (int, error) {
    if b == 0 {
        return 0, fmt.Errorf("除数不能为零")
    }
    return a / b, nil
}

///错误检查
result, err := divide(10, 0)
if err != nil {
    log.Println("除法操作失败:", err) //错误处理：使用log.Println函数记录错误信息
} else {
    fmt.Println("结果:", result)
}
```

在上面的例子中，divide函数返回两个值：商和错误。如果除数**b**为零，函数会返回一个非**nil**的错误对象，表示除法操作失败。

除了系统自己产生异常之外，Go还可以允许我们自定义错误：

```go
package main

import (
"errors"
"fmt"
)

type MyError struct {
	message string
}

func (e *MyError) Error() string {
	return e.message
}

func divide(a, b int) (int, error) {
	if b == 0 {
	return 0, &MyError{"division by zero"}
	}
	return a / b, nil
}

func main() {
result, err := divide(10, 0)
	if err != nil {
	fmt.Println("Error:", err)
} else {
	fmt.Println("Result:", result)
}
}
```

无论是自定义还是系统的错误都需要进行抛出。通过抛出程序将可以继续运行，执行中断程序的正常执行流程而不是意外停止。

**2.抛出异常**

在Go语言中，`panic`用于引发（panic）一个运行时异常。当程序遇到无法处理的错误或异常情况时，可以使用`panic`来中断程序的正常执行流程，并触发一个运行时错误。

以下是`panic`的一些特点和用法：

- `panic`的语法：使用`panic`关键字后跟一个表达式或值。

```go
func someFunction() {
    if someCondition {
        panic("发生了错误") //实际上产生一个带有“发生了错误”信息的error，由panic抛出
    }
    // 函数的其他代码
}
```

- `panic`的执行：当程序执行到`panic`语句时，会立即停止当前函数的执行，并开始沿着调用栈向上寻找延迟（defer）函数。如果没有被恢复（recover）的`panic`，程序会终止并打印出错误信息。
- `panic`的错误信息：`panic`可以接受一个参数，该参数可以是任何实现了`error`接口的类型，通常是一个字符串。当`panic`发生时，该参数的值会被打印出来作为错误信息。

```go
func someFunction() {
    err := someOperation()
    if err != nil {
        panic(err)
    }
    // 函数的其他代码
}
```

在上面的例子中，如果`someOperation`返回一个非`nil`的错误，`panic`会触发并打印出该错误信息。

### recover

在Go语言中，`recover`用于恢复（recover）一个被触发的`panic`。当程序遇到`panic`时，可以使用`recover`来捕获该`panic`，并在延迟函数中进行处理，从而避免程序的终止。

以下是`recover`的一些特点和用法：

- `recover`的语法：使用`recover`函数来捕获`panic`，通常在延迟函数中使用。

```go
func someFunction() {
    defer func() {
        if r := recover(); r != nil {
            // 处理panic
        }
    }()
    // 可能引发panic的代码
}
```

- `recover`的执行：当程序执行到`recover`函数时，会检查是否有未被恢复的`panic`。如果有，`recover`会停止`panic`的传播，并返回`panic`的值。如果没有未被恢复的`panic`，`recover`会返回`nil`。
- `recover`的用途：`recover`通常用于在延迟函数中处理`panic`，以便程序可以继续执行而不是终止。可以根据需要在延迟函数中进行一些错误处理、日志记录或其他操作。

```go
func someFunction() {
    defer func() {
        if r := recover(); r != nil {
            fmt.Println("发生了panic:", r)
            // 其他处理操作
        }
    }()
    // 可能引发panic的代码
}
```

在上面的例子中，如果发生了`panic`，`recover`会捕获该`panic`并打印出错误信息，然后程序会继续执行延迟函数中的其他处理操作。

需要注意的是，`recover`只能在延迟函数中使用。如果在非延迟函数中使用`recover`，它将返回`nil`，并且不会停止`panic`的传播。

通过使用`recover`，可以在程序遇到`panic`时进行适当的处理，从而提高程序的健壮性和可靠性。

## 笔记结语

通过这篇笔记，我们学到了很多关于Go语言的知识。我们了解了如何设置Go开发环境，掌握了简单\复杂类型的变量和它们的用法，学会了使用流程控制语句来控制程序的执行流程。我们还学习了Go函数、方法、结构体的概念以及面向对象编程。通过这些内容的学习，我希望读者能够掌握Go语言的基础知识，并能够开始编写简单的Go程序。

一路走来，我要感谢所有阅读这篇笔记的读者。你们的支持和关注是我写作的动力。我希望这篇笔记能够帮助你们入门Go语言，并为你们在日常开发中提供一些指导和帮助。

欢迎读者提出批评和指正。我们知道，没有完美的书籍，这个笔记也可能会犯错或遗漏一些重要的内容。因此，非常希望听到你们的反馈和建议，以便我们不断改进和完善这本书。

最后，我们想向那些对Go语言感兴趣的读者推荐下一步的学习材料：《Go并发笔记》。并发编程是Go语言的一大特色，它的并发原语和轻量级线程（goroutine）模型使其非常适合构建高性能和可扩展的应用程序。通过学习并发编程，你将能够充分发挥Go语言的优势，并构建出更加强大和高效的应用程序。

感谢你们的阅读和支持！祝愿大家在Go语言的学习和实践中取得成功！