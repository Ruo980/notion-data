# Docker

[Docker官网](https://www.docker.com/)

[Docker中文文档](https://docker-practice.github.io/zh-cn/)

[Docker学习视频](https://www.bilibili.com/video/BV1wQ4y1Y7SE/?spm_id_from=333.999.0.0&vd_source=1ff3d91e5fc304c43204d473b2b897df)

[Docker30分钟学习](https://www.bilibili.com/video/BV14s4y1i7Vf/?vd_source=1ff3d91e5fc304c43204d473b2b897df)

## 什么是Docker

本节主要包含项目部署方式的演变，交代容器化部署的优势，进而引出docker运行时、容器管理工具。

### 项目部署的演变

[官方文档说明](https://kubernetes.io/zh-cn/docs/concepts/overview/)

![Untitled](Untitled%208.png)

**1.传统部署时代：**

早期，各个组织是在物理服务器上运行应用程序。 由于无法限制在物理服务器中运行的应用程序资源使用，因此会导致资源分配问题。 例如，如果在同一台物理服务器上运行多个应用程序， 则可能会出现一个应用程序占用大部分资源的情况，而导致其他应用程序的性能下降。 一种解决方案是将每个应用程序都运行在不同的物理服务器上， 但是当某个应用程序资源利用率不高时，剩余资源无法被分配给其他应用程序， 而且维护许多物理服务器的成本很高。

**2.虚拟化部署时代：**

因此，虚拟化技术被引入了。虚拟化技术允许你在单个物理服务器的 CPU 上运行多台虚拟机（VM）。 虚拟化能使应用程序在不同 VM 之间被彼此隔离，且能提供一定程度的安全性， 因为一个应用程序的信息不能被另一应用程序随意访问。

虚拟化技术能够更好地利用物理服务器的资源，并且因为可轻松地添加或更新应用程序， 而因此可以具有更高的可扩缩性，以及降低硬件成本等等的好处。 通过虚拟化，你可以将一组物理资源呈现为可丢弃的虚拟机集群。

每个 VM 是一台完整的计算机，在虚拟化硬件之上运行所有组件，包括其自己的操作系统。

**3.容器部署时代：**

容器类似于 VM，但是更宽松的隔离特性，使容器之间可以共享操作系统（OS）。 因此，容器比起 VM 被认为是更轻量级的。且与 VM 类似，每个容器都具有自己的文件系统、CPU、内存、进程空间等。 由于它们与基础架构分离，因此可以跨云和 OS 发行版本进行移植。

### 传统项目部署

![Untitled](Untitled%209.png)

如上图，被红圈住的就是采用典型的传统部署方式：将dangdang和yingxue部署到Linux服务器中，其中dangdang项目使用了redis、mysql、es三个软件服务。而ying学则部署了除这三个软件服务外还使用了mq、mogon共五个软件服务。传统方式存在以下问题：

- 如果yingxue和dangdang需要的MySQL版本不一致。这可能造成应用无法运行（版本不一致）。
- 如果这两个项目中有一个极度占用某一软件服务资源，可能造成软件服务无法提供给其它项目（资源抢占）。
- 在一个服务器中安装部署一个项目及其运行环境是费时的，如果项目需要大范围部署，则无疑大大增加工作量（环境部署复杂）。

传统部署方式进行了改进，提出了虚拟机的概念，很好的解决了上述缺点。在一个主机上使用虚拟机将两个项目进行分开，一个虚拟机中部署一个项目及支持其运行的运行时(运行时就是运行环境，包含各种需要的软件服务)。而虚拟机中环境完全不依赖外部环境，相互独立工作，不会发生资源的抢占。同时正如Java JVM实现跨平台一样，我们也可以实现虚拟机的跨平台迁移。不过虚拟机本身也存在诸多的问题（在后面Docker对比中会详细说明），因此提出了新的概念——容器。而Docker就是目前最流行的容器技术。

### 什么是容器？

在下文中要注意区分Docker和Docker容器。Docker是容器运行引擎、运行时，Docker负责管理、运行容器，而被管理的容器就是Docker容器。这类似于MySQL与MySQL数据库的区别（因此docker实际上也有server和client两个端）。

容器里面装的就是一个一个软件服务。也就是说容器里面是一个软件集。它类似于一个主机，里面装有各种软件服务。我们以一个JavaWeb项目为例说明：

![Untitled](Untitled%2010.png)

如上图，原始部署和使用docker部署过程对比图，当我们为该项目生成一个Docker容器时，它包含了该项目以及项目所需要的外部软件服务。

<aside>
💡 容器 = 项目 + 项目运行时

</aside>

在第1小节中，我们使用dangdang和yingxue作为两个需要部署的项目对传统方式进行了说明。而使用Docker则是使用如下方式：

![Untitled](Untitled%2011.png)

Docker部署

如上图所示，Docker首相将redis、mysql、es等软件服务打包成容器，然后将它们和项目一起打包成大容器。如上图Docker管理了dangdang、yingxue两个容器。dangdang容器和dangdang项目的区别就是，dangdang容器除了dangdang项目还包含它的运行时(运行环境)。针对之前传统方式的缺点我们可以看到，Docker采用了容器技术，能解决版本的不一致问题(环境一致性)，同时解决进程冲突问题（进程级隔离）。同时Docker还支持镜像机制（后续配置镜像源小节会详细介绍镜像），通过镜像来实现快速部署、迁移（不是借助容器实现迁移）。

<aside>
💡 容器借助镜像可以实现项目的跨平台迁移（容器和镜像的区别就像软件和安装包的区别）

</aside>

这样看Docker和虚拟机基本相似，那么他们的区别在哪？

### 虚拟机和容器的区别

其核心区别就是操作系统！

`容器 = 项目 + 项目运行时`所有的容器共有主机的操作系统（虚拟化技术）

`虚拟机 = 项目 +项目运行时+操作系统`虚拟机包含了很多功能，不仅仅只是支持该项目。最典型的就是每个虚拟机都有操作系统，都支持基本的文件编辑等等功能。这些都造成了虚拟机远比容器更占用资源。对于多项目隔离，虚拟机是操作系统级隔离，而容器仅仅只是进程级更新。这也说明了，所有容器内部的项目都必须运行在一个操作系统下。

![Untitled](Untitled%2012.png)

![Untitled](Untitled%2013.png)

- 资源利用率：虚拟机在宿主机上运行一个完整的操作系统，因此资源利用率较低。而Docker容器共享主机操作系统的内核，因此更加轻量级，资源利用率更高。
- 启动时间：由于虚拟机需要启动和加载整个操作系统，所以启动时间较长。而Docker容器只需加载应用程序及其依赖项，因此启动时间非常快。
- 隔离性：虚拟机提供硬件级别的隔离，每个虚拟机都有自己的操作系统内核。而Docker容器共享主机操作系统的内核，通过Linux命名空间和控制组实现进程级别的隔离。
- 系统要求：虚拟机需要额外的资源来运行操作系统，因此对系统需求更高。而Docker容器只需运行应用程序及其依赖项，对系统要求较低。

<aside>
💡 在实际应用中，我们就把容器理解为轻量级虚拟机以方便理解和使用

</aside>

尽管我们尚未了解容器的具体指令，但为了这里的理解，我们提前使用`docker exec -it`指令进入到容器内部，我们可以看到如下图效果：

![Untitled](Untitled%2014.png)

我们可以看到，进入容器之后实际上是一个终端。我们可以认为容器就是一个轻量级的虚拟机，里面下载了一个对外提供服务的应用以及配套的软件服务。

## Docker安装

Docker 分为 `stable` `test` 和 `nightly` 三个更新频道。官网提供了所有系统、所有版本的下载，本节主要以CentOS系统中使用yum下载为例：

### 配置yum

我们知道`yum`是CentOS的包管理器，用于下载各类软件服务。因为Docker是国外资源，下载时由于网络原因经常导致下载过慢或失败。因此我们要给`yum`设置镜像，采用国内镜像来快速下载Docker。

执行以下命令安装依赖包：

```powershell
$ sudo yum install -y yum-utils

```

鉴于国内网络问题，强烈建议使用国内源，官方源请在注释中查看。

执行下面的命令添加 `yum` 软件源（相当于指定`yum`下载商店）：

```bash
$ sudo yum-config-manager \
    --add-repo \
    https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

$ sudo sed -i 's/download.docker.com/mirrors.aliyun.com\/docker-ce/g' /etc/yum.repos.d/docker-ce.repo

# 官方源
# $ sudo yum-config-manager \
#     --add-repo \
#     https://download.docker.com/linux/centos/docker-ce.repo

```

### 卸载旧版本

旧版本的 Docker 称为 `docker` 或者 `docker-engine`，使用以下命令卸载旧版本：

```bash
$ sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine

```

### 安装新版本

更新 `yum` 软件源缓存，并安装 `docker-ce`。

```bash
$ sudo yum install docker-ce docker-ce-cli containerd.io docker-compose-plugin
```

此时Docker就下载好了。

## Docker相关配置

### systemctl

Docker类似于MySQL、防火墙等，是一种后台运行的系统服务。我们使用systemctl来管理Docker服务。

```bash
# 启动 Docker
sudo systemctl start docker

# 关闭 Docker
sudo systemctl stop docker

# 重启 Docker
sudo systemctl restart docker

# 设置 Docker 自启动
sudo systemctl enable docker
```

### 配置镜像源

前面我们提到容器迁移时说到过镜像。镜像就是一个软件，容器就是一个运行的软件服务。我们可以理解为一个安装包、多个软件、也可以理解为一个WPS，多个页面。项目在编写外之后会打包成容器然后发布运行。如果我们要实现迁移，显然需要先把容器打包成一个镜像，然后进行迁移到其它平台运行解压。如果我们把这个当成一个服务发布出去给公共使用，那么我们我需要把它打包成一个镜像，然后挂在一个仓库供其它人下载。Docker提供了Docker Hub存放各种Docker镜像。其它人借助Docker可以从该Hub下载需要的镜像，然后运行镜像产生容器就可以获得服务。

![Untitled](Untitled%2015.png)

<aside>
💡 Docker三大核心：容器(Container)、镜像(Image)与仓库(Respostory)

</aside>

![Untitled](Untitled%2016.png)

从上图，Docker核心架构图可以看到，上述原理类似于maven与jar包的关系。

我们知道Docker本身在国外，网络原因会使得Docker下载各种镜像会非常慢。因此类似于maven有镜像，国内对Docker也提供了镜像支持。我们配置国内镜像源就可以更快、更便捷的下载Docker镜像。

> 国内各大云服务商（腾讯云、阿里云、百度云）均提供了 Docker 镜像加速服务，建议根据运行 Docker 的云平台选择对应的镜像加速服务，具体请参考本页最后一小节。
> 

1.进入阿里云官网

![Untitled](Untitled%2017.png)

在/etc中创建docker文件夹(该文件夹在Docker启动时自动生效)

```bash
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://46goqz93.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

之后重新启动服务。

```bash
sudo systemctl daemon-reload
sudo systemctl restart docker
```

最后使用`docker info`检查配置：

```bash
Registry Mirrors:
 https://https://46goqz93.mirror.aliyuncs.com/
```

## Docker基本命令

### docker命令规则

和Linux、SQL一样，Docker的命令也有规则可言。理解Docker命令规则，便于我们理解和使用Docker命令。

Docker提供了对镜像(image)、容器(container)、数据卷(volume)、网桥(network)等Docker基本组件的相关操作。Docker基本规则为：`docker 组件类型 相关操作 组件定位`；

**组件类型：**取值为(image\volume\network)。由于docker container是docker组件中最核心的部分，相关操作最多，因此不指定组件类型时默认为容器，而其它组件如果有自己特有的操作就省略组件类型，如果是和其它组件相同的操作(如创建，create)则必须指明组件类型。例如，`docker rm`删除容器，`docker image rm`删除镜像。而只有镜像需要从远程仓库拉取，因此`docker pull`拉取镜像(无docker image pull)。

**相关操作：**不同的组件类型既有相同的操作又有不同的操作。例如数据卷和网桥都有create操作，而镜像和容器都有rm操作，同时容器、数据卷、网桥都提供`inspect`命令查看细节。

**组件定位：**组件定位就是组件唯一性的标识，类似于主键和对象ID。在镜像类型中定位一个镜像使用ID和标签tag(`镜像名:版本号`)来唯一标识一个镜像(容器使用`容器ID`和`容器name`；数据卷使用`数据卷别名`；网桥使用`网桥名`)。

值得一提的是`docker inspect`命令，查看组件细节。它不需要指定组件类型，只需要根据组件定位的值自动就可以查看指定组件对象的细节。例如查看数据卷细节：`docker inspect 数据卷别名`即可查看该数据卷的详细信息。当然你也可以使用`docker volume inspect 数据卷别名`。但`inspect`不太需要这样做。

### 入门案例

![Untitled](Untitled%2018.png)

DockerHub提供一个docker-hello的项目镜像。上图展示了使用`docker run`命令来拉取镜像实例化为容器并部署的全过程。我们根据上述过程，对镜像操作、容器操作进行扩展。在这一过程中学习Docker命令

### 辅助命令

```docker
docker version  # 查看docker 客户端引擎 和 服务端引擎的版本
docker info  # 查看docker引擎详细信息
docker help # 查看docker帮助信息
```

### 镜像相关命令

镜像的相关命令主要包括查看所有镜像、搜索镜像、下载镜像、删除镜像等。

**1.查看本地仓库中所有镜像：`docker images` 或 `docker image ls`**

![Untitled](Untitled%2019.png)

<aside>
💡 定位一个镜像有两种方式：1.使用镜像标签(名称+版本号)(tomcat:8.0) 2.使用镜像ID

</aside>

**2.下载镜像：`docker pull 镜像名称`**

下载一个镜像显然需要定位到这个镜像

如果只有镜像名称，则默认下载最新版，即镜像名称:latest

如果使用`docker pull 镜像名称:tag`则是下载指定版本

**3.搜索镜像：`docker search 镜像名称`**

只需要指定镜像名称，可以查看docker Hub该镜像的版本情况。

![Untitled](Untitled%2020.png)

如上图，如果镜像所属列属性OFFICAL为OK，则表示为官方提供的镜像。

4**.删除镜像：`docker image rm 镜像名称:tag | ID`**

这里要注意：上述删除方式必须要求删除的镜像是没有运行过的镜像（也就是没有实例化为容器的镜像才能使用上述方式删除）

我们之前见过镜像和容器的关系类似于安装包和应用的关系。当应用正常安装后，其实安装包是可以删除的。

当你使用命令 `docker image rm` 删除一个镜像时，会从本地的镜像库中移除该镜像。这不会直接影响正在运行的容器，因为容器是基于镜像创建的独立实例。docker提供了强制删除的指令：`docker image rm -f 镜像名称:tag | ID`

删除镜像后，已经在运行的容器将继续正常工作，因为它们是从先前已下载的镜像创建的，并且拥有自己的文件系统。容器与其基础镜像之间存在一种类似“快照”的关系：容器启动时会创建一个可写层，用于存储对文件系统的更改。删除镜像并不会影响这个可写层。

但是需要注意的是，如果在将来需要重新创建相同镜像的新容器，而你已经删除了该镜像，那么将无法直接使用 `docker run` 命令创建新的容器。你需要重新拉取或构建该镜像，然后才能创建新的容器。

因此，在删除镜像之前，请确保不再需要它，并且没有依赖于该镜像的其他容器在运行。我们删除镜像时尽量使用`docker image rm 镜像名称:tag | ID`来删除，也就是确保该镜像不再需要使用(无需它的实例化容器)。

尽管我们可以使用`docker rmi`来删除镜像，但是为了和后续容器操作命令相区分，使用docker image+操作的格式来操作镜像。

### 容器基础命令

操作docker命令格式：docker 命令  [选项]  。如果多个选项，选项之前没有顺序之分，可以随意。

**1.查看运行中的容器：`docker ps`**

![Untitled](Untitled%2021.png)

<aside>
💡 容器定位：1.容器ID；2.容器名称name（容器不同于镜像，没有版本号、标签的概念）

</aside>

- 容器服务：容器向外提供服务；通过访问该服务端口就可以访问该容器。
    
    以一个Web项目的部署为例，我们把Web项目及其需要的MySQL数据库等打包为一个容器。这个容器中进程Web项目占用端口8080。而外部客户端只能访问服务器主机端口。由此我们需要将容器内部服务端口和外部服务器端口进行映射。
    

<aside>
💡 在使用容器ID查找容器时，不需要全写，只要能和已下载的其他容器相区分就可以了。

</aside>

**2.运行容器：`docker run 镜像名 | 镜像ID`**

我们说，容器类似于虚拟机，启动一个容器相当于启动一个虚拟机。此时我们需要指定这个虚拟机启动是后台挂载（后台式）还是进入虚拟机终端（交互式）

- 启发式容器（Interactive Container）和后台式容器（Detached Container）是两种不同的容器运行模式。
    
    启发式容器是指在容器中运行一个交互式的会话，类似于在本地终端中使用命令行界面。当你在启发式容器中运行一个命令时，你可以直接与容器进行交互，查看命令的输出并输入进一步的命令。启发式容器通常用于开发、调试和测试的目的，因为它们允许用户直接与容器进行交互并查看实时的输出。
    
    后台式容器是指在容器中运行一个命令或服务，但不会在终端中显示输出，并且容器会在后台持续运行。后台式容器通常用于生产环境中的应用程序部署，因为它们可以在容器中运行服务，并且不需要用户的交互。后台式容器可以通过日志记录来查看容器的输出和状态。
    
    在Docker中，使用`-it`选项来创建一个启发式容器，例如：
    
    ```
    docker run -it <image> <command>
    ```
    
    而创建后台式容器，可以使用`-d`选项，例如：
    
    ```
    docker run -d <image> <command>
    ```
    
    如果使用-it启动后会进入到容器终端，使用`exec`退出返回至宿主机的终端。另外就是容器一旦退出交互就会停止运行自动关闭，而后台式启动容器就会一直运行。如果我们需要对后台式容器中的服务进行操作时，可以借助后面要介绍的docker exec命令进入后台式容器终端中操作。
    

<aside>
💡 注意进入交互式容器不是/home，它是不固定的——进入容器的服务工作目录，随着服务不同而变化。

</aside>

如果不指定启动模式，则默认是后台式启动

我们知道虚拟机的程序想要供外部其它主机连上，首先需要和宿主机端口映射，这样借助于联网的宿主机端口，外部访问宿主机指定端口然后映射到虚拟机程序，得到服务。容器和这个情况类似，直接运行容器，容器内部无法访问。容器往往需要使用端口映射来将内部的服务向外提供给宿主机(服务器)再提供给客户端。因此，除了运行容器的模式之外，还需要指定容器的内部服务端口和宿主机端口映射关系。运行容器命令提供`-p`选项来增加端口映射配置：

```
docker run -p 8080:8080 tomcat:8.0 # 前面端口为服务器端口，后面端口为容器端口，即hostPort:containerPort格式
```

上述方式启动容器往往在我们离开容器(退出容器终端)时，容器会停止运行，自动关闭。但实际开发中，我们往往需要服务一直在后台运行，也就是后台式进程。

这里提供选项-d后台式启动服务：

```
docker run -p 8082:8080 -d tomcat:8.0 #执行命令后进入容器终端界面
```

通过该选项，直接进入容器终端，我们再该终端可以调整一些基本配置

![Untitled](Untitled%2022.png)

后台运行容器之后返回给服务器命令终端容器ID，docker为了简便，将容器ID识别为前12位即可。此时容器在后台提供服务，不需要始终打开容器。

除此之外，docker提供选项--name来给容器指定容器名称(容器名称规范是全部小写，以"-"连接):

```
docker run -d -p 8082:8080 --name  new-tomcat8 tomcat:8.0
```

- 我们看到选项有时候用-，有时候用--，这是采用了Linux命令选项的习惯：长选项与短选项；我们知道短选项是缩写，因此直接-标记就可以了。而长选项是多个单词组成时用'-'连接，因此为了区分用的'--'作为标记
    
    1.在Linux命令中，选项（Options）是用于修改命令行工具的行为和参数的一种机制。有时候选项前面使用单破折号（-），有时候使用双破折号（--），其区别如下：
    
    - 单破折号选项（-）：单破折号用于表示短选项或者简写选项。它通常只能单个字母，并且可以将多个单破折号选项连在一起。例如，在`ls`命令中，使用`l`选项来显示详细的文件列表。
    - 双破折号选项（--）：双破折号用于表示长选项。相比于单破折号选项，长选项通常是一个完整的单词或短语，更易读且更具描述性。长选项提供了更多的功能和灵活性，但由于长度较长，输入时会更繁琐。例如，在`git`命令中，使用`-all`选项来显示所有分支，同时使用`-verbose`选项来显示更详细的输出信息。
    
    单破折号选项（-）通常用于短选项，而双破折号选项（--）用于长选项，提供更具描述性的选项名称。选择使用哪种类型的选项取决于具体的命令和个人偏好。你可以通过查看命令的文档或使用命令后加上`--help`参数来获取有关可用选项的更多信息。
    
    2.长选项与短选项是不是一定都一一对应
    
    不是所有的长选项都有对应的短选项，尽管它们通常是以提供相同或类似的功能。长选项的存在是为了提供更具描述性和可读性的选项名称，更易于记忆和理解。
    
    在某些命令中，只提供了长选项而没有对应的短选项。例如，在`git`命令中，`--all`选项只有长选项形式，并没有对应的短选项。另外，一些命令可能只提供了短选项而没有对应的长选项。
    
    然而，大多数命令通常会同时提供长选项和短选项，以便用户根据个人偏好使用。如果一个命令提供了长选项，可以查看该命令的文档或者运行命令时添加`--help`参数来获取有关可用选项的详细信息，包括长选项和短选项的列表及其功能说明。
    
    例如：
    
    - `ls`命令：该命令用于列出目录中的文件和子目录。它提供了短选项`l`来显示详细的列表信息，同时也提供了长选项`-all`来显示所有文件（包括隐藏文件）。这里短选项`l`有对应的长选项`-all`。
    - `grep`命令：该命令用于在文件中搜索匹配指定模式的行。它提供了短选项`i`来忽略大小写进行搜索，同时也提供了长选项`-ignore-case`来实现同样的功能。这里短选项`i`有对应的长选项`-ignore-case`。
    - `cp`命令：该命令用于复制文件或目录。它提供了短选项`r`来递归地复制目录及其内容，但并没有对应的长选项。所以，这是一个例外情况，只有短选项而没有对应的长选项。
    
    总结：开发者在开发短选项时一般会开发对应的长选项，但不一定全部开发。而长选项则经常作为短选项的补充，因此也有可能没有短选项。在这里我们只需要知道什么时候用'-'和'--'（即长选项（单词）用--，短选项（字母）用-）
    

目前我们学习的运行容器的基本选项有：--name\-d\-it\-p

**3.暂停、重启、删除容器**

```
docker stop 容器名|容器ID
docker start 容器名|容器ID
docker restart 容器名|容器ID
docker rm 容器名|容器ID
docker rm -f 容器名|容器ID
```

<aside>
💡 容器只有停止运行时才可以被删除。因此，移除一个服务的全过程是停止容器→删除容器→移除镜像。

</aside>

**4.查看容器日志：`docker logs`**

docker logs命令有`-t/-f/--tail`三个选项

- t加入时间戳，-f跟随最新的日志打印，`--tail`数字，显示最后多少条

**5.进入容器：`docker exec`**

上面我们知道容器本身可以理解为一个轻量级虚拟机。在启动容器时提到后台运行式启动服务，即使得服务直接作为后台进程一直运行。尽管这种方式最为常见，但有时候我们需要修改后台式容器的相关配置，这需要我们进入容器终端，使得其能和我们进行交互。使用`docker exec -it`：

```
docker exec -it 容器ID|容器名 bash/sh #bash和sh二选一即可，一般选择bash
```

![Untitled](Untitled%2023.png)

我们可以看到，进入容器之后实际上是一个终端。我们可以认为容器就是一个轻量级的虚拟机，里面下载了一个对外提供服务的应用以及配套的软件服务。

如果要退出容器，使用命令`exit`退出：

![Untitled](Untitled%2024.png)

和`docker run -it`不同的是，这种只是暂时地交互，如果exit退出会变回后台运行而不是停止运行。另外就是使用docker exec -it进入的工作目录是不固定的，始终进入容器内服务的工作目录。

**6.容器和宿主机之前文件拷贝：`docker cp`**

如果要将容器内部的文件拷贝到宿主机上：docker cp 容器ID|name:容器中文件和目录 主机中那个目录

如果需要将宿主机文件拷贝到容器内部：docker cp 主机文件和目录 容器ID|name:容器中目录

### 容器高级指令

```
docker top 容器id|name #查看容器内进程
docker inspect 容器ID | name #查看容器内细节指令
```

**1.容器数据卷机制**

对`docker run`新增选项`-v/--volume`

**数据卷：**`Data Volume`

**作用：**用来实现容器中数据和宿主机中数据进行映射同步。数据卷机制如下图：

![Untitled](Untitled%2025.png)

**注意：**数据卷必须在容器启动时设置好

**使用：**`docker run -v 宿主机目录:容器内目录 ...`（也就是说数据卷增加了docker run命令选项`-v`）

![Untitled](Untitled%2026.png)

```
docker run -d -p 8082:8082 --name tomcat02 -v /root/apps/:usr/local/tomcat/webapps:ro tomcat:8.0
```

这种命令使得两个形成映射之后只能通过更改主机来更改容器中配置，容器中的目录是只读的。

数据卷一般直接使用别名，让其自动创建即可。

**数据卷相关命令：**

```
docker volume ls #查看docker维护的数据卷目录
docker (volume) inspect 数据卷别名 #查看指定数据卷的详细信息
docker volume rm 数据卷别名 #删除数据卷
docker volume create 数据卷别名 #创建数据卷
```

<aside>
💡 数据卷定位使用数据卷别名

</aside>

![Untitled](Untitled%2027.png)

在上图中我们能够清楚的看到使用别名创建的数据卷所存放的位置。

当我们删除容器或新建容器时，使用相同配置启动。此时宿主机数据被映射到新建容器中，容器数据恢复。

<aside>
💡 数据卷将数据脱离容器管理：使用数据卷将数据托管给宿主机避免容器删除导致数据丢失，同时能帮助数据快速复制给其它容器。

</aside>

**应用场景：**凡是使用数据的服务容器，都需要建立数据卷，把数据保存在宿主机中以防数据丢失。最典型的就是MySQL容器，它用来存放各种数据，但如果不小心删除，则数据丢失，这是不符合数据安全要求的。因此，在实际开发中，我们运行MySQL容器需要配置好数据卷。

数据卷配置只要知道，是使用`-v`进行选项配置，最后掌握如何查找服务在容器得数据存放位置以及在主机的位置即可。

**2.打包为镜像：`docker commit`**

如下图所示，我们往往需要将开发好的项目使用docker变成容器，然后借助容器生成镜像，镜像能够非常轻松的进行迁移。另外镜像实际上远远大于容器（在后面镜像构成原理中详解），因此我们还需要对镜像打包，将其打包为tar包。当我们需要部署时，先去找对应的tar包，然后使用`docker load`载入生成镜像，然后由镜像`docker run`生成容器到目标宿主机即可。

![Untitled](Untitled%2028.png)

<aside>
💡 以一个Web项目为例，我们可以把容器比作一个jar包+操作系统，镜像可以比作一个项目文件+操作系统核心库，tar可以认为就是项目文件+操作系统库文件打包

</aside>

以一个Web项目为例，我们可以把容器比作一个jar包+操作系统，镜像可以比作一个项目文件+操作系统核心库，tar可以认为就是项目文件+操作系统库文件打包

```
#打包镜像
docker save 镜像名 -o 名称.tar #打包镜像时报名规范是“镜像名-tag”例如：tomcat-8.0.tar
#载入镜像
docker load -i 名称.tar #载入镜像：可以将tar包变成镜像
#容器打包成新的镜像
docker commit -m "描述信息" -a "作者信息" (容器id或者名称) 打包的镜像名称:标签
```

打包镜像时报名规范是“镜像名-tag”，例如：

```
docker save tomcat:8.0 -o tomcat-8.0.tar
```

## 镜像构成原理

在前面我们提到由于镜像远比容器要大，因此我们生成镜像之后往往需要对镜像进行打包，使得它占用空间少。这里我们首先讲解一下为什么镜像比容器大，然后再讲述镜像的构成原理。

### 镜像为什么这么大

我们下载tomcat镜像并生成容器之后，使用docker images查看发现tomcat镜像为356M，而容器只有10M。之前我们说，容器可以认为就是一个轻量级的虚拟机，也就是轻量级的操作系统，其仅仅支持服务运行的基本功能：

`容器独立操作系统(精简Linux操作系统+软件服务)→镜像运行→镜像（操作系统库+软件文件）`也就是说，镜像要含有软件的文件以及生成操作系统用的操作系统核心系统库文件。最典型的就是，Spring Web项目它可以认为就是镜像，而生成的容器就只是包含jar包。也就是说，镜像含有代码以及运行时所需的库。

### 镜像的原理

镜像是一种轻量级的，可执行的独立软件包，用来打包软件运行环境和基于运行环境开发的软件，它包含运行某个软件所需的全部内容，包括代码、运行时所需的库、环境变量和配置文件。

![Untitled](Untitled%2029.png)

上面我们看到，镜像代表的是一个软件包，它往往具有多种版本。本身镜像的体积就比容器大很多，如果全部放置于Hub仓库中显然会很大。因此，镜像对此进行了优化，采用联合文件系统：

![Untitled](Untitled%2030.png)

如上图所示，联合文件系统（UnionFS）也称为叠加文件系统，通过文件的分层于叠加，使得某些文件成为公共文件而不用重复生成。这种文件系统的特性：一次同时加载多个文件系统，但从外面看起来就像只能看到一个文件系统，联合加载会把各层文件系统叠加起来，这样最终文件系统会包含所有底层的文件和目录。

之前我们简单说明了虚拟机和容器的区别。我们知道虚拟机是直接下载一个完整的操作系统，而容器则不是。这里重点要明白bootfs和rootfs的区别：

![Untitled](Untitled%2031.png)

bootfs（ boot file system）主要包含bootloader（boot加载器）和kernel（内核）。Bootloader是一个程序，主要是引导加载kernel。它位于计算机的固件中，并且是第一个在计算机启动时运行的软件。当Linux启动时就会启动bootloader加载kernel内核到内存中。加载完成之后，整个内核处于内存之中，内存的使用权限由bootfs转为内核，bootfs开始卸载。

rootfs（root file system）位于bootfs之上，包含的就是最典型的Linux系统中的/dev、/proc、/bin、/etc等标准目录和文件。rootfs就是各种不同版本操作系统发行版，比如Ubuntu\CentOS等。

容器作为轻量级虚拟机，实际上它的镜像底层就是bootfs。这一层，所有的操作系统都是一样的。但是虚拟机一般都是自行下载用于bootfs，因此宿主机和虚拟机操作系统可不一致，但是占用过大。而容器则是公用宿主机的rootfs，因此必须和宿主机的操作系统种类一致(Windows、Linux、MacOS)

## 运行MySQL服务

使用任何容器都建议去dockerhub官方网站查看：[https://hub.docker.com/_/mysql](https://hub.docker.com/_/mysql)

MySQL服务的运作具体包括：下载并运行产生容器；配置容器环境；配置容器数据卷

### 下载MySQL镜像

目前主流MySQL主要使用`5.x`版本和`8.x`版本，最常见的是5.6版本

docker search mysql查看MySQL发行版本

docker pull mysql:5.7

### 运行MySQL镜像生成容器

**安装：**

`docker run -p 3306:3306  -d --name some-mysql mysql:5.7`

注意：必须指定MySQL的ROOT密码，使用-e选项来设置启动的服务环境选项：-e(即env环境的意思)MYSQL*ROOT*PASSWORD

`docker run -p 3306:3305 -d --name some-mysql -e MYSQL*ROOT*PASSWORD=123456 mysql:5.7`

**检查安装状态：**

```docker
docker ps #查看容器及其ID

docker exec -it 容器ID bash #进入容器内终端
```

在终端中输入mysql，进入MySQL数据库管理程序中

![Untitled](Untitled%2032.png)

**永久运行：**

我们知道-d使得其在后台运行。但是后台运行不等于一直启动。当docker重启时无论后台运行容器还是交互式容器都会关闭。为了让后台式容器一直运行，我们需要在运行容器时增加选项`--restart-always`

**数据卷配置：**

在之前介绍数据卷我们就提到了，数据卷可以使得容器中的数据交给主机统一管理。这样当我们配置好数据卷之后，数据交给宿主机，当我们删除容器时，数据被保留到本地。MySQL数据保存容器到`/var/lib/mysql`

```
docker run -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d --name mysql102 --restart-always -v /root/data:/var/lib/mysql mysql:5.7
```

当我们再启动一个MySQL容器时，使用上面相同的命令，主机数据被映射到新容器中，MySQL容器中数据和原MySQL容器数据保持一致。

**数据跨平台迁移:**

![Untitled](Untitled%2033.png)

上面我们使用数据卷将数据保存在宿主机上，保证本平台数据始终不丢失并很容易地利用。但是如上图所示，如果容器需要跨平台迁移时，如何保证数据不丢失？调用MySQL的mysqldump将数据导出为sql文件。

```
docker exec some-mysql sh -c 'exec mysqldump --all-databases -uroot -p"$MYSQL_ROOT_PASSWORD"' > /some/path/on/your/host/all-databases.sql
```

![Untitled](Untitled%2034.png)

当然，这种数据迁移不是很常用，因为我们提供MySQL服务后可以使用Navicat或者其它远程连接工具直接连接并导出数据。

## 运行redis服务

参考文档：[https://hub.docker.com/_/redis](https://hub.docker.com/_/redis)

![Untitled](Untitled%2035.png)

在redis服务部署中要知道rdb和aof持久化，同时要知道数据卷映射时，生成的数据实际上为一个redis.conf日志。这个就是数据。

除了上述配置启动redis日志外，我们还可以借助数据卷实现redis配置同步，将配置文件也纳入宿主机管理，具体步骤如下：

- 从官网找到对应版本redis配置文件下载
- 自定义redis相关配置，如允许所有客户端连接；aof日志启动
- 将配置文件自定义然后部署到宿主机
- 将宿主机配置文件和redis文件映射

<aside>
💡 所有服务的配置都推荐使用数据卷的形式将其交给宿主机管理

</aside>

![Untitled](Untitled%2036.png)

我们对上述方式进行了一个优化：redis容器支持多宿主机文件和同一个容器文件相互映射。我们创建conf配置文件，直接编写需要修改的配置（而不是全部配置都写），上传到宿主机并和redis建立映射。新修改的配置会采用宿主机的，如果宿主机中配置没指明，则采用默认配置。

## 高级网络

### Docker网络原理

docker中容器网络通信：我们可以认为是虚拟机之间通信。在很早之前我们运行容器使用`-p`选项实现宿主机和容器之间的连接。实际上docker支持容器间通信。

当 Docker 启动时，会自动在主机上创建一个 `docker0` 虚拟网桥，实际上是 Linux 的一个 bridge，可以理解为一个软件交换机。它会在挂载到它的网口之间进行转发。

同时，Docker 随机分配一个本地未占用的私有网段（在 [RFC1918](https://datatracker.ietf.org/doc/html/rfc1918) 中定义）中的一个地址给 `docker0` 接口。比如典型的 `172.17.42.1`，掩码为 `255.255.0.0`。此后启动的容器内的网口也会自动分配一个同一网段（`172.17.0.0/16`）的地址。

当创建一个 Docker 容器的时候，同时会创建了一对 `veth pair` 接口（当数据包发送到一个接口时，另外一个接口也可以收到相同的数据包）。这对接口一端在容器内，即 `eth0`；另一端在本地并被挂载到 `docker0` 网桥，名称以 `veth` 开头（例如 `vethAQI2QT`）。通过这种方式，主机可以跟容器通信，容器之间也可以相互通信。Docker 就创建了在主机和所有容器之间一个虚拟共享网络。

![Untitled](Untitled%2037.png)

<aside>
💡 默认Docker在创建容器时，会将创建的容器连接到docker0网桥上，默认在docker0网桥上的容器都可以使用容器内IP地址进行通讯。

</aside>

值得一提的是，Docker容器IP是随机动态分配的。容器的重启和配置都可能引发容器IP重新分配。因此在实际通信中，Docker推荐使用容器名字替换IP，即，容器名是容器IP的别名，始终映射着容器IP。

```powershell
curl http://tomcat02:8080 #在宿主机使用tomcat02名+服务端口可以访问到指定容器
```

但是docker0网桥不支持使用容器名映射IP，我们需要自定义Docker网桥。

### 自定义网桥

使用`docker network ps`可以查看docker网桥类型：bridge(默认)、host、none(一般情况下，host\none基本不使用，只需了解即可)。因此，创建网桥时需要指定网桥类型。

```powershell
docker network create -d bridge 网络名称 #网络名称是网桥的唯一标识
```

docker网桥相关命令如下：

```powershell
docker network ls #查看所有网桥
docker network inspect 网络名称 #查看指定网桥的细节
docker network rm 网络名称 #删除指定网桥
docker network prune # 删除所有未使用的网桥
```

启动容器时指定加入到某个网桥：`docker run -d —network 网络名称…`;即增加`--network`长选项

启动容器之后如果想更改容器所属网桥：`docker network connect 网络名 容器id(name)`

<aside>
💡 容器借助于自定义网桥可以实现容器名/ID与容器IP的映射。避免了动态IP对容器间通信的困扰。

</aside>

## Dockerfile

[Dockerfile官方文档](https://docs.docker.com/engine/reference/builder/)

在实际生产中手动操作是低效且不可移植的。自动化脚本能够实现项目快速的批量操作。幸运的是，Docker也提供了镜像自动构建的方式——Dockerfile。

<aside>
💡 Dockerfile是Docker实现镜像自动化构建的脚本。可以认为是Docker镜像的描述文件，由一系列命令和参数构成的脚本，用于自动构建Docker镜像。

</aside>

![Untitled](Untitled%2038.png)

dockerfile运行命令：`docker build -t 镜像标签(name:版本号) .(dockerfile所在路径)`当dockerfile在当前目录时，直接使用.表示即可。

![Untitled](Untitled%2039.png)

### dockerfile编写规则

了解编写规则对我们快速编写dockerfile是有益的。dockerfile本质上是一个命令集，用于快速构建dockerfile。而`命令= 指令 + 参数`。

因此，掌握dockerfile指令是最基本要求。

**1.Dockerfile指令**

| Dockerfile 指令 | 说明 |
| --- | --- |
| FROM | 指定基础镜像，用于后续的指令构建。 |
| MAINTAINER | 指定Dockerfile的作者/维护者。（已弃用，推荐使用LABEL指令） |
| LABEL | 添加镜像的元数据，使用键值对的形式。 |
| RUN | 在构建过程中在镜像中执行命令。 |
| CMD | 指定容器创建时的默认命令。（可以被覆盖） |
| ENTRYPOINT | 设置容器创建时的主要命令。（不可被覆盖） |
| EXPOSE | 声明容器运行时监听的特定网络端口。 |
| ENV | 在容器内部设置环境变量。 |
| ADD | 将文件、目录或远程URL复制到镜像中。 |
| COPY | 将文件或目录复制到镜像中。 |
| VOLUME | 为容器创建挂载点或声明卷。 |
| WORKDIR | 设置后续指令的工作目录。 |
| USER | 指定后续指令的用户上下文。 |
| ARG | 定义在构建过程中传递给构建器的变量，可使用 "docker build" 命令设置。 |
| ONBUILD | 当该镜像被用作另一个构建过程的基础时，添加触发器。 |
| STOPSIGNAL | 设置发送给容器以退出的系统调用信号。 |
| HEALTHCHECK | 定义周期性检查容器健康状态的命令。 |
| SHELL | 覆盖Docker中默认的shell，用于RUN、CMD和ENTRYPOINT指令。 |

**2.格式要求**

- 一行只能编写一条命令。
- 第一行必须是`FROM`指令。
- 指令建议使用大写，其它参数则是小写。
- dockerfile注释使用#

### 指令详解

**1.FROM指令**

FROM指令用于指定基础镜像，即从什么镜像开始创建，后面接参数镜像标签tag(name:版本号)

```docker
FROM <image>[:<tag>] [AS <name>]
eg:
FROM centos:latest
```

使用FROM指定基础镜像时要了解Docker镜像构成原理。例如镜像tomcat实际上已经包含了centos:latest基本镜像。我们设定基础镜像一定要采用最近原则，即离当前要创建镜像最近的镜像(只需要最少操作既可以改造为当前需要创建的镜像)。

**2.RUN指令**

RUN用于指定构建镜像时需要使用的命令，即在基础镜像终端shell需要执行的命令。

RUN编写有shell格式和exec格式：

shell 格式：

```docker
RUN <命令行命令>
# <命令行命令> 等同于，在终端操作的 shell 命令。
eg:
RUN yum install -y vim
```

exec 格式：

```docker
RUN ["可执行文件", "参数1", "参数2"]
# 例如：
# RUN ["./test.php", "dev", "offline"] 等价于 RUN ./test.php dev offline
eg:
RUN ["yum","install","-y","vim"]
```

**3.EXPOSE指令**

EXPOSE用于声明当前容器对外暴露的服务端口。注意，EXPOSE仅仅只是声明作用，而不是决定容器的端口。在JavaWeb中，我们首先在程序配置文件中指定服务的端口为8081，然后使用EXPOSE进行声明，然后选择合适的宿主机端口8081与之进行映射(docker run -p)。

**4.WORKDIR指令**

指定Docker进入容器后的落脚点。我们之前介绍过Docker容器类似于虚拟机，而进入容器时的初始路径不全是相同的。实际上我们创建镜像时就会指定进入容器时的落脚点。这个功能借助WORKDIR实现。

```docker
WORKDIR <directory>
eg:
WORKDIR /usr/src/myapp 
```

<aside>
💡 需要注意的是，**WORKDIR** 指令不会在容器中创建目录，如果指定的目录不存在，后续的命令可能会失败。如果需要在容器中创建目录，可以使用 **RUN** 命令结合 **mkdir** 或类似的命令来实现。

</aside>

除此之外，WORKDIR还为RUN、CMD、ENTRYPOINT、COPY和ADD提供工作目录的设置。

**5.ADD指令**

将本地文件或远程文件拷贝到容器之中。格式为

```docker
ADD <src> <dest>
eg:
ADD app.py /app/
ADD https://example.com/file.txt /data/
```

其中 **<src>** 是要添加到容器的源文件或目录的路径，可以是本地文件或远程 URL。 **<dest>** 是容器中的目标路径，指定文件或目录在容器中的位置。

**ADD** **指令**还支持自动解压缩压缩文件，例如 **.tar**、**.tar.gz**、**.tar.bz2**、**.tar.xz**、**.zip** 等。如果 **<src>** 是一个压缩文件，它将被自动解压缩到 **<dest>** 目录中。

<aside>
💡 需要注意的是，相对于 **COPY** 指令，**ADD** 指令具有更多的功能，但也更复杂。在大多数情况下，如果只是简单地将文件从本地复制到容器中，推荐使用 **COPY** 指令。只有在需要自动解压缩压缩文件或下载远程文件时，才使用 **ADD** 指令。

</aside>

**6.ENV指令**

用来设置构造镜像过程中的环境变量。即主要用于在dockerfile里面定义变量：

```docker
ENV <key>=<value> #ENV 变量名 = 值

eg:
ENV BASE_PATH = /apps/data
WORKDIR $BASE_PATH
```

注意环境变量一般建议大写；引用时使用$

**7.volume指令**

volume声明挂载点,，即真正的容器数据卷设置需要手动进行。

```docker
VOLUME <path>
eg:
VOLUME /data
docker run -v /host/data:/data myimage
```

**8.CMD指令**

CMD和ENTRYPOINT都用于指定容器运行时要运行的命令。

CMD & ENTRYPOINT指令用于在容器启动时指定默认的执行命令或应用程序。它的格式有多种形式，可以是以下任意一种：

- CMD ["executable","param1","param2", ...]（推荐使用 JSON 数组格式）：
    - 这种形式将命令及其参数作为 JSON 数组提供。
    - 例如：CMD ["python", "app.py"] 表示在容器启动时默认执行 python app.py 命令；还有[”java”,”-jar”,”ems.jar”]
- CMD command param1 param2 ...（使用字符串格式）：
    - 这种形式将命令及其参数作为字符串提供。
    - 例如：CMD python app.py 表示在容器启动时默认执行 python app.py 命令；java -jar ems.jar

我们之前学的RUN是用于在构建镜像时执行命令，影响镜像的构建过程。而CMD和ENTRYPOINT用于在容器启动时指定默认的执行命令或应用程序，可以被运行容器时的命令覆盖。其最主要的区别是一个作用于镜像，一个作用于容器。容器才是对外提供服务，因此服务程序需要在容器启动时执行。

<aside>
💡 CMD和ENTRYPOINT主要用于启动容器中的服务。而RUN主要是创建目录、安装下载器等。

</aside>

docker run redis实际上内部执行了运行redis-server.conf的命令。

```docker
CMD ["python", "app.py"]
#这个示例在容器启动时默认执行了 python app.py 命令，假设容器中有一个名为 app.py 的 Python 应用程序。
CMD echo "Hello, Docker!"
这个示例在容器启动时默认执行了 echo "Hello, Docker!" 命令，输出一条简单的消息。
```

<aside>
💡 Dockerfile 中只能出现一条 **CMD** 指令，如果有多个 **CMD** 指令，只有最后一个会生效。ENTRYPOINT与之相同。

</aside>

需要注意的是，

**CMD** 命令定义了容器的默认行为，但可以在运行容器时使用 **docker run** 命令的参数来覆盖默认命令，在docker run中指定运行命令覆盖CMD:`docker run 镜像:版本号 覆盖自己定义的CMD命令`。

例如：

```docker
docker run myimage python script.py
```

这个示例中，**CMD** 指定的默认命令将被覆盖，容器启动时将执行 **python script.py** 命令。

**9.ENTRYPOINT指令**

CMD & ENTRYPOINT的用法基本相同——用于指定容器时执行命令。但是它们在细微之处存在区别。首先是docker run覆盖CMD & ENTRYPOINT命令时，存在一些不同之处：尽管docker run中指定的参数和ENTRYPOINT参数名称相同时实现值覆盖，但是如果不相同，则ENTRYPOINT的参数会被追加在 **docker run** 命令的参数之后。

在docker run中指定运行命令覆盖ENTRYPOINT：`docker run --entrypoint= 覆盖指令 镜像:版本号 参数` 。

例如：

```docker
ENTRYPOINT ["python", "app.py", "--arg1", "value1", "--arg2", "value2"]
```

如果我们docker run指定`--arg1`则会将ENTRYPOINT覆盖，但指定`--arg3`则是将ENTRYPOINT参数追加到后面。

总结：在编写一个容器启动时的命令过程中，建议使用ENTRYPOINT来书写一个容器固定的指定，cmd用来给entry传递参数。通过配合使用的方式必须采用json数组格式别写。

例如：

```docker
FROM python:3.9

WORKDIR /app
COPY . /app

ENTRYPOINT ["python", "app.py"]
CMD ["--arg1", "value1", "--arg2", "value2"]
```

在这个示例中，**ENTRYPOINT** 指定了容器的启动命令为 **python app.py**，而 **CMD** 指定了默认参数 **--arg1 value1 --arg2 value2**。

当使用 **docker run** 命令启动容器时，如果没有提供额外的命令和参数，容器将执行 **python app.py --arg1 value1 --arg2 value2** 命令。

如果需要在运行容器时指定不同的命令和参数，可以通过 **docker run** 命令的参数来覆盖默认的命令和参数。例如：

```docker
docker run myimage --arg1 newvalue --arg3 value3
```

在这个示例中，**myimage** 是要运行的镜像，**--arg1 newvalue --arg3 value3** 将覆盖默认的参数，容器将执行 **python app.py --arg1 newvalue --arg3 value3** 命令。

## Dockerfile构建应用

以Spring Boot项目为例，编写dockerfile构建镜像并实现项目部署。Spring Boot项目部署的过程为：构建项目镜像、下载MySQL镜像和自定义网桥三个部分。

### 构建项目镜像

首先将Spring Boot项目打包为jar包，然后将其上传到宿主机/apps目录并在该目录中编写dockerfile文件如下：

```docker
FROM openjdk:8-jre #在dockerhub查找jdk镜像
RUN mkdir /apps #创建apps目录
ENV APP_PATH=/apps #设置容器中服务程序所在位置 
WORKDIR /apps #将容器中服务程序目录设置为容器交互式落脚点
ADD ems-0.0.1-SHAPSHOT.jar $APP_PATH/apps.jar #将宿主机本地文件拷贝到容器中
EXPOSE 8081 #声明端口8081
ENTRYPOINT ["java","-jar"]
CMD ["apps.jar "]
```

使用`docker build -t dockerfile .`运行dockerfile生成镜像。然后我们可以使用docker ps查看镜像是否已经构建完成。

### 下载MySQL镜像

MySQL在Spring Boot项目配置中url为`jdbc:mysql://localhost:3306/mydatabase`

之前我们已经详细讲解了MySQL的下载和部署。只要参照该过程进行MySQL镜像生成。

### **自定义网桥**

尽管默认网桥可以实现容器之间的通信，但是容器IP是不固定的。使用`jdbc:mysql://localhost:3306/mydatabase`时localhost不能代表MySQL容器IP。因此我们自定义网桥，将两容器加入到该网络中，MySQL配置为：`jdbc:mysql://mysql:3306/mydatabase`其中替换localhost的mysql指的是容器名。具体过程如下：

```docker
docker network create -d bridge test #创建一个自定义网桥，网络名称为test

docker run -p hostport:8081 --name 项目名(自定义) --network test 镜像名 #生成项目容器并加入网络

docker run -p 3306:3305 -d --name mysql -e MYSQL*ROOT*PASSWORD=123456 --network test  mysql:5.7 #生成mysql容器并加入网络
```

## docker-compose

### docker部署问题

![Untitled](Untitled%2040.png)

如上图Spring Boot项目依赖关系图中，由于项目的运行依赖其它服务，因此我们必须先成功运行部署其它服务的容器，如MySQL、Redis、ES、MQ等。我们需要清楚的知道项目运行所需各个容器之间的依赖关系，并按照顺序逐一运行。

<aside>
💡 传统部署方式无法解决容器依赖性导致的部署困难，即容器编排问题需要得到解决。

</aside>

另一方面，我们不能从项目的角度将一组容器划分在一起。例如一个宿主机中存在100个容器，我们怎么实现dangdang项目宿主机的迁移，即只把上图中左侧5个容器迁移到新项目中。

<aside>
💡 不能从项目角度对容器进行划分导致项目难以在多服务器上部署。

</aside>

显然这里项目不再是指一个Spring Boot程序，而是Spring Boot项目及其配套服务组成的容器组。

### 基本概念

根据上面的缺陷分析，Docker官方提供了docker-compose来解决：

- 容器编排问题
- 整体迁移问题

<aside>
💡 docker-compose实现对容器集群的快速编排。

</aside>

一个dockerfile确定了一个服务镜像自动化构建(镜像构建顺序)；而docker-compose则借助一个yml文件来实现容器组编排问题(docker run执行顺序)。显然docker-compose主要是排序并指定镜像生成容器。

在学习用法之前首先需要对compose的两个重要概念项目(Project)和服务(Service)进行定义：。dangdang是一个Spring Boot项目，但不是docker中一个项目、应用。在docker-compose看来，一个项目就是一套容器组（例如，dangdang、mysql、redis、es、ms），而每个容器对外提供服务。

服务(Service)：提供某一类服务的容器成为服务。一个Service代表的是一个具体的容器实例，而不是一种容器。

项目(project)：由一组相关联的应用容器(服务)组成的一个完整业务单元，在`docker-compose.yml`文件中定义。

显然可以认为：

<aside>
💡 docker-compose.yml用于定义一个项目中的多个容器(服务)。compose的默认管理对象是项目，通过子命令对项目中的一组容器进行便捷地生命周期管理。

</aside>

### 安装使用

目前只有Linux平台上安装docker不附带docker-compose.在Windows和MacOS上安装docker时会自带docker-compose。因此我们主要用下面两种方式为Linux安装docker-compose：

1. 使用pip安装（适用于Linux、macOS和Windows）：
    - 确保已经安装了Python和pip。
    - 打开终端或命令提示符，并运行以下命令来安装Docker Compose：

```powershell
pip install docker-compose
```

- 等待安装完成后，可以通过运行以下命令来验证安装是否成功：

```
docker-compose --version
```

1. 从GitHub源代码安装（适用于Linux、macOS和Windows）：
    - 确保已经安装了Git和Python。
    - 打开终端或命令提示符，并运行以下命令来克隆Docker Compose的GitHub仓库：

```
git clone https://github.com/docker/compose.git
```

- 进入克隆的目录：

```
cd compose
```

- 运行以下命令来安装Docker Compose：

```
python3 -m pip install .
```

- 等待安装完成后，可以通过运行以下命令来验证安装是否成功：

```
docker-compose --version
```

### 基本使用

一方面通过编写docker-compose.yml文件来对一个项目的组成进行说明，然后运行配置文件生成项目容器组。另一方面，借助docker compose命令可以实现对项目及其所属容器的管理。

**1.docker-compose.yml编写**

mkdir ems #创建ems目录作为工作目录。

在ems目录中创建一个`docker-compose.yml`文件

使用`vim docker-compose.yml`编写配置文件，以上面dangdang项目为例，具体配置如下：

```yaml
version: "3.8" #指定dockerfile的版本目录

services: #指定容器组，是一个数组

	#创建服务01：就是对一个docker run的改写
	tomcat01: #指定服务名称，尽管可以在下面使用container键单独自定义容器名，但我们不推荐这样操作，我们尽量不设置容器名，由docker-compose基于服务名称自动生成。
	image: tomcat:8.0 #指定生成容器所需要运行的镜像
  ports: 
		- 8080:8080
	
	#创建服务02
	tomcat02: #指定同类型服务
	image: tomcat:8.0 #指定生成容器所需要运行的镜像
  ports: 
		- "8081:8081" #port推荐写为string

  #创建服务03
	redis: #指定不同类型服务
	image: redis #不指定版本号则采用最新版本
  ports: 
		- "8082:8082" #port推荐写为string

	#创建服务04
	mysql: #创建mysql服务
	image: mysql:5.7
	environment:  #environment不可数，但是里面设置环境，是一个数组
		- MYSQL_ROOT_PASSWORD: root #使用environment两种或写法设置数据库密码
		- "MYSQL_ROOT_PASSWORD = root"
  volumes: #指定数据卷映射，允许容器中多个目录与宿主机映射
		- /root/mysqldata:/var/lib/mysql
		- mysqldata1:/var/lib/mysql #别名不能自动创建，需要手动创建
volumes:
	mysqldata1: #声明数据卷别名，当运行yml时，会根据它先创建数据卷别名再给其它容器构建使用
```

- **关于yml中”-”短横线的意思：**
    
    在这个上下文中，短横线 "-" 是 YAML 语法中的一个标记，用于表示一个列表项。在这个例子中，它表示一个包含多个属性的列表项。在这个 YAML 文件中，每个列表项都以短横线 "-" 开头，并且在短横线后面缩进两个空格。如果去掉短横线 "-"，将会导致 YAML 语法错误。在 YAML 中，短横线 "-" 是用来表示一个列表项的标记，它告诉解析器这是一个列表的开始。如果去掉短横线，解析器将无法正确解析 YAML 文件，可能会导致语法错误或解析失败。因此，保留短横线是确保 YAML 文件正确解析的必要步骤。
    

注意，数据卷别名映射不同于docker run设置。当使用`docker run`命令设置数据卷并为其指定别名时，Docker自动创建别名对应的数据卷。但是docker-compose则不会，因此要专门进行声明。

<aside>
💡 docker-compose不支持数据卷别名的自动创建，需要声明操作。

</aside>

在声明之后，运行yml，启动docker-compose项目，mysql容器生成并运行。我们使用docker volume ls查看数据卷别名列表，看到名称为ems_mysqldata1而不是mysqldata1.因为docker-compose管理的是项目，因此对所有声明的数据卷别名前加”项目名_”

启动docker-compose一组服务：`docker-compose up`该命令必须必须在docker-compose.yml配置文件所在目录，即刚刚自定义的ems。

当需要修改docker-compose.yml中的配置时，只有先把docker-compose项目关闭重启才能生效。`docker-compose down`关闭项目。

**2.docker-compose.yml模板语法**

除了上述基本的使用外，docker-compose还提供了专门的模板指令。

- **build与image**

我们在上面的docker-compose.yml中借助于image指定已有镜像来进行配套服务的容器生成。而dangdang项目本身需要借助dockerfile事先在宿主机生成镜像再借助docker-compose.yml来生成，显然不符合docker-compose项目整体管理、整体迁移的思路。docker-compose实借助**build**指令实现dockerfile的构建过程。

<aside>
💡 每个服务都必须通过 `image` 指令指定镜像或 `build` 指令（需要 Dockerfile）等来自动构建生成镜像。

</aside>

指定 `Dockerfile` 所在文件夹的路径（可以是绝对路径，或者相对 docker-compose.yml 文件的路径）。 `Compose` 将会利用它自动构建这个镜像，然后使用这个镜像。

```
version: '3'
services:

  webapp:
    build: ./dir
```

在build指令下提供了子指令context\dockerfile\arg：

使用 `context` 指令指定 `Dockerfile` 所在文件夹的路径。

使用 `dockerfile` 指令指定 `Dockerfile` 文件名。

使用 `arg` 指令指定构建镜像时的变量。

```yaml
version: '3'
services:

  webapp:
    build:
      context: ./dir
      dockerfile: Dockerfile-alternate
      args:
        buildno: 1
```

- **command**

覆盖容器启动后默认执行的命令。

```yaml
command: echo "hello world"
```

实际上dockerfile中RUN已经指定好了，因此一般不常用。

- **depend_on**

docker-compose本身就是管理一组容器，并起到编排的作用。借助于`depend_on`指令来解决依赖问题。

解决容器的依赖、启动先后的问题。以下例子中会先启动 `redis` `db`(两者没有先后顺序，都优先于web) 再启动 `web`

```powershell
version: '3'

services:
  web:
    build: .
    depends_on:
      - db
      - redis

  redis:
    image: redis

  db:
    image: postgres

```

<aside>
💡 注意：web 服务不会等待 redis db 「完全启动」之后才启动。

</aside>

- **environment与env_file**

在创建项目章节中我们学习了environment指令的使用。它主要是替代docker run中的-e选项。

设置环境变量。你可以使用数组或字典两种格式。实际上为了避免词义问题，我们都推荐environment内部使用字符串（即加引号）的形式。

只给定名称的变量会自动获取运行 Compose 主机上对应变量的值，可以用来防止泄露不必要的数据。

```powershell
environment:
  RACK_ENV: development
  SESSION_SECRET:

environment:
  - "RACK_ENV=development"
  - SESSION_SECRET

	environment:  #environment不可数，但是里面设置环境，是一个数组
		- MYSQL_ROOT_PASSWORD: root #使用environment两种或写法设置数据库密码
		- "MYSQL_ROOT_PASSWORD = root"
```

env_file则与之有一定的不同。如果环境配置过多，不建议使用environment来进行书写，而是创建一个`.env`文件编写配置，然后借助env_file引入。

从文件中获取环境变量，可以为单独的文件路径或列表。

如果通过 `docker compose -f FILE` 方式来指定 Compose 模板文件，则 `env_file` 中变量的路径会基于模板文件路径。

如果有变量名称与 `environment` 指令冲突，则按照惯例，以后者为准。

```
env_file: .env

env_file:
  - ./common.env
  - ./apps/web.env
  - /opt/secrets.env

```

环境变量文件中每一行必须符合格式，与environment内部子命令格式相同，支持 `#` 开头的注释行。

```
# common.env: Set development environment
PROG_ENV=development
```

- **expose**

指定端口

- **network与volumes**

network配置容器连接的网络。注意，docker-compose中网桥和数据卷都不会自动创建，必须进行声明操作

```
version: "3"
services:

  some-service:
    networks:
     - some-network
     - other-network

#声明网桥
networks:
  some-network:
  other-network:
```

volumes数据卷所挂载路径设置。可以设置为宿主机路径(`HOST:CONTAINER`)或者数据卷名称(`VOLUME:CONTAINER`)，并且可以设置访问模式 （`HOST:CONTAINER:ro`）。

```powershell
	#创建服务04
	mysql: #创建mysql服务
	image: mysql:5.7
	environment:  #environment不可数，但是里面设置环境，是一个数组
		- MYSQL_ROOT_PASSWORD: root #使用environment两种或写法设置数据库密码
		- "MYSQL_ROOT_PASSWORD = root"
  volumes: #指定数据卷映射，允许容器中多个目录与宿主机映射
		- /root/mysqldata:/var/lib/mysql
		- mysqldata1:/var/lib/mysql #别名不能自动创建，需要手动创建
volumes:
	mysqldata1: #声明数据卷别名，当运行yml时，会根据它先创建数据卷别名再给其它容器构建使用
```

- **restart**

docker run运行容器时可以通过`--restart=always`指定容器始终运行，即当docker重启时会自动重启。在docker-compose也提供了相关的功能`restart`指令。

**3.compose命令**

compose可以被认为就是docker的一个框架，它也提供项目、容器的管理。我们可以使用compose相关命令平替docker相关命令。

对于 Compose 来说，大部分命令的对象既可以是项目本身，也可以指定为项目中的服务或者容器(指定容器id即可)。如果没有特别的说明，命令对象将是项目，这意味着项目中所有的服务都会受到命令影响。

执行 `docker compose [COMMAND] --help` 可以查看具体某个命令的使用格式。

`docker compose` 命令的基本的使用格式是

```
docker compose [-f=<arg>...] [options] [COMMAND] [ARGS...]
```

**(1)项目操作**

在项目目录中使用docker compose命令可以启动、关闭项目，并查看项目容器列表等。

- **up**

格式为 `docker compose up [options] [SERVICE...]`。

该命令十分强大，它将尝试自动完成包括构建镜像，（重新）创建服务，启动服务，并关联服务相关容器的一系列操作。可以说，大部分时候都可以直接通过该命令来启动一个项目。

链接的服务都将会被自动启动，除非已经处于运行状态。默认情况，如果服务容器已经存在，`docker compose up` 将会尝试停止容器，然后重新创建（保持使用 `volumes-from` 挂载的卷），以保证新启动的服务匹配 `docker-compose.yml` 文件的最新内容。如果用户不希望容器被停止并重新创建，可以使用 `docker compose up --no-recreate`。这样将只会启动处于停止状态的容器，而忽略已经运行的服务。如果用户只想重新部署某个服务，可以使用 `docker compose up --no-deps -d <SERVICE_NAME>` 来重新创建服务并后台停止旧服务，启动新服务，并不会影响到其所依赖的服务。

默认情况，`docker compose up` 启动的容器都在前台，控制台将会同时打印所有容器的输出信息，可以很方便进行调试。当通过 `Ctrl-C` 停止命令时，所有容器将会停止。

如果使用 `docker compose up -d`，将会在后台启动并运行所有的容器。一般推荐生产环境下使用该选项。

- **down**

此命令将会停止 `up` 命令所启动的容器，并移除网络。

- **version**

格式为 `docker compose version`。打印版本信息。

- **ps**

在项目中使用`docker compose ps`可以查看项目中所有的容器。而docker ps是查看该宿主机docker管理的所有容器。

格式为 `docker compose ps [options] [SERVICE...]`。

列出项目中目前的所有容器。

选项：

- `q` 只打印容器的 ID 信息。

**(2)操作容器**

- **exec**

借助于docker compose exec 容器id，直接进入指定容器终端。实际上，docker exec -it与之等价。