# Python基础

**目录：**

**参考文档：**

[酷Python](http://www.coolpython.net/python_primary/python_primary_tutorial.html)

[Python官网文档](https://docs.python.org/3/tutorial/index.html)

## 语言种类

编译型语言和解释型语言是计算机编程中两种不同的语言执行方式。

### 编译型语言

**基本概念：**编译型语言需要通过编译器将源代码一次性转换成机器语言的可执行文件，这个可执行文件包含了计算机可以直接执行的指令。在编译过程中，编译器会检查代码的语法和语义错误，并将源代码翻译成目标代码（通常是机器码或类似的低级语言）。编译型语言的典型例子包括C、C++、Go、Rust等。

**执行过程：**源代码 → 编译器 → 目标代码（可执行文件）→ 运行可执行文件。

**主要优点：**

- 执行效率高，因为代码已经提前转换为机器语言，无需再进行翻译和解释。
- 编译后的程序在不同平台上运行时不再需要编译，节省了运行时的开销。

**主要缺点：**

- 开发过程中需要额外的编译步骤，可能会增加开发时间。
- 由于每个平台都有自己理解的机器码，因此编译型语言的跨平台支持相对较差，需要针对每个平台单独编译。

### 解释型语言

**基本概念：** 解释型语言不需要编译成机器语言，而是通过解释器逐行解释执行源代码。解释型语言的源代码在运行时会逐行翻译成计算机能够理解的指令并立即执行。解释型语言的典型例子包括Python、JavaScript、Ruby、PHP等。

**执行过程：**源代码 → 解释器 → 逐行解释执行。

**主要优点：**

- 开发过程中省去了编译步骤，修改代码后可以直接执行，节省了开发时间。
- 跨平台支持较好，因为源代码在每个平台上都需要解释执行。

**主要缺点：**

- 执行效率通常较低，因为每次运行都需要实时解释代码。
- 相比于编译型语言，解释型语言在运行时可能更容易发现一些错误，因为错误会立即被解释器捕获。

当然这种分类并不是绝对的。例如，Java和C#是先编译成字节码（是一种标准码，可以理解为标准虚拟机所能理解的机器码），然后由虚拟机解释执行（由虚拟机来执行标准码，这样就不用理解宿主机的机器码）。而且现代的JavaScript引擎如V8，使用了即时编译（JIT）技术，可以在运行时将代码编译成机器语言，以提高执行效率。

<aside>
💡 Python作为典型的解释型编程语言，在使用Python开发前需要下载解释器来当作Python的运行环境(运行时)。

</aside>

## Python解释器

### 基本概念

Python解释器是一个计算机程序，用来翻译Python代码，并提交给计算机执行。它主要有两个功能：翻译代码；交给计算机执行；

![Untitled](Untitled%20116.png)

类似于JDK和IDEA，我们使用Pycharm进行编程前首先需要下载Python解释器。

<aside>
💡 安装Python环境本质上就是在电脑中安装Python解释器。

</aside>

### 环境配置

**1.下载解释器的安装程序**

进入[Python官网](https://www.python.org/downloads/)选择合适的解释器版本进行下载。这里我们使用Python3.10.10为例进行安装演示：

![Untitled](Untitled%20117.png)

进入到Python3.10.10安装界面可以看到它的新特性以及下载资源。

- File部分中四个安装方式
    
    32表示支持Windows32位系统，64表示支持Windows64位系统。
    
    embeddable package：压缩包下载，解压安装，下载的是一个压缩文件，解压后即表示安装完成。
    
    installer：独立安装程序，下载的是一个exe可执行程序，双击进行安装下载完可直接打开安装。
    
    前者解压之后需要手动配置环境变量。后者除了安装也支持一键卸载，因此非常方便，我们推荐使用后者来进行快速安装部署。
    

**2.安装解释器**

建议使用离线安装版（executable installer），这样软件会帮你设置系统变量，否则需要自己添加，对新手来说当然越傻瓜化越好。如上图，之后直接双击python-3.10.10.amd64.exe安装程序进行安装。

![Untitled](Untitled%20118.png)

点击Customize installation进行自定义安装，更改安装路径等相关设置(注意在安装指引中勾选`Add Python.exe to PATH`添加python到环境变量，避免后续环境变量的配置)。

![Untitled](Untitled%20119.png)

![Untitled](Untitled%20120.png)

如上图勾选直接默认，只需要更改下载路径即可，点击install下载安装。

打开win+r，输入cmd,进入以下界面，输入`python -V`，出现以下图片就已安装成功：

![Untitled](Untitled%20121.png)

注意安装完成之后不要删除安装程序，也不要改动安装程序的位置。当我们需要卸载python时可以借助该工具快速删除：

![Untitled](Untitled%20122.png)

如果卸载失败，可能时安装程序找不到对应的Python了。我们在确保两者版本一致的前提下，只需要先`Repair`然后再`Uninstall`。

**3.PyCharm的配置**

有两种方式写python代码，他们针对不同的应用场景

- 在python交互式解释器里写代码
- 在编辑器里写代码

![直接编写运行语句](Untitled%20123.png)

直接编写运行语句

![编写.py并运行](Untitled%20124.png)

编写.py并运行

由上图知道，Python解释器可以执行Python语句同时也可以直接编写.py文件。在实际开发中我们往往编写好.py文件然后交给解释器去解释并交给计算机执行。为了快速方便的编写.py文件，我们需要下载PyCharm并整合Python解释器，构建Python IDE(集成开发环境)。

![Untitled](Untitled%20125.png)

如上图所示，进入PyCharm之后，我们看到PyCharm提示需要配置Python解释器。

![Untitled](Untitled%20126.png)

我们点击配置`Python解释器`→`解释器设置`→进入解释器设置页面如下：

![Untitled](Untitled%20127.png)

![Untitled](Untitled%20128.png)

![Untitled](Untitled%20129.png)

这里有Virtualenv环境、conda环境和系统解释器。Conda环境在后面讲到Anaconda时就会清楚。这里重点讲另外两个的区别：

- Virtualenv环境和系统解释器
    
    在PyCharm中配置解释器时，你可以选择使用虚拟环境（Virtualenv）或系统解释器。下面是它们之间的区别：
    
    1. 虚拟环境（Virtualenv）：
    - 虚拟环境是一个独立的Python运行环境，与系统级别的Python解释器相互隔离。
    - 它允许你在同一台计算机上同时管理和运行多个项目，每个项目都有自己的依赖包和配置。
    - 当你创建一个虚拟环境后，在该环境中安装的任何软件包仅对该环境下的项目可见，不会影响到其他环境或系统级别解释器。
    - 虚拟环境可以帮助你管理不同项目之间的依赖关系，确保每个项目的环境都是独立且一致的。
    1. 系统解释器：
    - 系统解释器是在操作系统级别安装的全局Python解释器。
    - 它是默认的Python解释器，通常是由操作系统或你在计算机上手动安装的。
    - 当你选择系统解释器作为PyCharm项目的解释器时，项目将使用计算机上已安装的全局Python解释器来运行。
    - 使用系统解释器可能会导致依赖冲突的问题，特别是在多个项目之间共享同一全局Python解释器时。
        
        虚拟环境本质上是基于已安装的本地解释器创建的。这意味着，你仍然需要先下载解释器到本地，然后虚拟解释器是基于此再生产。因此我们在使用Pycharm开发时推荐配置虚拟解释器。
        
- 推荐Virtualenv环境
    1. 依赖隔离：每个项目都可以有自己的独立环境，可以安装特定版本的软件包和依赖项，而不会与其他项目的依赖项发生冲突。这样可以避免由于依赖冲突而导致的问题。
    2. 环境一致性：每个项目都有自己的虚拟环境，在不同的项目之间切换时，你可以确保每个项目都使用相同的Python解释器和依赖项版本，从而保持开发环境的一致性。
    3. 管理灵活性：你可以方便地创建、删除和切换虚拟环境，而不会影响到其他项目或系统级别的解释器。这使得你可以更轻松地管理不同项目之间的环境。
    4. 跨平台支持：虚拟环境在不同的操作系统上都能正常工作，因此你可以在不同的开发环境中共享和重现相同的项目环境。

之后我们编辑配置，使用虚拟解释器来运行：

![Untitled](Untitled%20130.png)

## 行与缩进

### 缩进

缩进是python的一大特色，很多其他语言爱好者在第一次接触python时，对此都会感到很不习惯。

在其他语言中，一个代码块通常是由一对大括号来定义边界，而在python中，却由缩进来表示代码块，通常是4个空格。

<aside>
💡 Python使用缩进来确定代码的逻辑结构，而不是使用大括号或关键字。

</aside>

```python
if x > 5:
    print("x is greater than 5")
    print("This is inside the if block")
else:
    print("x is less than or equal to 5")
    print("This is inside the else block")
```

在上面的示例中，if和else语句后面的代码块都使用了四个空格进行缩进，以表示它们属于相应的代码块。

请注意，缩进错误可能会导致语法错误或逻辑错误。因此，在编写Python代码时，请务必正确使用缩进。

### 多行代码

通常，一行代码就是一条语句，但有时，一行代码比较长，导致无法在一行全部写下，这时，我们就需要分行来写，分行写有助于保持代码的可阅读性。

```
count = 3 + 4 \
        + 6 + 9 \
        + 10 + 11
```

在 [], {}, 或 () 中的多行语句，不需要使用反斜杠，比如我们定义一个列表

```
lst = [1, 3, 4,
       5, 5, 2,
       7, 9, 10]
```

## Python注释

### 注释的写法

**1.单行注释**

单行注释以 # 开头，用于一行代码的解释。根据规范，注释内容与# 间隔一个空格

```
count = 0   # 记录数量
```

**2.多行注释**

多行注释，可以用三个单引号，或者三个双引号括起来

```python
def recursion(number):
    """
    计算number的阶乘
    :param number:
    :return:
    """

    '''
    计算number的阶乘
    :param number:
    :return:
    '''
    if number == 1:
        return 1

    next_recursion = recursion(number-1)
    return next_recursion*number

if __name__ == '__main__':
    print(recursion(4))
```

多行注释多用于函数，类，模块的说明。

### 注释规范

****1.文档字符串 (docstring)****

目前语言的编程规范一般都推荐Google：[Google Style Guides](https://google.github.io/styleguide/)

> *Python有一种独一无二的的注释方式: 使用文档字符串. 文档字符串是包, 模块, 类或函数里的第一个语句. 这些字符串可以通过对象的__doc__成员被自动提取, 并且被pydoc所用. (你可以在你的模块上运行pydoc试一把, 看看它长什么样). 我们对文档字符串的惯例是使用三重双引号"""( [PEP-257](http://www.python.org/dev/peps/pep-0257/) ). 一个文档字符串应该这样组织: 首先是一行以句号, 问号或惊叹号结尾的概述(或者该文档字符串单纯只有一行). 接着是一个空行. 接着是文档字符串剩下的部分, 它应该与文档字符串的第一行的第一个引号对齐. 下面有更多文档字符串的格式化规范.*
> 

**2.模块**

对于Python而言，一个.py文件就是一个模块。每个文件应该包含一个许可协议模版.。应根据项目使用的许可协议 (例如, Apache 2.0, BSD, LGPL, GPL) 选择合适的模版。

文件的开头应该是文档字符串, 其中应该描述该模块内容和用法.

```python
"""模块或程序的一行概述, 以句号结尾.

留一个空行. 接下来应该写模块或程序的总体描述. 也可以选择简要描述导出的类和函数,
和/或描述使用示例.

经典的使用示例:

foo = ClassFoo()
bar = foo.FunctionBar()
"""

eg：
"""这个blaze测试会使用样板文件.

若要更新这些文件, 你可以在 `google3` 文件夹中运行
`blaze run //foo/bar:foo_test -- --update_golden_files`
"""
```

**3.函数与方法**

和其它语言不一样，Python中函数和方法的注释不是写在声明上方而是写在代码块最顶部

对方法（函数）的注释说明

```python
def deploy(path, remote_ip, remote_path):
    '''
    这是一个自动部署程序
    :param remote_ip: 远程IP地址
    :param remote_path: 远程部署路径
    :return: 返回值
    '''

    pass
```

对类的注释说明

```python
class Deploy(object):
  """这是一个部署程序类"""
```

### PyCharm引入规范

**1.设置文件模板**

PyCharm提供了文件模板设置。通过设置文件模板，我们可以对模块进行基本的说明。首先打开setting设置，进入Editor--Color&Style--File and Templates--Python-Script：

![Untitled](Untitled%20131.png)

在该处设置如下模板：

```python
##!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : ${DATE} ${TIME}
# @Author  : Mat
# @Email   : mat_wu@163.com
# @File    : ${NAME}.py
```

**2.Docstring format**

Docstring format 可通过下方路径进行设置，包括五种风格：Plain、Epytext、reStructuredText、Numpy、Google。

> File -> Settings -> Tools -> Python Integrated Tools -> Docstrings -> Docstring format
> 

![Untitled](Untitled%20132.png)

## 标识符和保留字

### 标识符

Python标识符的定义有5个规则：

- 第一个字符必须是字母表中字母或下划线 _
- 标识符的其他的部分由字母、数字和下划线组成
- 标识符对大小写敏感
- 不能将保留字作为标识符
- 标识符应当有意义，做到见名知意

### 保留字

保留字，也叫关键字，这些关键字是Python直接提供给我们使用的，因此，我们在定义标识符的时候，不能用这些保留字。如果你要开一家公司，公司的名字肯定不能是教育局，这个名字只能官方使用。

你可以启动python交互式解释器，利用keyword模块来查看保留字

```python
>>> import keyword
>>> keyword.kwlist
['False', 'None', 'True', 'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del',
'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import',
'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try',
'while', 'with', 'yield']

```

## Python数据类型

![Untitled](Untitled%20133.png)

一个程序由数据和算法组成。学习一门编程语言要首先掌握最基本的数据类型以及它的程序控制。

Python的基本数据类型包括：

- 整数（int）：表示整数，例如：-5、0、10等。
- 浮点数（float）：表示带有小数部分的数字，例如：3.14、-2.5等。
- 布尔值（bool）：表示逻辑值，只有两个取值True和False，用于表示真和假。
- 字符串（str）：表示文本数据，由一系列字符组成，例如："Hello World"。
- 列表（list）：表示有序、可变的集合，可以包含不同类型的元素，用方括号([])括起来，例如：[1, "apple", True]。
- 元组（tuple）：表示有序、不可变的集合，可以包含不同类型的元素，用圆括号(())括起来，例如：(1, "apple", True)。
- 集合（set）：表示无序、唯一的元素集合，用花括号({})括起来，例如：{1, 2, 3}。
- 字典（dict）：表示键值对的集合，用花括号({})括起来，每个键值对之间使用冒号(:)分隔，例如：{"name": "John", "age": 25}。

### 数字类型

python支持3种数值类型：

- 整型(int)，通常称之为整型或整数，这个概念与我们小学时学过的整数是相同的，python3的整数没有大小限制
- 浮点型(float)， 浮点型数据由整数部分和小数部分组成
- 复数(complex)，由实数部分和虚数部分构成，编程中几乎用不到

在编程时，我们经常对数据的类型进行转换，比如，我们会把一个float类型转换成int类型数据以满足我们特定的操作要求，也存在将int类型数据转成float类型的情况，在交互式解释器里进行下面的操作

```
>>> float(33)
33.0
>>> int(22.34)
22
```

这一篇文章里，学习到了两个内置函数，`int()` 与 `float()`，后面还会学习更多的类型转换函数。

### bool类型

不同于C语言，bool不属于数字类型，也就是说0和1不能代表True和False。在判断语句种不能借助0和非0来执行判断。

```
>>> type(True)
<class 'bool'>
```

4 大于 3 ，显而易见，因此4 > 3 是正确的，其结果就是True， 4 > 6 显然是错误的，因此结果是False。

通过`type函数`可以查看到，True和False的类型是bool。

尽管bool不属于数字类型，但是Python支持bool与数字类型之间的转换：

```
>>> bool(1)
True
>>> bool(0)
False
>>> int(True)
1
>>> int(False)
0
>>> float(True)
1.0
>>> float(False)
0.0
```

在使用内置函数bool做数据类型转换时，bool(0),bool(0.0)的结果是False，此外都是True，显然，0被视为了与假，错相同概念的事物。当我们使用借助0、1做判断语句时，只需要如下：`if bool(0)`即可。

### 字符串

**1.字符串与字节流**

搞清楚了令人头疼的字符编码问题后，我们再来研究Python的字符串。

在最新的Python 3版本中，字符串是以Unicode编码的，也就是说，Python的字符串支持多语言，例如：

```
>>> print('包含中文的str')
包含中文的str
```

对于单个字符的编码，Python提供了`ord()`函数获取字符的整数表示，`chr()`函数把编码转换为对应的字符：

```
>>> ord('A')
65
>>> ord('中')
20013
>>> chr(66)
'B'
>>> chr(25991)
'文'
```

如果知道字符的整数编码，还可以用十六进制这么写`str`：

```
>>> '\u4e2d\u6587'
'中文'
```

两种写法完全是等价的。

由于Python的字符串类型是`str`，在内存中以Unicode表示，一个字符对应若干个字节。如果要在网络上传输，或者保存到磁盘上，就需要把`str`变为以字节为单位的`bytes`。

Python对`bytes`类型的数据用带`b`前缀的单引号或双引号表示：

```
x = b'ABC'
```

要注意区分`'ABC'`和`b'ABC'`，前者是`str`，后者虽然内容显示得和前者一样，但`bytes`的每个字符都只占用一个字节。

以Unicode表示的`str`通过`encode()`方法可以编码为指定的`bytes`，例如：

```
>>> 'ABC'.encode('ascii')
b'ABC'
>>> '中文'.encode('utf-8')
b'\xe4\xb8\xad\xe6\x96\x87'
>>> '中文'.encode('ascii')
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
UnicodeEncodeError: 'ascii' codec can't encode characters in position 0-1: ordinal not in range(128)
```

纯英文的`str`可以用`ASCII`编码为`bytes`，内容是一样的，含有中文的`str`可以用`UTF-8`编码为`bytes`。含有中文的`str`无法用`ASCII`编码，因为中文编码的范围超过了`ASCII`编码的范围，Python会报错。

在`bytes`中，无法显示为ASCII字符的字节，用`\x##`显示。

反过来，如果我们从网络或磁盘上读取了字节流，那么读到的数据就是`bytes`。要把`bytes`变为`str`，就需要用`decode()`方法：

```
>>> b'ABC'.decode('ascii')
'ABC'
>>> b'\xe4\xb8\xad\xe6\x96\x87'.decode('utf-8')
'中文'
```

如果`bytes`中包含无法解码的字节，`decode()`方法会报错：

```
>>> b'\xe4\xb8\xad\xff'.decode('utf-8')
Traceback (most recent call last):
  ...
UnicodeDecodeError: 'utf-8' codec can't decode byte 0xff in position 3: invalid start byte
```

如果`bytes`中只有一小部分无效的字节，可以传入`errors='ignore'`忽略错误的字节：

```
>>> b'\xe4\xb8\xad\xff'.decode('utf-8', errors='ignore')
'中'
```

要计算`str`包含多少个字符，可以用`len()`函数：

```
>>> len('ABC')
3
>>> len('中文')
2
```

`len()`函数计算的是`str`的字符数，如果换成`bytes`，`len()`函数就计算字节数：

```
>>> len(b'ABC')
3
>>> len(b'\xe4\xb8\xad\xe6\x96\x87')
6
>>> len('中文'.encode('utf-8'))
6
```

可见，1个中文字符经过UTF-8编码后通常会占用3个字节，而1个英文字符只占用1个字节。

在操作字符串时，我们经常遇到`str`和`bytes`的互相转换。为了避免乱码问题，应当始终坚持使用UTF-8编码对`str`和`bytes`进行转换。

由于Python源代码也是一个文本文件，所以，当你的源代码中包含中文的时候，在保存源代码时，就需要务必指定保存为UTF-8编码。当Python解释器读取源代码时，为了让它按UTF-8编码读取，我们通常在文件开头写上这两行：

```
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
```

第一行注释是为了告诉Linux/OS X系统，这是一个Python可执行程序，Windows系统会忽略这个注释；

第二行注释是为了告诉Python解释器，按照UTF-8编码读取源代码，否则，你在源代码中写的中文输出可能会有乱码。

申明了UTF-8编码并不意味着你的`.py`文件就是UTF-8编码的，必须并且要确保文本编辑器正在使用UTF-8 without BOM编码：

![Untitled](Untitled%20134.png)

如果.py文件本身使用UTF-8编码，并且也申明了# -*coding: utf-8 -*，打开命令提示符测试就可以正常显示中文：

![Untitled](Untitled%20135.png)

**2.格式化**

在Python中，采用的格式化方式和C语言是一致的，用`%`实现，举例如下：

```
>>> 'Hello, %s' % 'world'
'Hello, world'
>>> 'Hi, %s, you have $%d.' % ('Michael', 1000000)
'Hi, Michael, you have $1000000.'
```

你可能猜到了，`%`运算符就是用来格式化字符串的。在字符串内部，`%s`表示用字符串替换，`%d`表示用整数替换，有几个`%?`占位符，后面就跟几个变量或者值，顺序要对应好。如果只有一个`%?`，括号可以省略。

常见的占位符有：

| 占位符 | 替换内容 |
| --- | --- |
| %d | 整数 |
| %f | 浮点数 |
| %s | 字符串 |
| %x | 十六进制整数 |

如果你不太确定应该用什么，`%s`永远起作用，它会把任何数据类型转换为字符串：

```python
>>> 'Age: %s. Gender: %s' % (25, True)
'Age: 25. Gender: True'
```

如果需要打印%就需要转义，用`%%`来表示一个`%`：

```python
>>> 'growth rate: %d %%' % 7
'growth rate: 7 %'
```

- format()

另一种格方法是使用字符串的`format()`方法，它会用传入的参数依次替换字符串内的占位符`{0}`、`{1}`……，不过这种方式写起来比%要麻烦得多：

```python
>>> 'Hello, {0}, 成绩提升了 {1:.1f}%'.format('小明', 17.125)
'Hello, 小明, 成绩提升了 17.1%'
```

但是我们推荐使用format(),因为format 更像是一个编辑字符串的功能，而非像百分号那样的固定搭配。它和其它字符串修改相统一。使用format()可以和其它字符串修改方法相统一。

从这里看出，简单的使用方式，就是我只用`{}`来占位，后面在 format 里按顺序放入值就好了，不用管这个值到底是什么类型。 其实除了这样的方式，format 还支持很多其他方式。比如我给 `{}` 里放一个数字，表示后面 format 里面的 index，这样我就能复用传入的值了。 这一招就比 百分号 模式要好一些。

```python
name = "莫烦Python"
age = 18
height = 1.8
print("我的名字是 {0} !我 {1} 岁了，我 {2} 米高~我是{0}".format(name, age, height))
```

同样的，format也支持字典方式进行传入：

```python
name = "莫烦Python"
age = 18
height = 1.8
print("我的名字是 {nm} !我 {age} 岁了，我 {ht} 米高~我是{nm}".format(nm=name, age=age, ht=height))
```

如果我们需要复用时，尽量不使用index而是直接使用字典形式。

- f-string

最后一种格式化字符串的方法是使用以`f`开头的字符串，称之为`f-string`，它和普通字符串不同之处在于，字符串如果包含`{xxx}`，就会以对应的变量替换：

```python
>>> r = 2.5
>>> s = 3.14 * r ** 2
>>> print(f'The area of a circle with radius {r} is {s:.2f}')
The area of a circle with radius 2.5 is 19.62
```

上述代码中，`{r}`被变量`r`的值替换，`{s:.2f}`被变量`s`的值替换，并且`:`后面的`.2f`指定了格式化参数（即保留两位小数），因此，`{s:.2f}`的替换结果是`19.62`。

**3.修改字符串**

- `string.strip()`
- `string.replace()`
- `string.lower()`
- `string.upper()`
- `string.split()`
- `",".join([])`
- `string.startswith()`
- `string.endswith()`

### 列表

### 字典

### 集合

## 程序控制

和其它程序语言一样，Python提供最基本的条件控制和循环控制两种。在之前行与缩进中我们学习到，Python不提供“{}”而是使用缩进来进行控制。

### Python输入

input函数是python的内置函数，它专门用来接收标准输入数据，当用户在终端输入回车后表示输入结束，函数返回值是字符串类型。

想要让自己写的程序与用户交互，可以通过键盘，也可以通过文件。内置函数input可以从标准输入中读取一行文本数据，默认的标准输入就是键盘，下面是一个非常简单的示例：

```python
value = input("请输入一个整数:")
print(value, type(value))
```

input函数接受一个字符串参数，在终端会输出这个字符串参数作为人机交互的提示语。

### 条件控制

Python的条件控制只提供了`if`语句，不提供`switch..case`语句。

从形式上看，if语句可以分为3中形式：

- if statement
- if-else
- if-elif-else

当对应多个条件有多个逻辑分支时，则应使用**if-elif-else** 形式的if语句来处理，比如下面的代码

```python
temperature = input("请输入今天的温度:")
temperature = int(temperature)
if temperature < 0:
    print("寒冷")
elif temperature < 15:
    print("微冷")
elif temperature < 25:
    print("温暖")
else:
    print("炎热")
```

`pass`关键字用于跳过执行程序体。当我们编写代码时，如果一个功能尚未完成，而只是做一个接口时，我们可以使用`pass`关键字进行替换，这样Python不会报错、正常执行而该接口对整体无影响。

### 循环控制

与其他编程语言一样，python提供了for循环和while循环这两种循环方式。循环对于任何一门编程语言都是不可缺少的程序控制方式，如果没有循环，计算机将变得和人一样慢。

**1.for循环**

Python for循环可以遍历任何可迭代对象，比如列表，字典，集合，字符串等，通过for循环，可以对可迭代对象里的每一个元组执行一组语句，从原理上看，python的for循环与其他编程语言的for循环不太相似，更像是其他面向对象语言中的迭代器方法。

for循环，从形式上可以分为两种

- 使用range函数自由控制循环次数
- 遍历容器

range函数返回一个对象，该对象产生一个整数序列。

range函数有3个参数

- start 整数序列开始的位置
- stop 整数序列结束的位置
- step 步长

开始与结束位置所组成的区间[start, stop)是左闭右开的，start默认是0，step默认是1。下面向你展示range函数的使用方法

- range(1, 5) 产生的整数序列是1， 2， 3， 4
- range(0, 4, 2) 产生的整数序列是0，2
- range(5, 0, -1) 产生的整数序列是5， 4， 3， 2， 1
- range(3) 产生的整数序列是0，1，2

```python
for i in range(0, 101, 3):
    if i % 2 == 0:
        print(i)
```

**2.while循环**

```python
while 表达式:
    代码块
```

上面的代码会一直执行下去，形成了死循环，除非你有意实现一个死循环，否则，这样的死循环会导致致命的问题。

**3.continue与break**

coninue的中文翻译是继续，在循环体里，continue的作用是跳过当前循环的剩余语句，结束本次循环，继续进行下一轮循环。

```python
lst = [4, 6, 1, 7, 2, 9, 3]

for item in lst:
    if item == 7:
        continue
    print(item)
```

程序输出结果为

```python
4
6
1
2
9
3
```

不同于continue，break具有很强的破坏力，它的作用是直接停止当前所在的循环，程序控制转移至循环体的下一条语句。

```python
lst = [1, 4, 5, 10, 2, 11, 15]

for item in lst:
    if item > 10:
        print(item)
        break
```

程序输出结果为`11`

当找到一个满足条件的数据时，先使用print输出，然后执行break，终止循环，这样就不会输出15了。

## Python函数

### 内置函数

Python提供了很多内置函数供使用者快速调用：abs()\help()\数据类型转换

调用`abs`函数（绝对值）：

```python
>>> abs(100)
100
>>> abs(-20)
20
>>> abs(12.34)
12.34
```

help(abs)可以查看内置函数abs的说明:

```python
>>> int('123')
123
>>> int(12.34)
12
>>> float('12.34')
12.34
>>> str(1.23)
'1.23'
>>> str(100)
'100'
>>> bool(1)
True
>>> bool('')
False
```

### 定义函数

在Python中，定义一个函数要使用def语句，依次写出函数名、括号、括号中的参数和冒号:，然后，在缩进块中编写函数体，函数的返回值用return语句返回。

```python
import math

def move(x, y, step, angle=0):
    nx = x + step * math.cos(angle)
    ny = y - step * math.sin(angle)
    return nx, ny
```

`import math`语句表示导入`math`包，并允许后续代码引用`math`包里的`sin`、`cos`等函数。

```python
>>> x, y = move(100, 100, 60, math.pi / 6)
>>> print(x, y)
151.96152422706632 70.0
```

但其实这只是一种假象，Python函数返回的仍然是单一值：

```python
>>> r = move(100, 100, 60, math.pi / 6)
>>> print(r)
(151.96152422706632, 70.0)
```

原来返回值是一个tuple！但是，在语法上，返回一个tuple可以省略括号，而多个变量可以同时接收一个tuple，按位置赋给对应的值，所以，Python的函数返回多值其实就是返回一个tuple，但写起来更方便。

## 高级特性

## 函数式编程

## Python模块

在计算机程序的开发过程中，随着程序代码越写越多，在一个文件里代码就会越来越长，越来越不容易维护。

为了编写可维护的代码，我们把很多函数分组，分别放到不同的文件里，这样，每个文件包含的代码就相对较少，很多编程语言都采用这种组织代码的方式。

为了避免模块名冲突，Python又引入了按目录来组织模块的方法，称为包（Package）。

<aside>
💡 在Python中，一个.py文件就称之为一个模块（Module）;在Python中，一个文件夹就称之为一个模块包（Package）。

</aside>

比如如下的目录结构：

```python
mycompany
 ├─ web
 │  ├─ __init__.py
 │  ├─ utils.py
 │  └─ www.py
 ├─ __init__.py
 ├─ abc.py
 └─ utils.py
```

文件`www.py`的模块名就是`mycompany.web.www`，两个文件`utils.py`的模块名分别是`mycompany.utils`和`mycompany.web.utils`。

创建模块时要注意命名，不能和Python自带的模块名称冲突。例如，系统自带了sys模块，自己的模块就不可命名为sys.py，否则将无法导入系统自带的sys模块。

### 作用域

这里主要探讨的是模块中的定义的函数和变量作用域，也就是涉及访问权限控制。在Java中使用private\protect\default\public关键词来修饰方法和类；而在Golang中，使用首字母大小写来区分访问权限。Python则与之不同，通过`_`前缀来实现的:

正常的函数和变量名默认是公开的（public），可以被外部模块直接引用，比如：`abc`，`x123`，`PI`等；

类似`__xxx__`这样的变量是特殊变量，可以被直接引用，但是有特殊用途，比如上面的`__author__`，`__name__`就是特殊变量，`hello`模块定义的文档注释也可以用特殊变量`__doc__`访问，我们自己的变量一般不要用这种变量名；可以理解为一般的命名则是标识符，它们就是命名中的“关键字”，即该类命名依据被负有特殊意义。

类似`_xxx`和`__xxx`这样的函数或变量就是非公开的（private），不应该被直接引用，比如`_abc`，`__abc`等；

### 导入模块

Python导入模块使用关键字import。我们知道一个模块代表的是一个.py文件，它包含定义的变量和方法/函数。我们使用import可以实现整个模块的导入（`import`），也可以只导入某一方法/函数和变量（`from ... import ...`）。

utils.py文件的内容如下

```python
import os

def get_file_lst(py_path, suffix):
    """
    遍历指定文件目录下的所有指定类型文件
    :param py_path:
    :return:
    """
    file_lst = []
    for root, dirs, files in os.walk(py_path):
        for file in files:
            file_name = os.path.join(root, file)
            if file_name.endswith(suffix):
                file_lst.append(file_name)

    return file_lst
```

如何在program_count.py 文件中使用utils.py文件中的函数呢？

使用import，直接导入utils模块，使用get*file*lst函数时，则需要用utils.get*file*lst这种方法来调用函数。

```python
import utils

def get_program_line_count(file_name):
    """
    返回单个py脚本的代码行数
    :param filename:
    :return:
    """
    # 存储代码行数
    count = 0
    with open(file_name, 'r', encoding='utf-8')as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith("#"):
                continue
            count += 1
    return count

def get_py_program_count(py_path):
    # 获取指定目录下所有的python脚本
    file_lst = utils.get_file_lst(py_path, '.py')
    count = 0
    # 遍历列表,获取单个python脚本的代码行数
    for file_name in file_lst:
        count += get_program_line_count(file_name)  # 累加代码函数

    return count   # 返回代码总函数

if __name__ == '__main__':
    py_path = '/Users/kwsy/PycharmProjects/pythonclass'
    print(get_py_program_count(py_path))
```

import 会将整个模块的内容全部导入，但有时，我们不需要那么多，只需要其中一个两个就可以了。
于是，我们也可以这样写：

```python
from utils import get_file_lst

def get_py_program_count(py_path):
    file_lst = get_file_lst(py_path, '.py')
    count = 0
    for file_name in file_lst:
        count += get_program_line_count(file_name)

    return count
```

如果你想全部导入，也可以写成`from ... import *` 的形式，*表示全部导入。这种写法和import的区别在于，import一个模块A后，调用A里的函数是必须写成A.func的形式，而from ... import ... 的方法，就可以不用模块去调用方法了，可以直接调用函数。

另外，Python还提供了`as`关键字来给引入的模块取别名：import ...as...

### 模块属性

一个python脚本（以.py 结尾的文件）就是一个模块，模块自身有若干属性，其中比较常用的是如下两个

1. **name** 模块的名称
2. **file** 脚本的完整文件路径

在任意一个python脚本里，你都可以输出这两个属性

```python
print(__name__)
print(__file__)
```

得到结果

```python
__main__
/Users/zhangdongsheng/experiment/test/test.py
```

<aside>
💡 当脚本被直接执行时，模块属性**name** 等于**main**；当脚本被其他模块引入时，模块属性**name** 等于脚本名称去掉.py 后剩余的部分

</aside>

我们知道一个模块文件中不一定全部是函数和变量，可以直接在模块文件中写入执行语句。当我们导入模块时是会直接执行的，因此我们在每个脚本里都写上一段`if __name__ == '__main__'`: 如果你希望一些代码只有在脚本被直接执行时才执行，那么就把这些代码放入到if 语句块中：

```python
def func():
    print('ok')

if __name__ == '__main__':
    func()
```

了解了`if __name__ == '__main__'`的作用之后，我们很容易知道它的实际应用场景：测试模块中的函数功能是否正常。通过`if __name__ == '__main__'`，可以帮助我们独立执行这一模块。在实际开发中，我们的项目由一个程序入口模块和多个其它模块组成。这个程序入口引入其它的模块。此时我们只需要执行这个程序入口模块即可启动项目，而不需要再运行其它模块了。因此在每个模块中`if __name__ == '__main__'`来隔离出测试部分的好处是显而易见的。

### 安装第三方模块

**1.pip**

在Python中，安装第三方模块，是通过包管理工具pip完成的。在安装Python解释器时往往会附带pip包管理工具(python2→pip2;python3→pip3;)在命令提示符窗口下尝试运行`pip`，如果Windows提示未找到命令，可以重新运行安装程序添加`pip`；如果提示找到了命令，则表示pip已经安装成功。

一般来说，第三方库都会在Python官方的[pypi.python.org](https://pypi.python.org/)网站注册，要安装一个第三方库，必须先知道该库的名称，可以在官网或者pypi上搜索，比如Pillow的名称叫[Pillow](https://pypi.python.org/pypi/Pillow/)，因此，安装Pillow的命令就是：

```python
pip install Pillow
```

耐心等待下载并安装后，就可以使用Pillow了。

**2.Anaconda**

在使用Python时，我们经常需要用到很多第三方库，例如，上面提到的Pillow，以及MySQL驱动程序，Web框架Flask，科学计算Numpy等。用pip一个一个安装费时费力，还需要考虑兼容性。我们推荐直接使用[Anaconda](https://www.anaconda.com/)，这是一个基于Python的数据处理和科学计算平台，它已经内置了许多非常有用的第三方库，我们装上Anaconda，就相当于把数十个第三方模块自动安装好了，非常简单易用。

可以从[Anaconda官网](https://www.anaconda.com/download/)下载GUI安装包，安装包有500~600M，所以需要耐心等待下载。下载后直接安装，Anaconda会把系统Path中的python指向自己自带的Python，并且，Anaconda安装的第三方模块会安装在Anaconda自己的路径下，不影响系统已安装的Python目录。

安装好Anaconda后，重新打开命令行窗口，输入python，可以看到Anaconda的信息：

```python
┌────────────────────────────────────────────────────────┐
│Command Prompt - python                           - □ x │
├────────────────────────────────────────────────────────┤
│Microsoft Windows [Version 10.0.0]                      │
│(c) 2015 Microsoft Corporation. All rights reserved.    │
│                                                        │
│C:\> python                                             │
│Python 3.6.3 |Anaconda, Inc.| ... on win32              │
│Type "help", ... for more information.                  │
│>>> import numpy                                        │
│>>> _                                                   │
│                                                        │
│                                                        │
│                                                        │
└────────────────────────────────────────────────────────┘
```

可以尝试直接`import numpy`等已安装的第三方模块。在Pytorch中我们将使用Anaconda进行开发，而在目前Python基本语法学习中，我们只需要掌握python一般解释器的安装与配置即可。

### 常用模块

[常用模块参考文档](http://www.coolpython.net/python_primary/module/standard_module_index.html)

## 面向对象

### 类的定义和实例化

定义一个类使用class关键字

```python
class Stu:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def run(self):
        print("{name} is running".format(name=self.name))

```

之前我们使用def来定义函数，在类里面，同样用def关键字来定义函数，但是我们管类里的函数叫方法。

**1.初始化函数**

注意看这个方法

```python
def __init__(self, name, age):
    self.name = name
    self.age = age
```

单词init是初始化的意思，**init**是初始化函数，当实例被构造出来以后，使用**init**方法来初始化实例属性。初始化函数相当于Java类中的构造函数。类中每个方法都有一个self属性，它相当于Java中的this，我们定义一个方法可以写可以不写这个属性。

**2.实例化**

类是一种封装技术，我们把数据和方法都封装到了类里，如果你想使用数据和方法，那么你需要用类创建出一个实例来，这个过程就叫做实例化

```python
class Stu:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def run(self):
        print("{name} is running".format(name=self.name))

s = Stu('小明', 18)
s.run()
```

代码执行结果

```python
<class '__main__.Stu'>
小明 is running
```

**3.实例方法，类方法，静态方法， 类属性**

类里的方法有3种，在第一小节中所定义的类中，方法都是实例方法。这3种方法有各自的定义方式和权限：

| 名称 | 定义方法 | 权限 | 调用方法 |
| --- | --- | --- | --- |
| 实例方法 | 第一个参数必须是self，一般命名为self | 可以访问实例的属性和方法，也可以访问类的实例和方法 | 一般通过示例调用，类也可以调用 |
| 类方法 | 使用装饰器@classmethod修饰，第一个参数必须是当前的类对象，一般命名为cls | 可以访问类的实例和方法 | 类实例和类都可以调用 |
| 静态方法 | 使用装饰器@staticmethod修饰，参数随意，没有self和cls | 不可以访问类和实例的属性和方法 | 实例对象和类对象都可以调用 |

下面修改类Stu的定义来向你展示这3种方法的区别

```python
class Stu:
    school = '湘北高中'   # 类属性
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def play_basketball(self):
        print("{name} 正在打篮球".format(name=self.name))

    @classmethod
    def sport(cls):
        print("{school}的同学都喜欢篮球".format(school=cls.school))

    @staticmethod
    def clean():
        print("打扫教室卫生")

stu = Stu("樱木花道", 17)
stu.play_basketball()       # 通过实例调用实例方法
Stu.play_basketball(stu)    # 通过类调用实例方法

Stu.sport()     # 通过类调用类方法
stu.sport()     # 通过示例调用类方法

Stu.clean()     # 通过类调用静态方法
stu.clean()     # 通过实例调用静态方法

print(stu.school)       # 通过实例访问类属性
stu.school = '山王工业'     # 只是增加了一个实例属性,类属性不会被修改
print(Stu.school)       # 通过类访问类属性
```

### 类的封装

之前我们就知道，Python使用'_'来规定访问权限。在面向对象中依然如此。

在python里，如果属性和方法前面是双下划线，那么这个属性和方法就变成了私有的属性。

```python
class Animal:
    def __init__(self, name, age):
        self.__name = name
        self.__age = age

    def __run(self):
        print("run")

a = Animal('猫', 2)
a.__run()
print(a.__name, a.__age)

```

__run()方法是以双下划线开头的，这样的方法，类的对象无法使用，双下划线开头的属性也同样无法访问，通过这种方法，就可以将不希望外部访问的属性和方法隐藏起来。

### 类的继承

## 错误和异常

和Java、Golang一样，错误和异常的处理是每个程序设计语言必须考虑的问题，Python对此也提出了自己的机制。

这里我们就不讲解错误和异常是什么，直接学习抛出异常和异常捕获与处理。

![Untitled](Untitled%20136.png)

### 抛出异常

抛出异常时，你可以指定抛出哪个异常,如果你不想指定，那么可以抛出异常Exception， 它是所有异常的父类。抛出关键字为`raise`，等价于Java的`throw`关键字。

```python
def divide(x, y):
    if y == 0:
        raise Exception("0不能做分母")
    return x/y

if __name__ == '__main__':
    divide(10, 5)
    divide(10, 0)

```

### 捕获异常

Python中，捕获异常使用try … except …else…finally这种语法来捕捉异常，下面是一个异常捕获的示例

```python
def test(a, b):
    try:
        print(a/b)
    except ZeroDivisionError:
        print("0不能作分母")

if __name__ == '__main__':
    test(10, 5)
    test(10, 0)
```

Java采用的是try…catch;Golang采用的则是defer…recover();显然Python和Java类似。

也可以逐个捕捉

```python
def test(a, b):
    try:
        print(a/b)
    except ZeroDivisionError:
        print('0不能做分母')
    except ValueError:
        print("类型错误")
    else:
        print('什么异常都没发生')

if __name__ == '__main__':
    test(10, 5)
    test(10, 0)
```

try … except … else这种语法，当没有异常发生时，就会执行else语句块里的代码，反之则不执行else语句。

你可以在finally语句块里做清理操作，因为不论try子句里是否发生异常，也不论你在except语句块里做了什么操作，总之，最终一定会执行finally语句块里的代码，这就保证了这里的代码最后一定会被执行，所以，清理收尾的工作一定会进行。

你可以在这里输出日志，你可以做任何你想做的事情。

```python
def divide(x, y):
    try:
        result = x / y
    except ZeroDivisionError:
        print("division by zero!")
    else:
        print("result is", result)
    finally:
        print("executing finally clause")

if __name__ == '__main__':
    divide(10, 5)
    divide(10, 0)
```

### 主动触发异常

我们知道Java采用的是new Exception创建一个异常就可以触发try到catch。Python提供了`raise`关键字来手动触发异常。通过手动创造异常，我们可以给错误添加友善的错误信息提示，方便后续开发者便捷更改。

```python
def no_negative(num):
    if num < 0:
        raise ValueError("I said no negative")
    return num

print(no_negative(-1))

```

### 异常错误名称表

有哪些能被 raise 的 error 呢？.[Python异常错误名称表](https://mofanpy.com/tutorials/python-basic/interactive-python/try-except#Python%E5%BC%82%E5%B8%B8%E9%94%99%E8%AF%AF%E5%90%8D%E7%A7%B0%E8%A1%A8)

| 异常名称 | 描述 |
| --- | --- |
| BaseException | 所有异常的基类 |
| SystemExit | 解释器请求退出 |
| KeyboardInterrupt | 用户中断执行(通常是输入^C) |
| Exception | 常规错误的基类 |
| StopIteration | 迭代器没有更多的值 |
| GeneratorExit | 生成器(generator)发生异常来通知退出 |
| StandardError | 所有的内建标准异常的基类 |
| ArithmeticError | 所有数值计算错误的基类 |
| FloatingPointError | 浮点计算错误 |
| OverflowError | 数值运算超出最大限制 |
| ZeroDivisionError | 除(或取模)零 (所有数据类型) |
| AssertionError | 断言语句失败 |
| AttributeError | 对象没有这个属性 |
| EOFError | 没有内建输入,到达EOF 标记 |
| EnvironmentError | 操作系统错误的基类 |
| IOError | 输入/输出操作失败 |
| OSError | 操作系统错误 |
| WindowsError | 系统调用失败 |
| ImportError | 导入模块/对象失败 |
| LookupError | 无效数据查询的基类 |
| IndexError | 序列中没有此索引(index) |
| KeyError | 映射中没有这个键 |
| MemoryError | 内存溢出错误(对于Python 解释器不是致命的) |
| NameError | 未声明/初始化对象 (没有属性) |
| UnboundLocalError | 访问未初始化的本地变量 |
| ReferenceError | 弱引用(Weak reference)试图访问已经垃圾回收了的对象 |
| RuntimeError | 一般的运行时错误 |
| NotImplementedError | 尚未实现的方法 |
| SyntaxError | Python 语法错误 |
| IndentationError | 缩进错误 |
| TabError | Tab 和空格混用 |
| SystemError | 一般的解释器系统错误 |
| TypeError | 对类型无效的操作 |
| ValueError | 传入无效的参数 |
| UnicodeError | Unicode 相关的错误 |
| UnicodeDecodeError | Unicode 解码时的错误 |
| UnicodeEncodeError | Unicode 编码时错误 |
| UnicodeTranslateError | Unicode 转换时错误 |
| Warning | 警告的基类 |
| DeprecationWarning | 关于被弃用的特征的警告 |
| FutureWarning | 关于构造将来语义会有改变的警告 |
| OverflowWarning | 旧的关于自动提升为长整型(long)的警告 |
| PendingDeprecationWarning | 关于特性将会被废弃的警告 |
| RuntimeWarning | 可疑的运行时行为(runtime behavior)的警告 |
| SyntaxWarning | 可疑的语法的警告 |
| UserWarning | 用户代码生成的警告 |